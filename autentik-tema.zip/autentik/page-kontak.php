<?php
defined( 'ABSPATH' ) || exit;
/**
 * Halaman Kontak (slug: kontak): formulir di kiri; di kanan panel kantor
 * (kontak lengkap, jam, peta klik-untuk-memuat) dan "Setelah Anda mengirim".
 *
 * @package Autentik
 */

get_header();
the_post();
$tel = preg_replace( '/\D+/', '', autentik_opt( 'phone' ) );
list( $h1, $dek ) = autentik_page_head( get_the_ID() );
autentik_banner( $h1, $dek, array( array( get_the_title(), '' ) ) );
?>
<section class="bh-sec">
	<div class="wrap">
		<nav class="k-quick" aria-label="Hubungi langsung">
			<a href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo autentik_icon( 'phone' ); // phpcs:ignore ?>Telepon</a>
			<a href="<?php echo esc_url( autentik_wa() ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>WhatsApp</a>
			<a href="<?php echo esc_url( autentik_opt( 'maps' ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'pin' ); // phpcs:ignore ?>Petunjuk Arah</a>
		</nav>
	</div>
	<div class="wrap cform">
		<div class="fcard rv">
			<h2>Jadwalkan Konsultasi</h2>
			<p class="sub">Tuliskan garis besarnya saja: apa yang terjadi, siapa saja pihak yang terlibat, dan dokumen apa yang sudah Anda miliki. Kami akan menanggapi paling lambat satu hari kerja.</p>
			<?php
			$c = get_the_content();
			if ( shortcode_exists( 'fluentform' ) && preg_match( '/\[fluentform[^\]]*\]/', $c, $sc ) ) {
				echo do_shortcode( $sc[0] ); // phpcs:ignore -- Fluent Forms bila terpasang
			} else {
				autentik_form( 'kontak' );
			}
			?>
		</div>

		<aside class="office rv" aria-labelledby="kantor-h">
			<div class="office-card">
				<h2 id="kantor-h">Kantor Medan Baru</h2>
				<dl>
					<div><dt><?php echo autentik_icon( 'pin' ); // phpcs:ignore ?>Alamat</dt><dd><?php echo esc_html( autentik_address() ); ?></dd></div>
					<div><dt><?php echo autentik_icon( 'phone' ); // phpcs:ignore ?>Telepon</dt><dd><a href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo esc_html( autentik_opt( 'phone' ) ); ?></a></dd></div>
					<div><dt><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>WhatsApp</dt><dd><a href="<?php echo esc_url( autentik_wa() ); ?>" target="_blank" rel="noopener">Hubungi lewat WhatsApp</a></dd></div>
					<div><dt><?php echo autentik_icon( 'mail' ); // phpcs:ignore ?>Email</dt><dd><a href="mailto:<?php echo esc_attr( autentik_opt( 'email' ) ); ?>"><?php echo esc_html( autentik_opt( 'email' ) ); ?></a></dd></div>
					<div><dt><?php echo autentik_icon( 'clock' ); // phpcs:ignore ?>Jam kerja</dt><dd><?php echo esc_html( autentik_opt( 'hours' ) ); ?> <span class="open-now" data-open-now hidden><i></i><em></em></span></dd></div>
				</dl>
			</div>

			<div class="after">
				<h2>Setelah formulir dikirim</h2>
				<ol>
					<li><b>Kami menelaah pesan Anda</b><span>Pada jam kerja berikutnya, sekaligus memeriksa kemungkinan benturan kepentingan.</span></li>
					<li><b>Kami menghubungi Anda</b><span>Paling lambat satu hari kerja, melalui WhatsApp atau telepon.</span></li>
					<li><b>Anda menerima penawaran tertulis</b><span>Memuat langkah hukum, dokumen yang diperlukan, perkiraan waktu, dan biaya jasa hukum, sebelum pekerjaan dimulai.</span></li>
				</ol>
			</div>
		</aside>
	</div>
</section>

<section class="bh-sec k-visit" id="datang" aria-labelledby="datang-h">
	<div class="wrap k-visit-in">
		<div class="k-visit-t rv">
			<h2 id="datang-h">Datang ke kantor</h2>
			<p>Konsultasi tatap muka berlangsung di kantor kami di Medan Baru. Buat janji dulu lewat formulir atau WhatsApp, supaya Anda tidak perlu menunggu.</p>
			<dl>
				<div><dt><?php echo autentik_icon( 'pin' ); // phpcs:ignore ?>Alamat</dt><dd><?php echo esc_html( autentik_address() ); ?></dd></div>
				<div><dt><?php echo autentik_icon( 'clock' ); // phpcs:ignore ?>Jam kerja</dt><dd><?php echo esc_html( autentik_opt( 'hours' ) ); ?> <span class="open-now" data-open-now hidden><i></i><em></em></span></dd></div>
				<?php if ( autentik_opt( 'patokan' ) ) : ?>
					<div><dt><?php echo autentik_icon( 'map' ); // phpcs:ignore ?>Patokan</dt><dd><?php echo esc_html( autentik_opt( 'patokan' ) ); ?></dd></div>
				<?php endif; ?>
			</dl>
			<div class="acts">
				<a class="btn b-gold" href="<?php echo esc_url( autentik_opt( 'maps' ) ); ?>" target="_blank" rel="noopener">Petunjuk Arah <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
				<a class="btn b-line" href="<?php echo esc_url( autentik_wa( autentik_sapa() . 'Saya ingin membuat janji untuk konsultasi tatap muka di kantor Anda.' ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>Hubungi lewat WhatsApp</a>
			</div>
		</div>
		<div class="map rv">
			<img src="<?php echo esc_url( autentik_img( 'kontak.jpg' ) ); ?>"<?php echo autentik_srcset( autentik_img( 'kontak.jpg' ), '(max-width:900px) 100vw, 55vw' ); // phpcs:ignore ?> alt="" loading="lazy" width="2000" height="1333">
			<div class="in">
				<div class="acts">
					<button type="button" class="btn b-line b-sm" data-map="<?php echo esc_url( 'https://www.google.com/maps?q=' . rawurlencode( autentik_address() ) . '&output=embed' ); ?>">Tampilkan Peta</button>
				</div>
				<small class="map-n">Peta dimuat dari Google Maps setelah Anda menekan tombol Tampilkan Peta.</small>
			</div>
		</div>
	</div>
</section>

<?php if ( autentik_opt( 'scam_notice' ) ) : ?>
<section class="sec alt" id="waspada">
	<div class="wrap">
		<div class="scam-box rv">
			<span class="i"><?php echo autentik_icon( 'shield' ); // phpcs:ignore ?></span>
			<div>
				<h2>Waspada penipuan yang mengatasnamakan kantor kami</h2>
				<p>Nama kantor hukum kerap disalahgunakan untuk meminta uang atau data pribadi. Tagihan jasa hukum kami selalu diterbitkan atas nama firma. Apabila Anda menerima permintaan pembayaran, surat, atau pesan yang mengatasnamakan kantor atau tim kami dan Anda meragukannya, tanyakan dulu kepada kami melalui kontak resmi berikut sebelum menindaklanjutinya:</p>
				<ul>
					<li><?php echo autentik_icon( 'phone' ); // phpcs:ignore ?><a href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo esc_html( autentik_opt( 'phone' ) ); ?></a></li>
					<li><?php echo autentik_icon( 'mail' ); // phpcs:ignore ?><a href="mailto:<?php echo esc_attr( autentik_opt( 'email' ) ); ?>"><?php echo esc_html( autentik_opt( 'email' ) ); ?></a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
<?php
get_footer();
