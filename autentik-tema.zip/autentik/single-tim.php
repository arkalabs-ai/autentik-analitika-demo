<?php
/**
 * Profil anggota tim (v21): hero dua kolom berpotret, pita kredensial, profil, tulisan, anggota lain.
 * Setiap bagian otomatis tersembunyi bila datanya belum diisi. Label "Advokat" dan tombol
 * "Konsultasi dengan …" hanya tampil untuk anggota berstatus advokat (kolom Status profesi di CMS).
 *
 * @package Autentik
 */

get_header();
the_post();
$id     = get_the_ID();
$name   = get_the_title();
$gelar  = (string) autentik_field( 'gelar', $id );
$role   = (string) autentik_field( 'jabatan', $id );
$bio    = (string) autentik_field( 'bio', $id );
$email  = (string) autentik_field( 'email', $id );
$bahasa = (string) autentik_field( 'bahasa', $id );
$izin   = (string) autentik_field( 'no_izin', $id );
$bas    = (string) autentik_field( 'no_bas', $id );
$org    = (string) autentik_field( 'organisasi', $id );
$pend   = autentik_lines( autentik_field( 'pendidikan', $id ) );
$kg     = autentik_lines( autentik_field( 'keanggotaan', $id ) );
$bidang = autentik_layanan_for_tim( $id );
$tulis  = autentik_posts_by_tim( $id );
$tel    = preg_replace( '/\D+/', '', autentik_opt( 'phone' ) );
$adv    = autentik_is_advokat( $id );
$first  = 0 === strpos( $name, 'Dr.' ) ? $name : strtok( $name, ' ' );
$izin_l = array_values( array_filter( array( $adv ? 'Advokat' : '', $org, $bas ? 'No. BAS/KTA ' . $bas : '', $izin ) ) );
$izin_l = array_merge( $izin_l, $kg );
$cons   = $adv ? add_query_arg( 'advokat', rawurlencode( autentik_plain_title() ), home_url( '/kontak/' ) ) . '#form-konsultasi' : autentik_konsultasi_url();
?>
<section class="pf-hero">
	<div class="wrap pf-in">
		<div class="pf-t">
			<?php autentik_breadcrumb( array( array( 'Tim Kami', home_url( '/tim/' ) ), array( $name, '' ) ) ); ?>
			<?php if ( $role ) : ?><p class="pf-role"><?php echo esc_html( $role ); ?></p><?php endif; ?>
			<h1><?php echo esc_html( $name ); ?></h1>
			<?php if ( $gelar ) : ?><p class="pf-dg"><?php echo esc_html( $gelar ); ?></p><?php endif; ?>
			<?php if ( $bidang ) : ?>
				<ul class="pf-bid" aria-label="Layanan yang ditangani">
					<?php foreach ( $bidang as $b ) : ?>
						<li><a href="<?php echo esc_url( get_permalink( $b ) ); ?>"><?php echo esc_html( get_the_title( $b ) ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<ul class="pf-ct">
				<li><?php echo autentik_icon( 'mail' ); // phpcs:ignore ?><a href="mailto:<?php echo esc_attr( $email ? $email : autentik_opt( 'email' ) ); ?>"><?php echo esc_html( $email ? $email : autentik_opt( 'email' ) ); ?></a></li>
				<li><?php echo autentik_icon( 'phone' ); // phpcs:ignore ?><a href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo esc_html( autentik_opt( 'phone' ) ); ?></a></li>
				<li><?php echo autentik_icon( 'pin' ); // phpcs:ignore ?><span>Kantor Medan Baru, <?php echo esc_html( autentik_opt( 'city' ) ); ?></span></li>
			</ul>
			<div class="acts">
				<a class="btn b-gold" href="<?php echo esc_url( $cons ); ?>"><?php echo $adv ? 'Jadwalkan Konsultasi dengan ' . esc_html( $first ) : 'Jadwalkan Konsultasi'; ?> <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
				<a class="btn b-line" href="<?php echo esc_url( add_query_arg( 'vcard', '1', get_permalink() ) ); ?>" rel="nofollow"><?php echo autentik_icon( 'user' ); // phpcs:ignore ?>Simpan Kontak</a>
			</div>
		</div>
		<figure class="pf-ph">
			<span class="bh-frame" aria-hidden="true"></span>
			<?php if ( has_post_thumbnail() ) : ?>
				<?php echo get_the_post_thumbnail( null, 'autentik-portrait', array( 'alt' => $name, 'fetchpriority' => 'high', 'sizes' => '(max-width:760px) 100vw, 420px' ) ) . autentik_demo_tag( get_post() ); // phpcs:ignore ?>
			<?php else : ?>
				<span class="ini" aria-hidden="true"><?php echo esc_html( autentik_initials( $name ) ); ?></span>
			<?php endif; ?>
		</figure>
	</div>
</section>

<?php
$cred = array();
if ( $pend ) {
	$cred[] = array( 'Pendidikan', $pend );
}
if ( $izin_l ) {
	$cred[] = array( 'Izin praktik dan organisasi profesi', $izin_l );
}
if ( $bidang ) {
	$cred[] = array( 'Layanan yang ditangani', array_map( 'get_the_title', $bidang ) );
}
if ( $bahasa ) {
	$cred[] = array( 'Bahasa', array( $bahasa ) );
}
?>
<?php if ( $cred ) : ?>
<section class="pf-cred" aria-label="Kualifikasi">
	<div class="wrap">
		<dl>
			<?php foreach ( $cred as $c ) : ?>
				<div><dt><?php echo esc_html( $c[0] ); ?></dt><?php foreach ( $c[1] as $l ) : ?><dd><?php echo esc_html( $l ); ?></dd><?php endforeach; ?></div>
			<?php endforeach; ?>
		</dl>
	</div>
</section>
<?php endif; ?>

<section class="bh-sec">
	<div class="wrap pf-body">
		<div class="pf-main">
			<h2 class="pf-h">Profil</h2>
			<div class="prose">
				<?php if ( $bio ) : ?>
					<p><?php echo esc_html( $bio ); ?></p>
				<?php elseif ( ! trim( get_the_content() ) ) : ?>
					<p class="pf-empty">Profil lengkap sedang kami siapkan. Untuk mengetahui pengalaman dan bidang yang ditangani, silakan hubungi kantor kami.</p>
				<?php endif; ?>
				<?php the_content(); ?>
			</div>

			<?php if ( $tulis ) : ?>
				<h2 class="pf-h">Artikel yang ditulis</h2>
				<ul class="pf-posts">
					<?php foreach ( $tulis as $p ) : ?>
						<li><a href="<?php echo esc_url( get_permalink( $p ) ); ?>"><time datetime="<?php echo esc_attr( get_the_date( 'c', $p ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y', $p ) ); ?></time><b><?php echo esc_html( get_the_title( $p ) ); ?></b><?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
		<aside class="pf-side">
			<div class="pf-office">
				<b>Kantor</b>
				<p><?php echo esc_html( autentik_opt( 'firm' ) ); ?><br><?php echo esc_html( autentik_address() ); ?></p>
				<p><?php echo esc_html( autentik_opt( 'hours' ) ); ?> <span class="open-now" data-open-now hidden><i></i><em></em></span></p>
				<a class="bh-more" href="<?php echo esc_url( autentik_opt( 'maps' ) ); ?>" target="_blank" rel="noopener">Petunjuk Arah <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
			</div>
		</aside>
	</div>
</section>

<?php
$others = array_slice( array_values( array_filter( autentik_tim_publik(), function ( $t ) use ( $id ) { return $t->ID !== $id; } ) ), 0, 4 );
if ( $others ) :
	?>
<section class="bh-sec bh-alt">
	<div class="wrap">
		<header class="bh-head bh-head-split">
			<h2 class="rv">Anggota tim lainnya</h2>
			<a class="bh-more rv" href="<?php echo esc_url( home_url( '/tim/' ) ); ?>">Lihat Seluruh Tim <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
		</header>
		<div class="bh-team-grid">
			<?php foreach ( $others as $t ) { get_template_part( 'template-parts/person', null, array( 'p' => $t ) ); } ?>
		</div>
	</div>
</section>
<?php endif; ?>
<?php
autentik_cta();
get_footer();
