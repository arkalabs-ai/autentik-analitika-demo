<?php
defined( 'ABSPATH' ) || exit;
/**
 * Halaman terima kasih (slug: terima-kasih): tujuan setelah formulir konsultasi terkirim (inc/form.php).
 * Tidak diindeks dan tidak masuk sitemap (inc/seo-geo.php). Event generate_lead dikirim assets/js/analytics.js
 * hanya bila pengunjung menyetujui analitik dan kiriman berasal dari peramban ini.
 * qa/46e & qa/46f #11: janji waktu tidak bergantung jam kirim (lencana jam kerja dari main.js), ada persiapan
 * sebelum konsultasi, dan pengingat nomor resmi.
 *
 * @package Autentik
 */

get_header();
the_post();
list( $h1, $dek ) = autentik_page_head( get_the_ID(), 'Permintaan konsultasi Anda telah kami terima', 'Kami akan menghubungi Anda melalui WhatsApp atau telepon paling lambat satu hari kerja. Pesan yang masuk di luar jam kerja kami telaah pada jam kerja berikutnya.' );
autentik_banner( $h1, $dek, array( array( 'Kontak', home_url( '/kontak/' ) ), array( get_the_title(), '' ) ) );
?>
<section class="bh-sec" data-terima-kasih>
	<div class="wrap tk-in">
		<div class="after rv" role="status">
			<h2>Proses setelah permintaan Anda kami terima</h2>
			<ol>
				<li><b>Kami menelaah pesan Anda</b><span>Pada jam kerja, <?php echo esc_html( autentik_opt( 'hours' ) ); ?>. Pesan yang masuk di luar jam itu kami telaah pada jam kerja berikutnya, sekaligus memeriksa kemungkinan benturan kepentingan.</span></li>
				<li><b>Kami menghubungi Anda</b><span>Paling lambat satu hari kerja, melalui WhatsApp atau telepon dari nomor resmi kantor. <span class="open-now" data-open-now hidden><i></i><em></em></span></span></li>
				<li><b>Anda menerima penawaran tertulis</b><span>Memuat langkah hukum, dokumen yang diperlukan, perkiraan waktu, dan biaya jasa hukum sebelum pekerjaan dimulai.</span></li>
			</ol>
		</div>
		<div class="tk-next rv">
			<p><b>Sambil menunggu,</b> kumpulkan KTP, dokumen yang berkaitan dengan persoalan Anda, dan catatan kronologi singkat. Dokumennya cukup disiapkan dulu; mohon tidak mengirimkan dokumen yang bersifat rahasia sebelum perjanjian jasa hukum ditandatangani.</p>
			<p><b>Nomor resmi kami <?php echo esc_html( autentik_opt( 'phone' ) ); ?></b> (telepon dan WhatsApp). Tagihan jasa hukum kami selalu diterbitkan atas nama firma. Bila ada pesan dari nomor lain yang mengatasnamakan kami, tanyakan dulu ke nomor resmi ini sebelum menanggapinya.</p>
			<p>Bila persoalan Anda mendesak, langsung saja hubungi kami lewat WhatsApp dan sebutkan nama Anda.</p>
			<div class="acts">
				<a class="btn b-gold" href="<?php echo esc_url( autentik_wa( autentik_sapa() . 'Saya baru saja mengirim formulir permintaan konsultasi melalui situs Anda.' ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>Hubungi lewat WhatsApp</a>
				<a class="btn b-line" href="<?php echo esc_url( home_url( '/artikel/' ) ); ?>">Baca Artikel dan Panduan Hukum</a>
			</div>
		</div>
	</div>
</section>
<?php
get_footer();
