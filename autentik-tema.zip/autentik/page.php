<?php
/**
 * Halaman umum (mis. Kebijakan Privasi & Disclaimer) dalam format dokumen:
 * tanggal pembaruan, daftar isi otomatis dari Heading 2 (menempel di samping), kolom baca yang nyaman.
 * Isi diedit lewat editor blok; Heading 1 + paragraf pertama menjadi judul & teks banner.
 *
 * @package Autentik
 */

get_header();
while ( have_posts() ) :
	the_post();
	list( $title, $dek, $blocks ) = autentik_page_head( get_the_ID() );
	autentik_banner( $title, $dek, array( array( get_the_title(), '' ) ), has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'autentik-wide' ) : '' );
	$h2 = count( array_filter( $blocks, function ( $b ) { return 'core/heading' === $b['blockName'] && 2 === (int) ( $b['attrs']['level'] ?? 2 ); } ) );
	?>
	<section class="sec">
		<div class="wrap <?php echo $h2 >= 3 ? 'doc' : ''; ?>">
			<?php if ( $h2 >= 3 ) : ?>
				<aside class="doc-side">
					<nav class="toc" id="toc" hidden aria-label="Daftar isi"><b>Daftar isi</b><ol></ol></nav>
				</aside>
			<?php endif; ?>
			<article class="prose" id="isi" style="<?php echo $h2 >= 3 ? '' : 'margin-inline:auto'; ?>">
				<p class="upd"><?php echo autentik_icon( 'clock' ); // phpcs:ignore ?>Terakhir diperbarui <?php echo esc_html( get_the_modified_date( 'j F Y' ) ); ?></p>
				<?php echo apply_filters( 'the_content', serialize_blocks( $blocks ) ); // phpcs:ignore ?>
			</article>
		</div>
	</section>
	<?php
endwhile;
if ( ! is_page( 'kebijakan-privasi' ) ) {
	autentik_cta();
}
get_footer();
