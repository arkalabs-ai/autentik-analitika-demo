<?php
/**
 * Halaman Tim (slug: tim) — direktori dengan pencarian nama & filter bidang praktik.
 *
 * @package Autentik
 */

get_header();
the_post();
$tim = autentik_tim_publik();
list( $h1, $dek, $rest ) = autentik_page_head( get_the_ID() );
autentik_banner( $h1, $dek, array( array( get_the_title(), '' ) ), has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'autentik-wide' ) : autentik_img( 'tim.jpg' ) );

// Bidang praktik yang benar-benar punya anggota (filter hanya muncul bila datanya ada).
$filters = array();
foreach ( autentik_layanan() as $l ) {
	if ( autentik_tim_for_layanan( $l->ID ) ) {
		$filters[] = $l;
	}
}
?>
<section class="bh-sec">
	<div class="wrap">
		<div class="dir-tools">
			<?php if ( $filters ) : ?>
				<div class="chips" data-dir-f role="group" aria-label="Saring anggota tim menurut layanan">
					<button type="button" class="on" data-f="" aria-pressed="true">Semua</button>
					<?php foreach ( $filters as $l ) : ?>
						<button type="button" data-f="<?php echo (int) $l->ID; ?>" aria-pressed="false"><?php echo esc_html( get_the_title( $l ) ); ?></button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<span class="dir-n" aria-live="polite"><b data-dir-n><?php echo (int) count( $tim ); ?></b> anggota tim</span>
		</div>
		<h2 class="screen-reader-text">Anggota tim</h2>
		<div class="bh-team-grid people" data-dir>
			<?php
			foreach ( $tim as $t ) {
				get_template_part( 'template-parts/person', null, array( 'p' => $t ) );
			}
			?>
		</div>
		<p class="dir-empty" data-dir-empty hidden>Belum ada anggota tim yang tercatat untuk layanan ini. <button type="button" class="more" data-dir-reset>Tampilkan Semua</button></p>
		<?php if ( $rest ) : ?>
			<div class="prose" style="margin:40px auto 0"><?php echo apply_filters( 'the_content', serialize_blocks( $rest ) ); // phpcs:ignore ?></div>
		<?php endif; ?>
	</div>
</section>
<?php
autentik_cta();
get_footer();
