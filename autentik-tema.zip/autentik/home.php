<?php
/**
 * Daftar publikasi (Halaman Pos di Pengaturan › Membaca) dan arsip kategori.
 *
 * @package Autentik
 */

get_header();

$blog_id = (int) get_option( 'page_for_posts' );
$blog    = $blog_id ? get_permalink( $blog_id ) : home_url( '/' );
if ( is_category() ) {
	$title  = 'Artikel ' . single_cat_title( '', false );
	$dek    = wp_strip_all_tags( category_description() ) ? wp_strip_all_tags( category_description() ) : 'Artikel dan panduan mengenai ' . strtolower( single_cat_title( '', false ) ) . ' yang disusun oleh tim hukum Law Firm Autentik Analitika.';
	$crumbs = array( array( 'Artikel', $blog ), array( single_cat_title( '', false ), '' ) );
} elseif ( is_archive() ) {
	$title  = wp_strip_all_tags( get_the_archive_title() );
	$dek    = '';
	$crumbs = array( array( 'Artikel', $blog ), array( $title, '' ) );
} elseif ( is_search() ) {
	$title  = 'Hasil pencarian: ' . get_search_query();
	$dek    = '';
	$crumbs = array( array( 'Artikel', $blog ), array( 'Pencarian', '' ) );
} else {
	$title  = 'Artikel dan panduan hukum';
	$dek    = 'Penjelasan mengenai pertanahan, pendirian badan usaha, dan perizinan berusaha yang disusun oleh tim hukum kami untuk pembaca umum.';
	$crumbs = array( array( 'Artikel', '' ) );
}
autentik_banner( $title, $dek, $crumbs, autentik_img( 'publikasi.jpg' ) );
?>
<section class="bh-sec">
	<div class="wrap">
		<h2 class="screen-reader-text">Daftar artikel</h2>
		<div class="art-tools">
			<nav class="chips" aria-label="Kategori">
				<a href="<?php echo esc_url( $blog ); ?>" class="<?php echo is_home() ? 'on' : ''; ?>">Semua</a>
				<?php foreach ( get_categories( array( 'hide_empty' => true, 'exclude' => get_option( 'default_category' ) ) ) as $c ) : ?>
					<a href="<?php echo esc_url( get_category_link( $c ) ); ?>" class="<?php echo is_category( $c->term_id ) ? 'on' : ''; ?>"><?php echo esc_html( $c->name ); ?></a>
				<?php endforeach; ?>
			</nav>
			<?php if ( (int) wp_count_posts()->publish >= 10 ) : ?>
			<form class="search-f" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<label class="screen-reader-text" for="cari">Cari artikel</label>
				<input id="cari" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="Cari artikel…">
				<input type="hidden" name="post_type" value="post">
				<button class="btn b-navy b-sm" type="submit" aria-label="Cari"><?php echo autentik_icon( 'search' ); // phpcs:ignore ?></button>
			</form>
			<?php endif; ?>
		</div>
		<?php if ( have_posts() ) : ?>
			<?php
			$lead = is_home() && ! is_paged();
			if ( $lead ) {
				the_post();
				autentik_post_lead( get_post() );
			}
			?>
			<div class="posts">
				<?php
				while ( have_posts() ) :
					the_post();
					autentik_post_card( get_post() );
				endwhile;
				?>
			</div>
			<div class="pager"><?php echo paginate_links( array( 'prev_text' => '‹', 'next_text' => '›' ) ); // phpcs:ignore ?></div>
		<?php else : ?>
			<p>Belum ada artikel yang sesuai. <a class="bh-more" href="<?php echo esc_url( $blog ); ?>">Lihat Semua Artikel</a></p>
		<?php endif; ?>
	</div>
</section>
<?php
autentik_cta();
get_footer();
