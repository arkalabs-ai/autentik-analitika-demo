<?php
/**
 * Halaman indeks Layanan (slug: layanan) v21: indeks editorial + alur penanganan.
 *
 * @package Autentik
 */

get_header();
the_post();
$lay   = autentik_layanan();
$tugas = autentik_layanan_tugas();
list( $h1, $dek ) = autentik_page_head( get_the_ID() );
autentik_banner( $h1, $dek, array( array( get_the_title(), '' ) ), has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'autentik-wide' ) : autentik_img( 'kenotariatan.jpg' ) );
?>
<section class="bh-sec">
	<div class="wrap">
		<h2 class="screen-reader-text">Daftar layanan</h2>
		<ol class="lay-idx">
			<?php foreach ( $lay as $p ) : ?>
				<?php $d = autentik_field( 'dek', $p->ID ) ? (string) autentik_field( 'dek', $p->ID ) : get_the_excerpt( $p ); ?>
				<li class="rv">
					<a href="<?php echo esc_url( get_permalink( $p ) ); ?>">
						<span class="im"><img src="<?php echo esc_url( autentik_layanan_img( $p->ID ) ); ?>"<?php echo autentik_srcset( autentik_layanan_img( $p->ID ), '(max-width:620px) 100vw, 260px' ); // phpcs:ignore ?> alt="" loading="lazy" width="520" height="390"></span>
						<span class="t">
							<?php if ( isset( $tugas[ $p->post_name ] ) ) : ?><span class="tg"><?php echo esc_html( $tugas[ $p->post_name ] ); ?></span><?php endif; ?>
							<b><?php echo esc_html( get_the_title( $p ) ); ?></b>
							<span class="d"><?php echo esc_html( $d ); ?></span>
							<span class="go">Lihat Layanan <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span>
						</span>
					</a>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<section class="bh-sec bh-way" id="alur" data-way>
	<div class="wrap bh-way-in">
		<header class="bh-head bh-way-h">
			<h2 class="rv">Tahapan penanganan untuk setiap layanan</h2>
			<p class="rv">Kami menyampaikan perkembangan pekerjaan pada setiap tahap, dan pekerjaan baru dimulai setelah Anda menyetujui penawaran tertulis.</p>
			<a class="btn b-gold rv" href="<?php echo esc_url( autentik_konsultasi_url() ); ?>">Jadwalkan Konsultasi <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
		</header>
		<ol class="bh-way-list">
			<?php foreach ( autentik_steps() as $i => $s ) : ?>
				<li>
					<span class="dot" aria-hidden="true"><?php echo (int) ( $i + 1 ); ?></span>
					<h3><?php echo esc_html( $s[0] ); ?></h3>
					<p><?php echo esc_html( $s[1] ); ?></p>
					<?php if ( ! empty( $s[2] ) ) : ?><p class="pegang"><b>Yang Anda terima</b><?php echo esc_html( $s[2] ); ?></p><?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>
<?php
autentik_cta();
get_footer();
