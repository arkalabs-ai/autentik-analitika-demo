/* Autentik — analitik berbasis persetujuan. Tidak ada permintaan ke Google sebelum pengunjung menekan "Izinkan". */
(function () {
	'use strict';
	var C = window.AA_AN;
	if (!C) return;
	var KEY = 'aa-consent', MAX = C.days * 864e5, loaded = false, pend = [];
	var box = document.getElementById('aa-cc');

	function state() {
		try {
			var v = JSON.parse(localStorage.getItem(KEY) || 'null');
			if (v && v.v === C.v && Date.now() - v.t < MAX) return v.s;
		} catch (e) {}
		return navigator.globalPrivacyControl ? 'denied' : null; // sinyal GPC dihormati sebagai penolakan
	}
	function save(s) { try { localStorage.setItem(KEY, JSON.stringify({ s: s, t: Date.now(), v: C.v })); } catch (e) {} }

	function load() {
		if (loaded) return;
		loaded = true;
		gtag('consent', 'update', { analytics_storage: 'granted' }); // iklan tetap "denied"
		var s = document.createElement('script');
		s.async = true;
		if (C.gtm) {
			dataLayer.push({ content_group: C.pt, practice_area: C.pa });
			dataLayer.push({ 'gtm.start': Date.now(), event: 'gtm.js' });
			s.src = 'https://www.googletagmanager.com/gtm.js?id=' + C.gtm;
		} else {
			gtag('js', new Date());
			gtag('config', C.ga4, { content_group: C.pt, allow_google_signals: false, allow_ad_personalization_signals: false, cookie_expires: 31536000 }); // cookie _ga 12 bulan, sama dengan masa persetujuan
			s.src = 'https://www.googletagmanager.com/gtag/js?id=' + C.ga4;
		}
		document.head.appendChild(s);
		pend.forEach(function (x) { send(x[0], x[1]); });
		pend = [];
	}
	function wipe() { // hapus cookie _ga* bila persetujuan dicabut
		var d = location.hostname.split('.');
		document.cookie.split(';').forEach(function (c) {
			var n = c.split('=')[0].trim();
			if (!/^_(ga|gid|gat)/.test(n)) return;
			document.cookie = n + '=;Max-Age=0;path=/';
			for (var i = 0; i < d.length - 1; i++) document.cookie = n + '=;Max-Age=0;path=/;domain=.' + d.slice(i).join('.');
		});
	}
	function decide(s) {
		save(s);
		if (box) box.hidden = true;
		if (s === 'granted') { load(); return; }
		pend = [];
		gtag('consent', 'update', { analytics_storage: 'denied' });
		wipe();
	}

	function send(name, p) {
		if (C.gtm) {
			dataLayer.push({ ev: null }); // cegah parameter event sebelumnya terbawa (penggabungan data layer GTM)
			dataLayer.push({ event: name, ev: p });
		} else {
			gtag('event', name, p);
		}
	}
	function track(name, p) {
		p = p || {};
		if (C.pa && !p.practice_area) p.practice_area = C.pa;
		var s = state();
		if (s === 'granted') send(name, p);
		else if (s === null) pend.push([name, p]); // dikirim hanya jika pengunjung mengizinkan di halaman ini
	}

	// Banner & tautan "Pengaturan cookie" (href="#pengaturan-cookie" di menu/konten mana pun)
	if (box) box.addEventListener('click', function (e) {
		var b = e.target.closest('[data-cc]');
		if (b) decide(b.getAttribute('data-cc'));
	});
	document.addEventListener('click', function (e) {
		var a = e.target.closest && e.target.closest('a[href$="#pengaturan-cookie"]');
		if (!a || !box) return;
		e.preventDefault();
		box.hidden = false;
		box.querySelector('[data-cc]').focus();
	});
	var s0 = state();
	if (s0 === 'granted') load();
	else if (s0 === null && box) box.hidden = false;
	// Tautan "/#pengaturan-cookie" dari halaman lain (mis. Kebijakan Privasi) langsung membuka pilihan.
	function fromHash() { if (box && location.hash === '#pengaturan-cookie') { box.hidden = false; box.querySelector('[data-cc]').focus(); } }
	addEventListener('hashchange', fromHash);
	fromHash();

	// ---------- Event ----------
	var path = location.pathname;
	function where(a) {
		if (a.closest('.mbar')) return 'bilah_bawah_mobile';
		if (a.matches('.wa-float')) return 'tombol_mengambang';
		if (a.closest('.topbar')) return 'topbar';
		if (a.closest('#form-konsultasi, .lp-form')) return 'formulir';
		if (a.closest('.ft, .lp-foot, footer')) return 'footer';
		if (a.closest('.cta, .bh-cta')) return 'blok_cta';
		if (a.closest('header')) return 'header';
		return 'konten';
	}
	function clean(t) { // buang email/nomor dari kata kunci (GA4 melarang PII)
		return String(t || '').replace(/\S+@\S+/g, '[email]').replace(/\+?\d[\d\s().-]{5,}\d/g, '[angka]').trim().slice(0, 80);
	}

	document.addEventListener('click', function (e) {
		var a = e.target.closest && e.target.closest('a[href], [data-print-docs], [data-dir-f] button');
		if (!a) return;
		if (a.matches('[data-print-docs]')) return track('checklist_print', {});
		if (a.matches('[data-dir-f] button')) return track('team_filter', { filter_value: a.getAttribute('data-f') ? a.textContent.trim() : 'Semua' });
		var h = a.getAttribute('href') || '';
		if (/^https:\/\/(wa\.me|api\.whatsapp\.com)\//.test(h)) {
			if (/^https:\/\/wa\.me\/\?/.test(h)) return track('share', { method: 'whatsapp', content_type: C.pt, item_id: path });
			var m = null;
			try { m = /tentang (.+?)\.?$/.exec(decodeURIComponent((h.split('text=')[1] || '').replace(/\+/g, ' '))); } catch (err) {}
			return track('click_whatsapp', { link_location: where(a), practice_area: C.pa || (m ? m[1] : ''), page_type: C.pt });
		}
		if (h.indexOf('tel:') === 0) return track('click_phone', { link_location: where(a), page_type: C.pt });
		if (h.indexOf('mailto:') === 0) return track('click_email', { link_location: where(a), page_type: C.pt });
		if (/[?&]vcard=1\b/.test(h)) return track('vcard_download', { advocate_name: C.adv || document.title });
		if (/#(form-konsultasi|daftar)$/.test(h)) return track('click_cta', { link_location: where(a), page_type: C.pt });
	}, true);

	// Formulir konsultasi: form_start → generate_lead (hanya setelah redirect ?konsultasi=ok dari kiriman peramban ini)
	var fk = document.getElementById('form-konsultasi');
	if (fk) {
		var loc = fk.elements.asal ? fk.elements.asal.value : C.pt, started = false;
		fk.addEventListener('focusin', function () { if (!started) { started = true; track('form_start', { form_location: loc }); } });
		fk.addEventListener('submit', function () {
			var b = fk.elements.bidang;
			try { sessionStorage.setItem('aa-lead', JSON.stringify({ l: loc, p: b && b.value ? b.options[b.selectedIndex].text : 'Belum yakin' })); } catch (err) {}
		});
		var st = new URLSearchParams(location.search).get('konsultasi');
		if (st === 'ok') {
			var d = null;
			try { d = JSON.parse(sessionStorage.getItem('aa-lead') || 'null'); sessionStorage.removeItem('aa-lead'); } catch (err) {}
			if (d) track('generate_lead', { form_location: d.l, practice_area: d.p, lead_channel: 'formulir' }); // muat ulang/tautan dibagikan tidak terhitung ganda
		} else if (st === 'gagal') {
			track('form_error', { form_location: loc });
		}
	}

	// Pencarian situs (?s=) — hasil dari search.php (.sr-n)
	if (document.body.classList.contains('search')) {
		var n = document.querySelector('.sr-n');
		track('search', { search_term: clean(new URLSearchParams(location.search).get('s')), search_results: n ? parseInt(n.textContent, 10) || 0 : 0 });
	}
	// Pencarian nama di direktori tim (tanpa muat ulang halaman)
	var dq = document.querySelector('[data-dir-q]'), tq, last = '';
	if (dq) dq.addEventListener('input', function () {
		clearTimeout(tq);
		tq = setTimeout(function () {
			var t = clean(dq.value);
			if (t.length > 1 && t !== last) { last = t; track('team_search', { search_term: t }); }
		}, 1200);
	});

	// Kedalaman gulir 25/50/75/90 % (halaman yang cukup panjang saja)
	var marks = [25, 50, 75, 90], tick = false;
	function depth() {
		tick = false;
		var el = document.documentElement, max = el.scrollHeight - innerHeight;
		if (max < innerHeight * 0.5) return;
		var pct = (scrollY / max) * 100;
		while (marks.length && pct >= marks[0]) track('scroll_depth', { percent_scrolled: marks.shift(), page_type: C.pt });
		if (!marks.length) removeEventListener('scroll', onScroll);
	}
	function onScroll() { if (!tick) { tick = true; requestAnimationFrame(depth); } }
	addEventListener('scroll', onScroll, { passive: true });
})();
