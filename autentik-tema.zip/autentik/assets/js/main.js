(function () {
	'use strict';

	// Menu seluler
	var burger = document.getElementById('burger');
	var nav = document.getElementById('nav');
	function closeNav() {
		if (!nav || !burger) return;
		nav.classList.remove('open');
		burger.setAttribute('aria-expanded', 'false');
		burger.setAttribute('aria-label', 'Buka menu');
	}
	if (burger && nav) {
		burger.addEventListener('click', function () {
			var open = nav.classList.toggle('open');
			burger.setAttribute('aria-expanded', open ? 'true' : 'false');
			burger.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
			if (open) { var f0 = nav.querySelector('a'); if (f0) f0.focus(); }
		});
		// Tab dari tautan terakhir kembali ke tombol menu; Shift+Tab dari tombol menu ke tautan terakhir
		document.addEventListener('keydown', function (e) {
			if (e.key !== 'Tab' || !nav.classList.contains('open')) return;
			var items = [].slice.call(nav.querySelectorAll('a,button')).filter(function (x) { return x.offsetParent; });
			var last = items[items.length - 1];
			if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); burger.focus(); }
			else if (e.shiftKey && document.activeElement === burger && last) { e.preventDefault(); last.focus(); }
		});
	}

	// Submenu "Bidang Praktik": hover/fokus di desktop (CSS), tombol panah di layar sentuh/seluler
	document.querySelectorAll('.nav .sub-t').forEach(function (b) {
		b.addEventListener('click', function () {
			var li = b.closest('.has-sub');
			var open = li.classList.toggle('open');
			b.setAttribute('aria-expanded', open ? 'true' : 'false');
		});
	});

	// Pencarian di header
	var st = document.getElementById('srchT'), sp = document.getElementById('srch');
	function closeSearch() {
		if (!st || !sp) return;
		sp.hidden = true;
		st.setAttribute('aria-expanded', 'false');
	}
	if (st && sp) {
		st.addEventListener('click', function () {
			var open = sp.hidden;
			sp.hidden = !open;
			st.setAttribute('aria-expanded', open ? 'true' : 'false');
			if (open) { closeNav(); sp.querySelector('input').focus(); }
		});
	}
	document.addEventListener('keydown', function (e) {
		if (e.key !== 'Escape') return;
		var a = document.activeElement;
		if (sp && !sp.hidden && sp.contains(a)) { closeSearch(); st.focus(); return; }
		if (nav && nav.classList.contains('open') && nav.contains(a) && !a.closest('.has-sub')) { closeNav(); burger.focus(); return; }
		var sub = a && a.closest ? a.closest('.has-sub') : null;
		if (sub) {
			sub.classList.add('esc'); sub.querySelector('a').focus();
			sub.addEventListener('focusout', function fo() { sub.classList.remove('esc'); sub.removeEventListener('focusout', fo); });
		}
		closeSearch();
		document.querySelectorAll('.nav .has-sub.open').forEach(function (li) {
			li.classList.remove('open');
			var b = li.querySelector('.sub-t'); if (b) b.setAttribute('aria-expanded', 'false');
		});
		if (!sub) closeNav();
	});

	// Direktori tim: cari nama + filter bidang praktik
	var dir = document.querySelector('[data-dir]');
	if (dir) {
		var q = document.querySelector('[data-dir-q]'), fbox = document.querySelector('[data-dir-f]');
		var nOut = document.querySelector('[data-dir-n]'), empty = document.querySelector('[data-dir-empty]');
		var f = '';
		var run = function () {
			var term = (q && q.value || '').trim().toLowerCase(), n = 0;
			dir.querySelectorAll('.person, .bh-person').forEach(function (c) {
				var ok = (!term || c.dataset.name.indexOf(term) > -1) && (!f || (' ' + c.dataset.bidang + ' ').indexOf(' ' + f + ' ') > -1);
				c.hidden = !ok; if (ok) n++;
			});
			if (nOut) nOut.textContent = n;
			if (empty) empty.hidden = n > 0;
			var u = new URL(location.href), t = (q && q.value || '').trim();
			t ? u.searchParams.set('q', t) : u.searchParams.delete('q');
			f ? u.searchParams.set('bidang', f) : u.searchParams.delete('bidang');
			history.replaceState(null, '', u);
		};
		if (q) q.addEventListener('input', run);
		if (fbox) fbox.querySelectorAll('button').forEach(function (b) {
			b.addEventListener('click', function () {
				fbox.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); x.setAttribute('aria-pressed', 'false'); });
				b.classList.add('on'); b.setAttribute('aria-pressed', 'true');
				f = b.dataset.f; run();
			});
		});
		var reset = document.querySelector('[data-dir-reset]');
		if (reset) reset.addEventListener('click', function () {
			if (q) q.value = '';
			if (fbox) { var all = fbox.querySelector('[data-f=""]'); if (all) all.click(); }
			f = ''; run();
		});
		var p0 = new URLSearchParams(location.search);
		if (q && p0.get('q')) q.value = p0.get('q');
		var b0 = fbox && p0.get('bidang') ? fbox.querySelector('[data-f="' + p0.get('bidang').replace(/\D/g, '') + '"]') : null;
		if (b0) b0.click(); else if (q && q.value) run();
	}

	// Peta: iframe Google Maps baru dimuat setelah pengunjung menekan tombol (privasi & kecepatan)
	document.querySelectorAll('[data-map]').forEach(function (b) {
		b.addEventListener('click', function () {
			var box = b.closest('.map'), fr = document.createElement('iframe');
			fr.src = b.dataset.map; fr.title = 'Peta lokasi kantor'; fr.loading = 'lazy';
			fr.referrerPolicy = 'no-referrer-when-downgrade'; fr.setAttribute('allowfullscreen', '');
			box.classList.add('live'); box.appendChild(fr); fr.focus();
		});
	});

	// Header & tombol kembali ke atas
	var hdr = document.getElementById('hdr');
	var up = document.getElementById('toTop');
	window.addEventListener('scroll', function () {
		var y = window.scrollY;
		if (hdr) hdr.classList.toggle('sc', y > 10);
		if (up) up.classList.toggle('show', y > 700);
	}, { passive: true });
	var calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
	if (up) up.addEventListener('click', function () {
		window.scrollTo({ top: 0, behavior: calm ? 'auto' : 'smooth' });
		var k = document.getElementById('konten'); if (k) { k.setAttribute('tabindex', '-1'); k.focus({ preventScroll: true }); }
	});

	// Lencana "Buka sekarang" berdasarkan jam WIB. Aturan: "1-5|09:00-17:00" (1 = Senin).
	var rule = (window.AUTENTIK && AUTENTIK.jam) || '';
	var m = rule.match(/^(\d)-(\d)\|(\d\d):(\d\d)-(\d\d):(\d\d)$/);
	if (m) {
		var pt = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Jakarta', weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
			.formatToParts(new Date()).reduce(function (o, x) { o[x.type] = x.value; return o; }, {});
		var d = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 }[pt.weekday];
		var mins = +pt.hour * 60 + +pt.minute;
		var open = d >= +m[1] && d <= +m[2] && mins >= (+m[3] * 60 + +m[4]) && mins < (+m[5] * 60 + +m[6]);
		var lagi = '';
		if (!open) {
			var HARI = ['', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'], st0 = +m[3] * 60 + +m[4];
			if (d >= +m[1] && d <= +m[2] && mins < st0) lagi = 'hari ini';
			else { var nd = d, k = 0; do { nd = nd % 7 + 1; k++; } while (nd < +m[1] || nd > +m[2]); lagi = k === 1 ? 'besok' : HARI[nd]; }
			lagi = 'Kantor sedang tutup · buka kembali ' + lagi + ' pukul ' + m[3] + '.' + m[4] + ' WIB';
		}
		document.querySelectorAll('[data-open-now]').forEach(function (el) {
			el.hidden = false;
			el.classList.toggle('on', open);
			el.querySelector('em').textContent = open ? 'Kantor sedang buka' : lagi;
		});
	}

	// Tombol WhatsApp mengambang disembunyikan saat formulir terlihat (tidak menutupi tombol kirim)
	var wa = document.querySelector('.wa-float');
	var forms = document.querySelectorAll('#form-konsultasi, .lp-form');
	if (wa && forms.length && 'IntersectionObserver' in window) {
		var seen = new Set();
		var fo = new IntersectionObserver(function (es) {
			es.forEach(function (e) { if (e.isIntersecting) seen.add(e.target); else seen.delete(e.target); });
			wa.classList.toggle('off', seen.size > 0);
		});
		forms.forEach(function (f) { fo.observe(f); });
	}

	// Masuk saat digulir: fade-up bertahap. Konten tetap terlihat tanpa JS (kelas hanya dipasang bila didukung).
	var rvs = document.querySelectorAll('.rv');
	if (rvs.length && 'IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
		document.documentElement.classList.add('js-rv');
		var rio = new IntersectionObserver(function (es) {
			var n = 0;
			es.forEach(function (e) {
				if (!e.isIntersecting) return;
				e.target.style.transitionDelay = Math.min(n++ * 90, 360) + 'ms';
				e.target.classList.add('in');
				setTimeout(function (t) { t.style.transitionDelay = ''; }, 1500, e.target);
				rio.unobserve(e.target);
			});
		}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
		rvs.forEach(function (el) { rio.observe(el); });
		window.addEventListener('beforeprint', function () { rvs.forEach(function (el) { el.classList.add('in'); }); });
	}

	// Angka menghitung naik (nilai akhir sudah ada di HTML)
	if ('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
		var io = new IntersectionObserver(function (es) {
			es.forEach(function (e) {
				if (!e.isIntersecting) return;
				io.unobserve(e.target);
				var el = e.target, to = +el.dataset.count, t0 = null;
				(function st(ts) {
					if (!t0) t0 = ts;
					var p = Math.min((ts - t0) / 1100, 1);
					el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3)));
					if (p < 1) requestAnimationFrame(st);
				})(performance.now());
			});
		}, { threshold: .6 });
		document.querySelectorAll('[data-count]').forEach(function (n) { io.observe(n); });
	}

	// Daftar isi otomatis dari H2 artikel
	var isi = document.getElementById('isi'), tocs = document.querySelectorAll('[data-toc]');
	if (!tocs.length) { var t1 = document.getElementById('toc'); if (t1) tocs = [t1]; }
	if (isi && tocs.length) {
		var hs = isi.querySelectorAll('h2');
		if (hs.length >= 3) {
			var tl = [];
			hs.forEach(function (h, i) { if (!h.id) h.id = 'bagian-' + (i + 1); });
			[].forEach.call(tocs, function (toc) {
				var ol = toc.querySelector('ol');
				hs.forEach(function (h) {
					var li = document.createElement('li'), a = document.createElement('a');
					a.href = '#' + h.id; a.textContent = h.textContent;
					li.appendChild(a); ol.appendChild(li); tl.push(a);
				});
				toc.hidden = false;
			});
			// Daftar isi aktif: bagian yang sedang dibaca ditandai
			if ('IntersectionObserver' in window) {
				var hio = new IntersectionObserver(function (es) {
					es.forEach(function (e) {
						if (!e.isIntersecting) return;
						tl.forEach(function (a) { var on = a.getAttribute('href') === '#' + e.target.id; a.classList.toggle('on', on); if (on) a.setAttribute('aria-current', 'location'); else a.removeAttribute('aria-current'); });
					});
				}, { rootMargin: '-20% 0px -70% 0px' });
				hs.forEach(function (h) { hio.observe(h); });
			}
		}
		// Bilah progres baca
		var rb = document.querySelector('.readbar span');
		if (rb) {
			var rbt = false, rbu = function () {
				rbt = false;
				var r = isi.getBoundingClientRect(), p = Math.min(Math.max((innerHeight * 0.3 - r.top) / r.height, 0), 1);
				rb.style.transform = 'scaleX(' + p.toFixed(3) + ')';
			};
			window.addEventListener('scroll', function () { if (!rbt) { rbt = true; requestAnimationFrame(rbu); } }, { passive: true });
			rbu();
		}
	}

	// Salin tautan
	document.querySelectorAll('[data-copy]').forEach(function (b) {
		b.addEventListener('click', function () {
			if (!navigator.clipboard) { window.prompt('Salin tautan ini:', b.dataset.copy); return; }
			navigator.clipboard.writeText(b.dataset.copy).then(function () {
				var t = b.lastChild.textContent; b.lastChild.textContent = 'Tersalin';
				var s = document.querySelector('[data-copy-status]'); if (s) s.textContent = (b.dataset.copyLabel || 'Tautan') + ' tersalin';
				b.classList.add('ok'); setTimeout(function () { b.classList.remove('ok'); }, 1600);
				setTimeout(function () { b.lastChild.textContent = t; }, 1600);
			});
		});
	});
	// Formulir konsultasi: isian dipulihkan bila gagal, status "Mengirim…", peringatan sebelum pergi
	var fk = document.getElementById('form-konsultasi');
	if (fk) {
		var K = 'aa-draft', qs = location.search, sb = fk.querySelector('[type=submit]'), sbTxt = sb ? sb.firstChild.textContent : '';
		var ta = fk.querySelector('textarea[name=pesan]');
		var warn = function (e) { if (ta && ta.value.trim().length > 20) { e.preventDefault(); e.returnValue = ''; } };
		window.addEventListener('beforeunload', warn);
		fk.addEventListener('submit', function () {
			window.removeEventListener('beforeunload', warn);
			try {
				var dd = {};
				fk.querySelectorAll('input[name]:not([type=hidden]):not([type=checkbox]):not([name=website]),select[name],textarea[name]').forEach(function (x) { dd[x.name] = x.value; });
				sessionStorage.setItem(K, JSON.stringify(dd));
			} catch (err) {}
			if (sb) { sb.disabled = true; sb.setAttribute('aria-busy', 'true'); sb.firstChild.textContent = 'Mengirim… '; }
		});
		window.addEventListener('pageshow', function () {
			if (sb) { sb.disabled = false; sb.removeAttribute('aria-busy'); sb.firstChild.textContent = sbTxt; }
		});
		try {
			if (/konsultasi=(gagal|wa|batas)/.test(qs)) {
				var dd = JSON.parse(sessionStorage.getItem(K) || '{}');
				Object.keys(dd).forEach(function (n) { var x = fk.elements[n]; if (x && !x.value) x.value = dd[n]; });
			}
			if (qs.indexOf('konsultasi=ok') > -1) sessionStorage.removeItem(K);
		} catch (err) {}
		// Validasi langsung di dekat isian (bukan gelembung bawaan browser)
		if (fk.hasAttribute('data-v')) {
			var cek = function (x) {
				var v = (x.value || '').trim(), ok = true;
				if (x.type === 'checkbox') ok = x.checked;
				else if (x.required && !v) ok = false;
				else if (x.name === 'wa') { var dg = v.replace(/\D/g, ''); ok = dg.length >= 9 && dg.length <= 15; }
				var e = document.getElementById(x.getAttribute('aria-describedby') || '');
				x.setAttribute('aria-invalid', ok ? 'false' : 'true');
				if (e) e.hidden = ok;
				return ok;
			};
			var wajib = fk.querySelectorAll('#aa-nama,#aa-wa,#aa-pesan,#aa-setuju');
			wajib.forEach(function (x) { x.addEventListener(x.type === 'checkbox' ? 'change' : 'blur', function () { cek(x); }); });
			fk.addEventListener('submit', function (e) {
				var bad = [].filter.call(wajib, function (x) { return !cek(x); });
				if (bad.length) {
					e.preventDefault(); e.stopImmediatePropagation(); bad[0].focus();
					if (sb) { sb.disabled = false; sb.removeAttribute('aria-busy'); sb.firstChild.textContent = sbTxt; }
				}
			}, true);
		}
	}
	var fs = document.getElementById('form-status');
	if (fs) setTimeout(function () { fs.focus({ preventScroll: true }); fs.scrollIntoView({ block: 'center' }); }, 60);
	// Setelah terkirim: hapus penanda dari URL agar muat ulang tidak menampilkan konfirmasi lagi
	if (location.search.indexOf('konsultasi=ok') > -1) {
		try { sessionStorage.removeItem('aa-draft'); var uu = new URL(location.href); uu.searchParams.delete('konsultasi'); history.replaceState(null, '', uu); } catch (err) {}
	}
	// Checklist dokumen: centang tersimpan di perangkat pengunjung; tombol cetak hanya mencetak checklist
	document.querySelectorAll('[data-checklist]').forEach(function (ul) {
		var key = ul.dataset.checklist, saved = [], cnt = document.querySelector('[data-docs-n]');
		var count = function () { if (cnt) cnt.textContent = ul.querySelectorAll('input:checked').length; };
		try { saved = JSON.parse(localStorage.getItem(key) || '[]'); } catch (err) {}
		ul.querySelectorAll('input[type=checkbox]').forEach(function (c) {
			c.checked = saved.indexOf(c.value) > -1;
			c.addEventListener('change', function () {
				var v = [].slice.call(ul.querySelectorAll('input:checked')).map(function (x) { return x.value; });
				try { localStorage.setItem(key, JSON.stringify(v)); } catch (err) {}
				count();
			});
		});
		count();
	});
	// Landing: memilih layanan mengisi formulir lalu membawa pengunjung ke formulir
	document.querySelectorAll('[data-fill]').forEach(function (b) {
		b.addEventListener('click', function () {
			var sel = document.getElementById('aa-bidang'), box = document.getElementById('daftar');
			if (sel) sel.value = b.dataset.fill;
			if (box) box.scrollIntoView({ behavior: calm ? 'auto' : 'smooth', block: 'start' });
			var nm = document.getElementById('aa-nama'); if (nm) setTimeout(function () { nm.focus({ preventScroll: true }); }, calm ? 0 : 450);
		});
	});
	// Navigasi lompat: tandai bagian yang sedang dibaca
	var spy = document.querySelector('[data-spy]');
	if (spy && 'IntersectionObserver' in window) {
		var sl = {};
		spy.querySelectorAll('a[href^="#"]').forEach(function (a) { var t = document.getElementById(a.getAttribute('href').slice(1)); if (t) sl[t.id] = a; });
		var sio = new IntersectionObserver(function (es) {
			es.forEach(function (e) {
				if (!e.isIntersecting) return;
				Object.keys(sl).forEach(function (k) { sl[k].classList.toggle('on', k === e.target.id); if (k === e.target.id) sl[k].setAttribute('aria-current', 'location'); else sl[k].removeAttribute('aria-current'); });
			});
		}, { rootMargin: '-30% 0px -60% 0px' });
		Object.keys(sl).forEach(function (k) { sio.observe(document.getElementById(k)); });
	}
	document.querySelectorAll('[data-print-docs]').forEach(function (b) {
		b.addEventListener('click', function () {
			document.body.classList.add('print-docs');
			window.print();
		});
	});
	window.addEventListener('afterprint', function () { document.body.classList.remove('print-docs'); });
	// Saat mencetak, semua tanya jawab dibuka; setelahnya dikembalikan
	var shut = [];
	window.addEventListener('beforeprint', function () { shut = [].slice.call(document.querySelectorAll('details:not([open])')); shut.forEach(function (x) { x.open = true; }); });
	window.addEventListener('afterprint', function () { shut.forEach(function (x) { x.open = false; }); shut = []; });

	// Beranda: layanan — foto & keterangan berganti mengikuti baris; pemilih usaha/pribadi; di HP baris di tengah layar aktif
	var prac = document.querySelector('[data-prac]');
	if (prac) {
		var pimg = prac.querySelectorAll('.bh-prac-media img'), pcap = prac.querySelector('[data-cap]'), pct = prac.querySelector('[data-cap-t]');
		var plinks = prac.querySelectorAll('.bh-prac-list a');
		var pset = function (a) {
			var i = a.getAttribute('data-i');
			pimg.forEach(function (im) { im.classList.toggle('on', im.getAttribute('data-i') === i); });
			plinks.forEach(function (x) { x.classList.toggle('on', x === a); });
			if (pcap) pcap.textContent = a.querySelector('.t b').textContent;
			if (pct) pct.textContent = a.dataset.t || '';
		};
		plinks.forEach(function (a, k) {
			if (!k) a.classList.add('on');
			a.addEventListener('mouseenter', function () { pset(a); });
			a.addEventListener('focus', function () { pset(a); });
		});
		var rt = prac.querySelector('.bh-router'), sout = prac.querySelector('[data-seg-out]');
		if (rt) rt.addEventListener('click', function (e) {
			var b = e.target.closest('button'); if (!b) return;
			var sg = b.dataset.seg, n = 0;
			rt.querySelectorAll('button').forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
			prac.querySelectorAll('.bh-prac-list li').forEach(function (li) {
				var ok = !sg || (' ' + li.dataset.seg + ' ').indexOf(' ' + sg + ' ') > -1;
				li.classList.toggle('dim', !ok); if (ok) n++;
			});
			var first = prac.querySelector('.bh-prac-list li:not(.dim) a'); if (first) pset(first);
			if (sout) sout.textContent = sg ? n + ' layanan ditampilkan' : 'Semua layanan ditampilkan';
		});
		// Baris di tengah layar menjadi aktif (HP dan desktop); di desktop kursor tetap bisa mengambil alih
		if ('IntersectionObserver' in window) {
			var mio = new IntersectionObserver(function (es) {
				es.forEach(function (e) { if (e.isIntersecting) pset(e.target); });
			}, { rootMargin: '-45% 0px -45% 0px' });
			plinks.forEach(function (a) { mio.observe(a); });
		}
	}

	// Cara kami bekerja: garis emas terisi mengikuti gulir, tahap yang terlewati menyala
	var way = document.querySelector('[data-way]');
	if (way && !calm) {
		var wol = way.querySelector('.bh-way-list'), wli = wol.querySelectorAll('li'), wt = false;
		document.documentElement.classList.add('js-way');
		var wup = function () {
			wt = false;
			var r = wol.getBoundingClientRect(), mid = innerHeight * 0.55;
			wol.style.setProperty('--p', Math.min(Math.max((mid - r.top) / r.height, 0), 1).toFixed(3));
			wli.forEach(function (li) { li.classList.toggle('on', li.getBoundingClientRect().top < mid); });
		};
		window.addEventListener('scroll', function () { if (!wt) { wt = true; requestAnimationFrame(wup); } }, { passive: true });
		window.addEventListener('resize', wup, { passive: true });
		wup();
	}

	// Bilah kontak HP: disembunyikan dekat formulir, ajakan penutup, dan footer
	var mbar = document.querySelector('.mbar');
	if (mbar && 'IntersectionObserver' in window) {
		var hide = new Set();
		var mo = new IntersectionObserver(function (es) {
			es.forEach(function (e) { if (e.isIntersecting) hide.add(e.target); else hide.delete(e.target); });
			mbar.classList.toggle('off', hide.size > 0);
		});
		document.querySelectorAll('.hero .acts, .bh-hero .acts, .bio-hero .acts, #form-konsultasi, .lp-form, .cta, .bh-cta, .ft, .lp-foot').forEach(function (x) { mo.observe(x); });
		document.addEventListener('focusin', function (e) { if (e.target.matches('input,textarea,select')) mbar.classList.add('kb'); });
		document.addEventListener('focusout', function () { mbar.classList.remove('kb'); });
	}
})();
