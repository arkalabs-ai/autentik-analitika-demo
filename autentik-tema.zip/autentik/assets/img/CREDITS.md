# Kredit Foto

Foto ilustrasi berlisensi (bukan foto kantor atau klien firma). Dapat diganti tanpa mengubah kode: latar ajakan konsultasi dan latar alur kerja di Tampilan › Sesuaikan › Autentik: Foto Latar & Footer; foto layanan, halaman, dan artikel lewat Gambar unggulan.

Lisensi: Unsplash License / Pexels License (bebas untuk penggunaan komersial, atribusi tidak wajib).
Diunduh 28 September 2026. Tema menyimpan turunan WebP 480/768/1024/1600 px (nama berkas di tabel tanpa akhiran .jpg = `nama-<lebar>.webp`); JPEG asli 2000 px tersimpan di riwayat repo, tidak ikut paket tema.

| Berkas | Isi | Sumber | Fotografer |
|---|---|---|---|
| hero-bg.jpg | Gedung tinggi Medan (hitam-putih, di-crop lanskap) | Pexels 37220843 | Mike Panton |
| about.jpg | Ruang rapat kayu | Unsplash _-KLkj7on_c | Dane Deaner |
| hukum.jpg | Tangan meninjau dokumen | Unsplash TFFn3BYLc5s | Van Tay Media |
| perizinan.jpg | Tangan, pensil, laptop | Unsplash 5fNmWej4tAA | Scott Graham |
| kenotariatan.jpg | Penandatanganan dokumen | Unsplash wB9iWZKwljw | Signature Pro |
| pertanahan.jpg | Foto udara permukiman & sawah, Indonesia | Unsplash kc8D-uD2jco | Ervan Sugiana |
| korporasi.jpg | Ruang rapat berdinding kaca | Unsplash 0sT9YhNgSEs | Benjamin Child |
| investasi.jpg | Crane proyek, Jakarta Pusat | Unsplash xVOygnvHsco | Iqro Rinaldi |
| kontak.jpg | Lobi modern berpanel kayu | Pexels 32674962 | Miff Ibra |
| tim.jpg | Rak perpustakaan | Unsplash OPzWvgL-upY | Giammarco Boscaro |
| kota.jpg | Jakarta saat senja | Unsplash cdsC3Q7miLQ | David Kristianto |
| publikasi.jpg | Membaca dokumen | Unsplash ecHGTPfjNfA | Anastassia Anufrieva |

Logo klien PT Adipa Karya: arsip situs resmi adipakarya.co.id (web.archive.org, 2021). Logo milik perusahaan terkait.
