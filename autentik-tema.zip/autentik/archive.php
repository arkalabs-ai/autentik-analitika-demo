<?php
defined( 'ABSPATH' ) || exit;
/**
 * Arsip (kategori/tag/tanggal) memakai tampilan daftar artikel.
 *
 * @package Autentik
 */

require __DIR__ . '/home.php';
