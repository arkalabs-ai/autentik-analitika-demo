<?php
defined( 'ABSPATH' ) || exit;
/**
 * Hasil pencarian situs, dikelompokkan: Bidang Praktik, Tim, Publikasi, Halaman.
 * (Pencarian dari halaman Publikasi — post_type=post — memakai tampilan daftar publikasi.)
 *
 * @package Autentik
 */

if ( 'post' === get_query_var( 'post_type' ) ) {
	require __DIR__ . '/home.php';
	return;
}

get_header();
$q = get_search_query();
autentik_banner( $q ? 'Hasil pencarian: ' . $q : 'Cari di situs', '', array( array( 'Pencarian', '' ) ) );

$groups = array(
	'layanan' => array( 'Layanan', array() ),
	'tim'     => array( 'Tim hukum', array() ),
	'post'    => array( 'Artikel', array() ),
	'page'    => array( 'Halaman', array() ),
);
foreach ( $GLOBALS['wp_query']->posts as $p ) {
	if ( isset( $groups[ $p->post_type ] ) && ! in_array( $p->post_name, array( 'beranda', 'konsultasi' ), true ) ) {
		$groups[ $p->post_type ][1][] = $p;
	}
}
$total = array_sum( array_map( function ( $g ) { return count( $g[1] ); }, $groups ) );
$isi   = array_filter( $groups, function ( $g ) { return (bool) $g[1]; } );
?>
<section class="sec">
	<div class="wrap">
		<form class="search-big" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="cari-situs">Cari di situs</label>
			<?php echo autentik_icon( 'search' ); // phpcs:ignore ?>
			<input id="cari-situs" type="search" name="s" value="<?php echo esc_attr( $q ); ?>" placeholder="Cari layanan, nama anggota tim, atau topik hukum…">
			<button class="btn b-navy" type="submit">Cari</button>
		</form>
		<p class="sr-n"><?php echo $total ? esc_html( $total . ' hasil ditemukan' ) : 'Tidak ada hasil untuk kata kunci tersebut. Coba kata lain, misalnya "sertifikat", "PT", atau "OSS".'; ?></p>

		<?php if ( count( $isi ) > 1 ) : // Lompat ke kelompok hasil (45 B3) ?>
			<nav class="chips sr-jump" aria-label="Kelompok hasil">
				<?php foreach ( $isi as $type => $g ) : ?><a href="#hasil-<?php echo esc_attr( $type ); ?>"><?php echo esc_html( $g[0] ); ?> <span><?php echo (int) count( $g[1] ); ?></span></a><?php endforeach; ?>
			</nav>
		<?php endif; ?>

		<?php foreach ( $isi as $type => $g ) : ?>
			<div class="sr-g" id="hasil-<?php echo esc_attr( $type ); ?>">
				<h2><?php echo esc_html( $g[0] ); ?> <span><?php echo (int) count( $g[1] ); ?></span></h2>
				<?php if ( 'tim' === $type ) : ?>
					<div class="bh-team-grid sr-tim"><?php foreach ( $g[1] as $p ) { get_template_part( 'template-parts/person', null, array( 'p' => $p ) ); } ?></div>
				<?php elseif ( 'post' === $type ) : ?>
					<div class="posts"><?php foreach ( $g[1] as $p ) { autentik_post_card( $p ); } ?></div>
				<?php else : ?>
					<ul class="sr-list">
						<?php foreach ( $g[1] as $p ) : ?>
							<?php $ex = 'layanan' === $type ? (string) autentik_field( 'dek', $p->ID ) : wp_trim_words( wp_strip_all_tags( $p->post_content ), 26, '…' ); ?>
							<li><a href="<?php echo esc_url( get_permalink( $p ) ); ?>">
								<?php if ( 'layanan' === $type ) : ?><img src="<?php echo esc_url( autentik_layanan_img( $p->ID ) ); ?>"<?php echo autentik_srcset( autentik_layanan_img( $p->ID ), '120px' ); // phpcs:ignore ?> alt="" loading="lazy" width="520" height="390"><?php endif; ?>
								<span class="t"><b><?php echo autentik_sorot( get_the_title( $p ), $q ); // phpcs:ignore -- di-escape di dalam ?></b><?php if ( $ex ) : ?><span><?php echo autentik_sorot( $ex, $q ); // phpcs:ignore ?></span><?php endif; ?></span>
							</a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>
</section>
<?php
autentik_cta();
get_footer();
