<?php
/**
 * Hasil pencarian situs, dikelompokkan: Bidang Praktik, Tim, Publikasi, Halaman.
 * (Pencarian dari halaman Publikasi — post_type=post — memakai tampilan daftar publikasi.)
 *
 * @package Autentik
 */

if ( 'post' === get_query_var( 'post_type' ) ) {
	require __DIR__ . '/home.php';
	return;
}

get_header();
$q = get_search_query();
autentik_banner( $q ? 'Hasil pencarian: ' . $q : 'Cari di situs', '', array( array( 'Pencarian', '' ) ), autentik_img( 'hukum.jpg' ) );

$groups = array(
	'layanan' => array( 'Layanan', array() ),
	'tim'     => array( 'Tim hukum', array() ),
	'post'    => array( 'Artikel', array() ),
	'page'    => array( 'Halaman', array() ),
);
foreach ( $GLOBALS['wp_query']->posts as $p ) {
	if ( isset( $groups[ $p->post_type ] ) && ! in_array( $p->post_name, array( 'beranda', 'konsultasi' ), true ) ) {
		$groups[ $p->post_type ][1][] = $p;
	}
}
$total = array_sum( array_map( function ( $g ) { return count( $g[1] ); }, $groups ) );
?>
<section class="sec">
	<div class="wrap">
		<form class="search-big" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="cari-situs">Cari di situs</label>
			<?php echo autentik_icon( 'search' ); // phpcs:ignore ?>
			<input id="cari-situs" type="search" name="s" value="<?php echo esc_attr( $q ); ?>" placeholder="Cari layanan, nama anggota tim, atau topik hukum…">
			<button class="btn b-navy" type="submit">Cari</button>
		</form>
		<p class="sr-n"><?php echo $total ? esc_html( $total . ' hasil ditemukan' ) : 'Tidak ditemukan hasil untuk kata kunci tersebut. Silakan coba kata kunci lain, misalnya "sertifikat", "PT", atau "OSS".'; ?></p>

		<?php foreach ( $groups as $type => $g ) : ?>
			<?php if ( ! $g[1] ) { continue; } ?>
			<div class="sr-g">
				<h2><?php echo esc_html( $g[0] ); ?> <span><?php echo (int) count( $g[1] ); ?></span></h2>
				<?php if ( 'tim' === $type ) : ?>
					<div class="people"><?php foreach ( $g[1] as $p ) { get_template_part( 'template-parts/team-card', null, array( 'p' => $p ) ); } ?></div>
				<?php elseif ( 'post' === $type ) : ?>
					<div class="posts"><?php foreach ( $g[1] as $p ) { autentik_post_card( $p ); } ?></div>
				<?php else : ?>
					<ul class="sr-list">
						<?php foreach ( $g[1] as $p ) : ?>
							<?php $ex = 'layanan' === $type ? (string) autentik_field( 'dek', $p->ID ) : wp_trim_words( wp_strip_all_tags( $p->post_content ), 26, '…' ); ?>
							<li><a href="<?php echo esc_url( get_permalink( $p ) ); ?>"><b><?php echo esc_html( get_the_title( $p ) ); ?></b><?php if ( $ex ) : ?><span><?php echo esc_html( $ex ); ?></span><?php endif; ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>
</section>
<?php
autentik_cta();
get_footer();
