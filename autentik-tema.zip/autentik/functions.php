<?php
/**
 * Tema Autentik — Law Firm Autentik Analitika.
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AUTENTIK_VER', '2.1.0' );
define( 'AUTENTIK_DIR', get_template_directory() );
define( 'AUTENTIK_URI', get_template_directory_uri() );

require AUTENTIK_DIR . '/inc/helpers.php';
require AUTENTIK_DIR . '/inc/customizer.php';
require AUTENTIK_DIR . '/inc/seo-geo.php';
require AUTENTIK_DIR . '/inc/form.php';
require AUTENTIK_DIR . '/inc/profesional.php';
require AUTENTIK_DIR . '/inc/halaman.php';
require AUTENTIK_DIR . '/inc/admin.php';
require AUTENTIK_DIR . '/inc/analytics.php';
require AUTENTIK_DIR . '/inc/pratinjau.php';

/**
 * Dukungan tema, menu, ukuran gambar.
 */
function autentik_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 120, 'width' => 120, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'site-icon' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor.css' );

	register_nav_menus(
		array(
			'utama'  => __( 'Menu Utama', 'autentik' ),
			'footer' => __( 'Menu Footer', 'autentik' ),
		)
	);

	add_image_size( 'autentik-card', 720, 450, true );
	add_image_size( 'autentik-wide', 1400, 700, true );
	add_image_size( 'autentik-portrait', 640, 820, true );
}
add_action( 'after_setup_theme', 'autentik_setup' );

/**
 * CSS & JS.
 */
function autentik_assets() {
	wp_enqueue_style( 'autentik', get_stylesheet_uri(), array(), AUTENTIK_VER );
	wp_enqueue_style( 'autentik-komponen', AUTENTIK_URI . '/assets/css/komponen.css', array( 'autentik' ), AUTENTIK_VER );
	wp_enqueue_script( 'autentik', AUTENTIK_URI . '/assets/js/main.js', array(), AUTENTIK_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_localize_script(
		'autentik',
		'AUTENTIK',
		array(
			'jam' => autentik_opt( 'hours_rule' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'autentik_assets' );

/**
 * Font di-host sendiri (assets/fonts): preload dua file utama agar judul & teks tidak berkedip.
 */
function autentik_preload_fonts() {
	foreach ( array( 'source-serif-4-normal-latin.woff2', 'plus-jakarta-sans-normal-latin.woff2' ) as $f ) {
		echo '<link rel="preload" href="' . esc_url( AUTENTIK_URI . '/assets/fonts/' . $f ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	}
}
add_action( 'wp_head', 'autentik_preload_fonts', 2 );

/**
 * Bersihkan <head> yang tidak perlu.
 */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );

/**
 * Panjang ringkasan artikel.
 */
add_filter( 'excerpt_length', function () { return 26; } );
add_filter( 'excerpt_more', function () { return '…'; } );

/**
 * 10 artikel per halaman di daftar artikel.
 */
function autentik_posts_per_page( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	if ( $q->is_search() && ! $q->get( 'post_type' ) ) {
		// Pencarian situs: bidang praktik, tim, publikasi, dan halaman (dikelompokkan di search.php).
		$q->set( 'post_type', array( 'layanan', 'tim', 'post', 'page' ) );
		$q->set( 'posts_per_page', 40 );
	} elseif ( $q->is_home() || $q->is_archive() || $q->is_search() ) {
		$q->set( 'posts_per_page', 9 );
	}
}
add_action( 'pre_get_posts', 'autentik_posts_per_page' );


/**
 * Favicon bawaan (emblem) bila Site Icon belum diatur di Customizer.
 */
function autentik_favicon() {
	if ( has_site_icon() ) {
		return;
	}
	echo '<link rel="icon" href="' . esc_url( autentik_img( 'favicon.png' ) ) . '" sizes="64x64">' . "
";
	echo '<link rel="apple-touch-icon" href="' . esc_url( autentik_img( 'apple-touch-icon.png' ) ) . '">' . "
";
}
add_action( 'wp_head', 'autentik_favicon', 3 );

/**
 * Konten situs berbahasa Indonesia: pastikan <html lang="id-ID"> walau Bahasa Situs belum diatur.
 */
add_filter( 'language_attributes', function ( $o ) {
	return preg_replace( '/lang="[^"]*"/', 'lang="id-ID"', $o );
} );

/**
 * CSS cetak (media="print"), dimuat paling akhir. Kop & kaki cetak diisi per halaman lewat variabel CSS.
 */
function autentik_print_assets() {
	// Prioritas 99: diantrekan setelah semua CSS tema (beranda/komponen) sehingga tercetak paling akhir.
	wp_enqueue_style( 'autentik-print', AUTENTIK_URI . '/assets/css/print.css', array( 'autentik' ), AUTENTIK_VER, 'print' );
	$css  = function ( $s ) {
		return '"' . str_replace( array( '\\', '"', '<', "\r", "\n" ), array( '\\\\', '\\"', '\\3C ', '', '\\A ' ), $s ) . '"';
	};
	$url  = function_exists( 'autentik_canonical_url' ) ? autentik_canonical_url() : '';
	$url  = $url ? $url : home_url( '/' . ltrim( (string) $GLOBALS['wp']->request, '/' ) );
	$foot = autentik_opt( 'firm' ) . ' · ' . autentik_address() . "\n"
		. 'Telepon/WhatsApp ' . autentik_opt( 'phone' ) . ' · ' . autentik_opt( 'email' ) . ' · ' . preg_replace( '#^https?://#', '', untrailingslashit( home_url() ) ) . "\n"
		. 'Informasi umum, bukan nasihat hukum. Dicetak dari: ' . $url;
	$home = untrailingslashit( home_url() );
	wp_add_inline_style(
		'autentik-print',
		':root{--aa-print-url:' . $css( $url . "\n" . 'Telepon/WhatsApp ' . autentik_opt( 'phone' ) ) . ';--aa-print-foot:' . $css( $foot ) . '}'
		. '@media print{main a[href^=' . $css( $home ) . ']::after,main a[href^="/"]::after{content:none!important}}'
	);
}
add_action( 'wp_enqueue_scripts', 'autentik_print_assets', 99 );

/**
 * Judul tab & arsip berbahasa Indonesia tanpa paket bahasa (404, pencarian, arsip, halaman ke-N) dan satu pemisah "|".
 */
function autentik_tanggal_id( $format ) {
	$bulan = array( 1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember' );
	$y     = (int) get_query_var( 'year' );
	$m     = (int) get_query_var( 'monthnum' );
	$d     = (int) get_query_var( 'day' );
	if ( 'day' === $format && $d && $m ) {
		return $d . ' ' . $bulan[ $m ] . ' ' . $y;
	}
	if ( in_array( $format, array( 'day', 'month' ), true ) && $m ) {
		return $bulan[ $m ] . ' ' . $y;
	}
	return (string) $y;
}

add_filter( 'document_title_separator', function () { return '|'; } );

add_filter( 'document_title_parts', function ( $t ) {
	if ( is_404() ) {
		$t['title'] = 'Halaman tidak ditemukan';
	} elseif ( is_search() ) {
		$t['title'] = get_search_query() ? 'Hasil pencarian: ' . get_search_query() : 'Cari di situs';
	} elseif ( is_day() ) {
		$t['title'] = 'Arsip ' . autentik_tanggal_id( 'day' );
	} elseif ( is_month() ) {
		$t['title'] = 'Arsip ' . autentik_tanggal_id( 'month' );
	} elseif ( is_year() ) {
		$t['title'] = 'Arsip ' . autentik_tanggal_id( 'year' );
	} elseif ( is_category() || is_tag() ) {
		$t['title'] = 'Artikel ' . single_term_title( '', false );
	}
	if ( isset( $t['page'] ) ) {
		$t['page'] = 'Halaman ' . max( 2, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
	}
	return $t;
} );

add_filter( 'get_the_archive_title', function ( $title ) {
	if ( is_day() ) {
		return 'Arsip ' . autentik_tanggal_id( 'day' );
	}
	if ( is_month() ) {
		return 'Arsip ' . autentik_tanggal_id( 'month' );
	}
	if ( is_year() ) {
		return 'Arsip ' . autentik_tanggal_id( 'year' );
	}
	if ( is_category() || is_tag() || is_tax() ) {
		return single_term_title( '', false );
	}
	if ( is_author() ) {
		return 'Tulisan ' . get_the_author();
	}
	if ( is_post_type_archive() ) {
		return post_type_archive_title( '', false );
	}
	return $title;
} );

/**
 * Bangun ulang aturan URL saat tema diaktifkan (mencegah 404 pada halaman & bidang praktik setelah impor).
 */
add_action( 'after_switch_theme', 'flush_rewrite_rules' );
