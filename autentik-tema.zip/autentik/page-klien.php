<?php
defined( 'ABSPATH' ) || exit;
/**
 * Halaman Klien (slug: klien): dinding logo klien + sektor usaha.
 *
 * @package Autentik
 */

get_header();
the_post();
$kl = autentik_klien();
list( $h1, $dek ) = autentik_page_head( get_the_ID() );
autentik_banner( $h1, $dek, array( array( get_the_title(), '' ) ) );
$sektor = array(
	array( 'building', 'Konstruksi', 'Kontrak proyek, perizinan, dan sengketa pekerjaan konstruksi.' ),
	array( 'chart', 'Energi', 'Legalitas usaha, perizinan, dan tata kelola perusahaan.' ),
	array( 'map', 'Transportasi & Logistik', 'Perjanjian kerja sama, pengadaan armada, dan izin operasional.' ),
	array( 'layers', 'Industri & Perdagangan', 'Pendirian badan usaha, perizinan melalui OSS, dan telaah kontrak.' ),
);
?>
<?php if ( $kl ) : ?>
<section class="sec">
	<div class="wrap">
		<h2 class="screen-reader-text">Klien kami</h2>
		<ul class="lg-wall lg-page">
			<?php foreach ( $kl as $k ) { autentik_klien_tile( $k ); } ?>
		</ul>
		<p class="note lg-note"><?php echo autentik_icon( 'info' ); // phpcs:ignore ?><span>Setiap logo merupakan milik perusahaan yang bersangkutan. Isi perkara dan dokumen klien tidak kami ungkapkan kepada pihak mana pun.</span></p>
	</div>
</section>
<?php endif; ?>

<section class="sec <?php echo $kl ? 'alt' : ''; ?>">
	<div class="wrap">
		<div class="split-h">
			<?php autentik_sh( '', 'Sektor usaha yang kami dampingi', '', true ); ?>
			<p class="rv">Lain sektor, lain pula dokumen, izin, dan risikonya. Satu hal tidak berubah: isi perkara dan dokumen setiap klien kami rahasiakan.</p>
		</div>
		<ul class="cards sectors">
			<?php foreach ( $sektor as $sk ) : ?>
				<li class="box rv"><span class="ic"><?php echo autentik_icon( $sk[0] ); // phpcs:ignore ?></span><h3><?php echo esc_html( $sk[1] ); ?></h3><p><?php echo esc_html( $sk[2] ); ?></p></li>
			<?php endforeach; ?>
		</ul>
		<p class="kl-izin rv"><?php echo autentik_icon( 'shield' ); // phpcs:ignore ?><span>Nama dan logo klien hanya kami tampilkan setelah klien yang bersangkutan memberikan izin tertulis.</span></p>
	</div>
</section>
<?php
autentik_cta();
get_footer();
