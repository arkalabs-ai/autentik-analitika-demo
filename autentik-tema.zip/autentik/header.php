<?php
/**
 * Header.
 *
 * @package Autentik
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#konten">Langsung ke konten utama</a>

<?php if ( ! is_page_template( 'page-templates/landing.php' ) ) : ?>
<header class="hdr" id="hdr">
	<div class="wrap">
		<?php get_template_part( 'template-parts/brand' ); ?>
		<nav class="nav" id="nav" aria-label="Menu utama">
			<?php
			if ( has_nav_menu( 'utama' ) ) {
				wp_nav_menu( array( 'theme_location' => 'utama', 'container' => false, 'depth' => 2 ) );
			} else {
				$is_lay = is_page( 'layanan' ) || is_singular( 'layanan' );
				echo '<ul>';
				echo '<li><a href="' . esc_url( home_url( '/tentang-kami/' ) ) . '"' . ( is_page( 'tentang-kami' ) ? ' aria-current="page"' : '' ) . '>Tentang Kami</a></li>';
				echo '<li class="has-sub"><a href="' . esc_url( home_url( '/layanan/' ) ) . '"' . ( $is_lay ? ' aria-current="page"' : '' ) . '>Layanan</a>';
				echo '<button type="button" class="sub-t" aria-expanded="false" aria-label="Tampilkan daftar layanan">' . autentik_icon( 'chev' ) . '</button>'; // phpcs:ignore
				echo '<div class="sub"><ul>';
				$tugas = autentik_layanan_tugas();
				foreach ( autentik_layanan() as $p ) {
					$tg = isset( $tugas[ $p->post_name ] ) ? $tugas[ $p->post_name ] : '';
					echo '<li><a href="' . esc_url( get_permalink( $p ) ) . '"' . ( is_single( $p->ID ) ? ' aria-current="page"' : '' ) . '><b>' . esc_html( get_the_title( $p ) ) . '</b>' . ( $tg ? '<small>' . esc_html( $tg ) . '</small>' : '' ) . '</a></li>';
				}
				echo '</ul><a class="all" href="' . esc_url( home_url( '/layanan/' ) ) . '">Semua Layanan →</a></div></li>';
				foreach ( array(
					array( 'Tim Kami', '/tim/', is_page( 'tim' ) || is_singular( 'tim' ) ),
					array( 'Artikel', '/artikel/', is_home() || is_singular( 'post' ) || is_category() ),
					array( 'Klien', '/klien/', is_page( 'klien' ) ),
					array( 'Kontak', '/kontak/', is_page( 'kontak' ) ),
				) as $l ) {
					echo '<li><a href="' . esc_url( home_url( $l[1] ) ) . '"' . ( $l[2] ? ' aria-current="page"' : '' ) . '>' . esc_html( $l[0] ) . '</a></li>';
				}
				echo '</ul>';
			}
			?>
		</nav>
		<button type="button" class="srch-t" id="srchT" aria-label="Cari di situs" aria-controls="srch" aria-expanded="false"><?php echo autentik_icon( 'search' ); // phpcs:ignore ?></button>
		<a class="btn b-navy b-sm hdr-cta" href="<?php echo esc_url( home_url( '/kontak/' ) ); ?>">Jadwalkan Konsultasi</a>
		<button type="button" class="burger" id="burger" aria-label="Buka menu" aria-controls="nav" aria-expanded="false"><span class="bl" aria-hidden="true"><i></i><i></i><i></i></span></button>
	</div>
	<div class="srch" id="srch" hidden>
		<form class="wrap" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="srch-q">Cari di situs</label>
			<?php echo autentik_icon( 'search' ); // phpcs:ignore ?>
			<input id="srch-q" type="search" name="s" placeholder="Cari layanan, nama anggota tim, atau topik hukum…" autocomplete="off">
			<button class="btn b-navy b-sm" type="submit">Cari</button>
		</form>
	</div>
</header>
<?php else : ?>
<header class="lp-hdr">
	<div class="wrap">
		<?php get_template_part( 'template-parts/brand' ); ?>
		<a class="btn b-wa b-sm" href="<?php echo esc_url( autentik_wa( 'Halo, Law Firm Autentik Analitika. Saya ingin menjadwalkan konsultasi hukum.' ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?><span class="lg"><?php echo esc_html( autentik_opt( 'phone' ) ); ?></span><span class="sm">WhatsApp</span></a>
	</div>
</header>
<?php endif; ?>

<main id="konten">
