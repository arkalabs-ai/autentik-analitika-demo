<?php
/**
 * Logo + nama firma.
 *
 * @package Autentik
 */

$logo_id = get_theme_mod( 'custom_logo' );
?>
<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( autentik_opt( 'firm' ) ); ?>, Beranda">
	<?php if ( $logo_id ) : ?>
		<?php echo wp_get_attachment_image( $logo_id, 'medium', false, array( 'alt' => '' ) ); ?>
	<?php else : ?>
		<img src="<?php echo esc_url( autentik_img( 'logo-96.webp' ) ); ?>"<?php echo autentik_srcset( autentik_img( 'logo-96.webp' ), '(max-width:760px) 92vw, 50vw' ); // phpcs:ignore ?> alt="" width="46" height="46">
	<?php endif; ?>
	<span translate="no"><b>Autentik Analitika</b><small lang="en">Law Firm · Medan</small></span>
</a>
