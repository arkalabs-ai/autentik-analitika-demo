<?php
/**
 * Kartu anggota tim (direktori potret). data-* dipakai filter & pencarian di halaman Tim.
 *
 * @package Autentik
 */

$p      = $args['p'];
$role   = (string) autentik_field( 'jabatan', $p->ID );
$bidang = autentik_layanan_for_tim( $p->ID );
?>
<a class="person rv" href="<?php echo esc_url( get_permalink( $p ) ); ?>" data-name="<?php echo esc_attr( strtolower( autentik_plain_title( $p ) ) ); ?>" data-bidang="<?php echo esc_attr( implode( ' ', wp_list_pluck( $bidang, 'ID' ) ) ); ?>">
	<span class="ph">
		<?php if ( has_post_thumbnail( $p ) ) : ?>
			<?php echo get_the_post_thumbnail( $p, 'autentik-portrait', array( 'alt' => '', 'loading' => 'lazy' ) ); ?>
		<?php else : ?>
			<span class="ini" aria-hidden="true"><?php echo esc_html( autentik_initials( get_the_title( $p ) ) ); ?></span>
		<?php endif; ?>
	</span>
	<span class="rl"><?php echo esc_html( $role ); ?></span>
	<h3><?php echo esc_html( get_the_title( $p ) ); ?></h3>
	<span class="dg"><?php echo esc_html( (string) autentik_field( 'gelar', $p->ID ) ); ?></span>
	<?php $kg = autentik_lines( autentik_field( 'keanggotaan', $p->ID ) ); ?>
	<?php if ( $kg ) : ?><span class="kg"><?php echo esc_html( $kg[0] ); ?></span><?php endif; ?>
	<?php if ( $bidang ) : ?>
		<span class="bd"><?php echo esc_html( implode( ' · ', array_map( 'get_the_title', array_slice( $bidang, 0, 2 ) ) ) ); ?></span>
	<?php endif; ?>
</a>
