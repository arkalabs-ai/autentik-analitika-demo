<?php
/**
 * Kartu anggota tim (v21): potret 4:5 tersingkap, jabatan, nama, gelar, bidang selalu tampil.
 * data-* dipakai filter & pencarian di halaman Tim.
 *
 * @package Autentik
 */

$p  = $args['p'];
$bd = autentik_layanan_for_tim( $p->ID );
?>
<a class="bh-person rv" href="<?php echo esc_url( get_permalink( $p ) ); ?>" data-name="<?php echo esc_attr( strtolower( autentik_plain_title( $p ) ) ); ?>" data-bidang="<?php echo esc_attr( implode( ' ', wp_list_pluck( $bd, 'ID' ) ) ); ?>">
	<span class="ph">
		<?php if ( has_post_thumbnail( $p ) ) : ?>
			<?php echo get_the_post_thumbnail( $p, 'autentik-portrait', array( 'alt' => '', 'loading' => 'lazy', 'sizes' => '(max-width:980px) 46vw, 270px' ) ) . autentik_demo_tag( $p ); // phpcs:ignore ?>
		<?php else : ?>
			<span class="ini" aria-hidden="true"><?php echo esc_html( autentik_initials( get_the_title( $p ) ) ); ?></span>
		<?php endif; ?>
		<span class="hv">Lihat Profil <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span>
	</span>
	<span class="rl"><?php echo esc_html( (string) autentik_field( 'jabatan', $p->ID ) ); ?></span>
	<h3><?php echo esc_html( get_the_title( $p ) ); ?></h3>
	<span class="dg"><?php echo esc_html( (string) autentik_field( 'gelar', $p->ID ) ); ?></span>
	<?php if ( $bd ) : ?><span class="bd"><?php echo esc_html( implode( ' · ', array_map( 'get_the_title', array_slice( $bd, 0, 2 ) ) ) ); ?></span><?php endif; ?>
</a>
