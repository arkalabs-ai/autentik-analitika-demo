=== Autentik ===
Contributors: ARKA LABS
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Version: 2.6.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Tema kustom company profile + landing page untuk Law Firm Autentik Analitika, Medan.

== Deskripsi ==

Tema klasik (bukan tema blok) bernuansa navy–emas dengan CMS artikel, jenis konten Layanan/Tim/Klien
(dari plugin "Autentik — Jenis Konten"), formulir konsultasi, schema SEO & GEO bawaan, dan analitik
berbasis persetujuan. Situs satu bahasa (Indonesia): terjemahan penuh (i18n) sengaja tidak disiapkan.

Wajib: plugin "Autentik — Jenis Konten" dan "Secure Custom Fields". Panduan pasang: PANDUAN-PASANG.md.

Bagian yang memang berada di tema (bukan plugin) karena khusus situs ini: schema/llms.txt/robots,
analitik, formulir konsultasi, dan tampilan halaman login.

== Pengaturan ==

Tampilan › Sesuaikan:
* Autentik: Kontak & Lokasi — telepon, WhatsApp, alamat, jam kerja, peta.
* Autentik: Legalitas — nama firma (dipakai di seluruh situs), nomor pendaftaran, NIB, NPWP.
* Autentik: Beranda — judul, foto pimpinan, empat fakta, teks Tentang Kami.
* Autentik: Foto Latar & Footer — latar ajakan konsultasi, latar alur kerja, deskripsi footer.
* Analitik & Verifikasi — GA4/GTM, Search Console, Bing.

== Changelog ==

= 2.6.1 =
* CSS dipecah per templat: style.css berisi aturan global, assets/css/<templat>.css dimuat hanya di templatnya
  (dibuat dengan wordpress/_uji/pecah-css.py; urutan kaskade dicek di DOM dan tangkapan layar identik).
* Font serif miring di-preload di beranda & landing; animasi foto masuk di HP lebih singkat.
* Dasbor: info pesan tertua & tanggal hapus otomatis.

= 2.6.0 =
* Sisa audit qa/45 dan 46g/46c: judul seksi beranda, hasil pencarian, kartu legalitas HP, nama firma
  dari Customizer, foto latar & fakta beranda dapat diedit, validasi Customizer, widget "Siap tayang?",
  paket tema tanpa JPEG asli.

= 2.5.0 =
* Desain halaman dalam: penutup CTA tiga bentuk, kartu konsultasi lengket, Tentang Kami berfoto,
  kartu tim 4+3, tata letak tablet tiga kolom.

= 2.4.0 =
* Perbaikan audit multi-peran 46 (SEO, keamanan, performa, aksesibilitas, etika, CRO).

== Kredit ==

* Source Serif 4 (Adobe) dan Plus Jakarta Sans (Tokotype) — SIL Open Font License 1.1, di-host sendiri.
* Foto ilustrasi — Unsplash/Pexels License; rincian di assets/img/CREDITS.md.
