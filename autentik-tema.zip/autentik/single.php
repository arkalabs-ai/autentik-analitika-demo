<?php
/**
 * Detail artikel (v21, mode baca): banner bermeta, daftar isi di atas (HP) dan lengket (desktop),
 * bilah progres baca, kartu layanan terkait di dalam artikel, penulis & peninjau, penafian.
 *
 * @package Autentik
 */

get_header();
while ( have_posts() ) :
	the_post();
	$id   = get_the_ID();
	$cats = get_the_category();
	$cat  = $cats ? $cats[0] : null;
	$blog = get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/artikel/' );
	$lay  = autentik_post_layanan( $id );
	list( $by, $rev ) = autentik_post_people( $id );
	$img  = has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'autentik-wide' ) : ( $lay ? autentik_layanan_img( $lay->ID, 'autentik-wide' ) : autentik_img( 'hukum.jpg' ) );
	$tim_nama = 'Tim Hukum Autentik Analitika';

	$crumbs = array( array( 'Artikel', $blog ) );
	if ( $cat ) {
		$crumbs[] = array( $cat->name, get_category_link( $cat ) );
	}
	$crumbs[] = array( get_the_title(), '' );
	?>
	<div class="readbar" aria-hidden="true"><span></span></div>
	<section class="ban ban2 ban-art">
		<div class="wrap ban-in">
			<div class="ban-t">
				<?php autentik_breadcrumb( $crumbs ); ?>
				<h1><?php the_title(); ?></h1>
				<div class="meta-row">
					<span><?php echo autentik_icon( 'user' ); // phpcs:ignore ?><?php if ( $by ) : ?>Ditulis oleh <a href="<?php echo esc_url( get_permalink( $by ) ); ?>"><?php echo esc_html( get_the_title( $by ) ); ?></a><?php else : ?><?php echo esc_html( $tim_nama ); ?><?php endif; ?></span>
					<?php if ( $rev ) : ?>
						<span><?php echo autentik_icon( 'check' ); // phpcs:ignore ?>Ditinjau oleh <a href="<?php echo esc_url( get_permalink( $rev ) ); ?>"><?php echo esc_html( get_the_title( $rev ) ); ?></a></span>
					<?php endif; ?>
					<span><?php echo autentik_icon( 'cal' ); // phpcs:ignore ?><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time></span>
					<?php if ( get_the_modified_date( 'Ymd' ) !== get_the_date( 'Ymd' ) ) : ?>
						<span><?php echo autentik_icon( 'clock' ); // phpcs:ignore ?>Diperbarui <?php echo esc_html( get_the_modified_date( 'j F Y' ) ); ?></span>
					<?php endif; ?>
					<span><?php echo autentik_icon( 'file' ); // phpcs:ignore ?><?php echo (int) autentik_read_minutes( $id ); ?> menit baca</span>
				</div>
			</div>
			<figure class="ban-ph" aria-hidden="true"><img class="bg" src="<?php echo esc_url( $img ); ?>"<?php echo autentik_srcset( $img, '(max-width:760px) 100vw, 42vw' ); // phpcs:ignore ?> alt="" width="1000" height="667" fetchpriority="high"></figure>
		</div>
	</section>

	<section class="bh-sec">
		<div class="wrap dt dt2 art">
			<article class="dt-main">
				<nav class="toc toc-m" data-toc hidden aria-label="Daftar isi"><b>Daftar isi</b><ol></ol></nav>
				<div class="prose" id="isi"><?php the_content(); ?></div>

				<?php if ( $lay ) : ?>
					<aside class="art-lay" aria-label="Layanan terkait">
						<span class="im"><img src="<?php echo esc_url( autentik_layanan_img( $lay->ID ) ); ?>"<?php echo autentik_srcset( autentik_layanan_img( $lay->ID ), '(max-width:620px) 100vw, 220px' ); // phpcs:ignore ?> alt="" loading="lazy" width="440" height="330"></span>
						<span class="t">
							<small>Layanan terkait</small>
							<b><?php echo esc_html( get_the_title( $lay ) ); ?></b>
							<span><?php echo esc_html( autentik_field( 'dek', $lay->ID ) ? (string) autentik_field( 'dek', $lay->ID ) : get_the_excerpt( $lay ) ); ?></span>
							<span class="acts">
								<a class="btn b-navy b-sm" href="<?php echo esc_url( autentik_konsultasi_url( $lay->post_name ) ); ?>">Jadwalkan Konsultasi</a>
								<a class="bh-more" href="<?php echo esc_url( get_permalink( $lay ) ); ?>">Lihat Layanan <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
							</span>
						</span>
					</aside>
				<?php endif; ?>

				<div class="share">
					<b>Bagikan</b>
					<a class="btn b-line b-sm" href="<?php echo esc_url( 'https://wa.me/?text=' . rawurlencode( autentik_plain_title() . ' — ' . get_permalink() ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>WhatsApp</a>
					<button class="btn b-line b-sm" type="button" data-copy="<?php echo esc_url( get_permalink() ); ?>" data-copy-label="Tautan"><?php echo autentik_icon( 'link' ); // phpcs:ignore ?>Salin Tautan</button>
					<span class="screen-reader-text" aria-live="polite" data-copy-status></span>
				</div>

				<?php foreach ( array_filter( array( $by, $rev && ( ! $by || $rev->ID !== $by->ID ) ? $rev : null ) ) as $n => $person ) : ?>
					<a class="author" href="<?php echo esc_url( get_permalink( $person ) ); ?>">
						<?php echo autentik_avatar( $person, 'thumbnail', 'i' ); // phpcs:ignore ?>
						<div><small><?php echo $by && $person->ID === $by->ID ? 'Penulis' : 'Peninjau hukum'; ?></small><b><?php echo esc_html( get_the_title( $person ) ); ?><?php echo autentik_field( 'gelar', $person->ID ) ? ', ' . esc_html( (string) autentik_field( 'gelar', $person->ID ) ) : ''; ?></b><p><?php echo esc_html( autentik_field( 'jabatan', $person->ID ) ? (string) autentik_field( 'jabatan', $person->ID ) . ', ' . autentik_opt( 'firm' ) : autentik_opt( 'firm' ) ); ?></p></div>
					</a>
				<?php endforeach; ?>
				<?php if ( ! $by && ! $rev ) : ?>
					<div class="author">
						<span class="i"><?php echo esc_html( autentik_initials( 'Autentik Analitika' ) ); ?></span>
						<div><small>Penulis</small><b><?php echo esc_html( $tim_nama ); ?></b><p>Kantor Medan Baru, <?php echo esc_html( autentik_opt( 'city' ) ); ?></p></div>
					</div>
				<?php endif; ?>
				<p class="disc">Artikel ini merupakan informasi umum dan bukan nasihat hukum atas perkara tertentu. Peraturan dapat berubah sewaktu-waktu. Karena itu, konsultasikan keadaan Anda dengan advokat sebelum mengambil keputusan.</p>
			</article>

			<aside class="side">
				<nav class="toc box" id="toc" data-toc hidden aria-label="Daftar isi"><b>Daftar isi</b><ol></ol></nav>
				<?php $others = get_posts( array( 'numberposts' => 3, 'exclude' => array( $id ) ) ); ?>
				<?php if ( $others ) : ?>
					<div class="box">
						<h3>Artikel lainnya</h3>
						<div class="relp">
							<?php foreach ( $others as $o ) : ?>
								<a href="<?php echo esc_url( get_permalink( $o ) ); ?>"><?php echo autentik_post_img_tag( $o, 'thumbnail', '64px' ); // phpcs:ignore ?><b><?php echo esc_html( get_the_title( $o ) ); ?></b></a>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
				<div class="help">
					<h3>Menghadapi persoalan serupa?</h3>
					<p>Sampaikan keadaan Anda kepada kami. Kami akan membantu menelaahnya sebelum Anda mengambil langkah hukum.</p>
					<a class="btn b-gold" href="<?php echo esc_url( autentik_konsultasi_url() ); ?>">Jadwalkan Konsultasi</a>
					<a class="btn b-line" href="<?php echo esc_url( autentik_wa( autentik_wa_pesan() ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>Hubungi lewat WhatsApp</a>
				</div>
			</aside>
		</div>
	</section>
	<?php
endwhile;
autentik_cta();
get_footer();
