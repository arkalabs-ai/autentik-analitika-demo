<?php
/**
 * Cadangan.
 *
 * @package Autentik
 */

require __DIR__ . '/home.php';
