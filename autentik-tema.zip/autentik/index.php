<?php
defined( 'ABSPATH' ) || exit;
/**
 * Cadangan.
 *
 * @package Autentik
 */

require __DIR__ . '/home.php';
