<?php
/**
 * Beranda v21 (qa/34): 10 seksi, satu momen gerak per layar.
 * Hero → Klien (berizin) → Layanan + pemilih → Tentang & legalitas terbuka → Cara kami bekerja
 * → Tim → Artikel & panduan → Tanya jawab → CTA penutup.
 * Gaya: assets/css/komponen.css (global).
 *
 * @package Autentik
 */

get_header();

$title = esc_html( autentik_opt( 'hero_title' ) );
$title = preg_replace( '/\*(.+?)\*/', '<em>$1</em>', $title );
$bg    = autentik_opt( 'hero_bg' ) ? autentik_opt( 'hero_bg' ) : autentik_img( 'kota.jpg' );
$tokoh = autentik_opt( 'hero_person' );
$lay   = autentik_layanan();
$tim   = autentik_tim_publik();
$lead  = null;
foreach ( $tim as $t ) {
	if ( autentik_field( 'pimpinan', $t->ID ) ) {
		$lead = $t;
		break;
	}
}
$lead_role = $lead ? implode( ' · ', array_filter( array( (string) autentik_field( 'jabatan', $lead->ID ), (string) autentik_field( 'gelar', $lead->ID ) ) ) ) : '';
$blog_url  = get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/artikel/' );
?>

<section class="bh-hero">
	<div class="bh-hero-bg" aria-hidden="true"><img src="<?php echo esc_url( $bg ); ?>"<?php echo autentik_srcset( $bg, '100vw' ); // phpcs:ignore ?> alt="" width="2000" height="1333" decoding="async"></div>
	<div class="wrap bh-hero-in">
		<div class="bh-hero-copy">
			<h1><?php echo $title; // phpcs:ignore -- sudah di-escape, hanya <em> ditambahkan ?></h1>
			<p class="bh-lead"><?php echo esc_html( autentik_opt( 'hero_text' ) ); ?></p>
			<div class="acts">
				<a class="btn b-gold" href="<?php echo esc_url( autentik_konsultasi_url() ); ?>">Jadwalkan Konsultasi <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
				<a class="tl" href="<?php echo esc_url( home_url( '/layanan/' ) ); ?>">Lihat Layanan <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
				<a class="tl tl-wa" href="<?php echo esc_url( autentik_wa() ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>WhatsApp</a>
			</div>
		</div>

		<figure class="bh-hero-ph">
			<span class="bh-frame" aria-hidden="true"></span>
			<?php
			$alt = $lead ? autentik_plain_title( $lead ) : autentik_opt( 'firm' );
			if ( $tokoh ) {
				$tokoh_id = attachment_url_to_postid( $tokoh );
				echo $tokoh_id
					? wp_get_attachment_image( $tokoh_id, 'large', false, array( 'alt' => $alt, 'sizes' => '(max-width: 980px) 100vw, 430px', 'fetchpriority' => 'high' ) ) . autentik_demo_tag( $tokoh_id ) // phpcs:ignore
					: '<img src="' . esc_url( $tokoh ) . '" alt="' . esc_attr( $alt ) . '" width="520" height="700" fetchpriority="high">';
			} elseif ( $lead && has_post_thumbnail( $lead ) ) {
				echo get_the_post_thumbnail( $lead, 'autentik-portrait', array( 'alt' => $alt, 'fetchpriority' => 'high' ) ) . autentik_demo_tag( $lead ); // phpcs:ignore
			} else {
				echo '<span class="ini" aria-hidden="true">' . esc_html( autentik_initials( $lead ? get_the_title( $lead ) : autentik_opt( 'firm' ) ) ) . '</span>';
			}
			?>
			<?php if ( $lead ) : ?>
				<figcaption class="bh-plate"><b><?php echo esc_html( get_the_title( $lead ) ); ?></b><span><?php echo esc_html( $lead_role ); ?></span></figcaption>
			<?php endif; ?>
		</figure>
	</div>

	<div class="bh-facts">
		<ul class="wrap">
			<li><b>1 hari kerja</b><span>Batas waktu kami menanggapi pesan Anda</span></li>
			<li><b>Biaya disepakati di awal</b><span>Lingkup, jangka waktu, dan biaya dituangkan secara tertulis sebelum pekerjaan dimulai</span></li>
			<li><b><?php echo (int) count( $lay ); ?> bidang layanan</b><span>Hukum bisnis, perizinan berusaha, badan usaha, dan pertanahan</span></li>
			<li><b>Kantor di Medan Baru</b><span>Konsultasi tatap muka di kantor kami</span></li>
		</ul>
	</div>
</section>

<?php $kl_logo = array_values( array_filter( autentik_klien(), 'has_post_thumbnail' ) ); ?>
<?php if ( count( $kl_logo ) >= 4 ) : ?>
<section class="bh-trust" aria-labelledby="trust-h">
	<div class="wrap">
		<h2 id="trust-h">Klien kami dari sektor konstruksi, energi, transportasi, dan industri di Sumatera Utara</h2>
		<ul class="lg-wall">
			<?php foreach ( array_slice( $kl_logo, 0, 6 ) as $k ) { autentik_klien_tile( $k ); } ?>
		</ul>
		<a class="bh-more" href="<?php echo esc_url( home_url( '/klien/' ) ); ?>">Lihat Semua Klien <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
	</div>
</section>
<?php endif; ?>

<?php if ( $lay ) : ?>
<?php
$seg_map = array( 'hukum' => 'u p', 'perizinan' => 'u', 'kenotariatan' => 'u', 'korporasi' => 'u', 'pertanahan' => 'p', 'investasi-properti' => 'p u' );
$tugas   = autentik_layanan_tugas();
?>
<section class="bh-sec bh-prac" data-prac id="layanan">
	<div class="wrap bh-prac-in">
		<div class="bh-prac-media" aria-hidden="true">
			<?php foreach ( $lay as $i => $p ) : ?>
				<img class="<?php echo 0 === $i ? 'on' : ''; ?>" data-i="<?php echo (int) $i; ?>" src="<?php echo esc_url( autentik_layanan_img( $p->ID ) ); ?>"<?php echo autentik_srcset( autentik_layanan_img( $p->ID ), '(max-width:980px) 1px, 40vw' ); // phpcs:ignore ?> alt="" loading="lazy" width="1000" height="667">
			<?php endforeach; ?>
			<span class="bh-prac-cap"><b data-cap><?php echo esc_html( get_the_title( $lay[0] ) ); ?></b><span data-cap-t><?php echo esc_html( isset( $tugas[ $lay[0]->post_name ] ) ? $tugas[ $lay[0]->post_name ] : '' ); ?></span></span>
		</div>
		<div class="bh-prac-list">
			<header class="bh-head">
				<h2 class="rv">Layanan untuk pelaku usaha dan perorangan</h2>
				<p class="rv">Kebutuhan hukum perusahaan dan keluarga umumnya berbeda, baik dari segi dokumen maupun instansi yang terkait. Apabila Anda belum yakin persoalan Anda termasuk bidang yang mana, silakan sampaikan kepada kami.</p>
			</header>
			<div class="bh-router" role="group" aria-label="Saring layanan menurut jenis klien">
				<button type="button" data-seg="" aria-pressed="true">Semua Layanan</button>
				<button type="button" data-seg="u" aria-pressed="false">Pelaku Usaha &amp; Perusahaan</button>
				<button type="button" data-seg="p" aria-pressed="false">Perorangan &amp; Keluarga</button>
			</div>
			<p class="screen-reader-text" aria-live="polite" data-seg-out></p>
			<ol>
				<?php foreach ( $lay as $i => $p ) : ?>
					<?php $dek = autentik_field( 'dek', $p->ID ) ? (string) autentik_field( 'dek', $p->ID ) : get_the_excerpt( $p ); ?>
					<li data-seg="<?php echo esc_attr( isset( $seg_map[ $p->post_name ] ) ? $seg_map[ $p->post_name ] : 'u p' ); ?>">
						<a href="<?php echo esc_url( get_permalink( $p ) ); ?>" data-i="<?php echo (int) $i; ?>" data-t="<?php echo esc_attr( isset( $tugas[ $p->post_name ] ) ? $tugas[ $p->post_name ] : '' ); ?>">
							<img class="th" src="<?php echo esc_url( autentik_layanan_img( $p->ID ) ); ?>"<?php echo autentik_srcset( autentik_layanan_img( $p->ID ), '72px' ); // phpcs:ignore ?> alt="" loading="lazy" width="72" height="72">
							<span class="t"><b><?php echo esc_html( get_the_title( $p ) ); ?></b><span><?php echo esc_html( $dek ); ?></span></span>
							<?php echo autentik_icon( 'arrow', 'go' ); // phpcs:ignore ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ol>
		</div>
	</div>
</section>
<?php endif; ?>

<section class="bh-sec bh-alt bh-about">
	<div class="wrap bh-about-in">
		<div class="bh-about-t">
			<h2 class="rv">Tentang firma kami</h2>
			<p class="rv"><?php echo esc_html( autentik_opt( 'about_text' ) ); ?></p>
			<?php if ( $lead && autentik_opt( 'quote_text' ) ) : ?>
				<figure class="bh-quote rv">
					<blockquote><?php echo esc_html( autentik_opt( 'quote_text' ) ); ?></blockquote>
					<figcaption>
						<?php echo autentik_avatar( $lead, 'thumbnail', 'f' ); // phpcs:ignore ?>
						<span><b><?php echo esc_html( get_the_title( $lead ) ); ?></b><?php echo esc_html( $lead_role ); ?></span>
					</figcaption>
				</figure>
			<?php endif; ?>
			<div class="acts rv">
				<a class="btn b-navy" href="<?php echo esc_url( home_url( '/tentang-kami/' ) ); ?>">Profil Kami <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
				<a class="btn b-line" href="<?php echo esc_url( home_url( '/tim/' ) ); ?>">Lihat Tim Kami</a>
			</div>
		</div>
		<div class="bh-legal rv" id="legalitas-firma">
			<div class="bh-legal-in">
				<h3>Legalitas firma</h3>
				<p class="sub">Firma kami berdiri pada <?php echo esc_html( autentik_opt( 'founded' ) ); ?>. Data legalitas berikut kami cantumkan agar dapat Anda periksa sendiri pada instansi yang berwenang.</p>
				<dl>
					<?php if ( autentik_opt( 'sk' ) ) : ?><div><dt>Nomor pendaftaran Kementerian Hukum</dt><dd><?php echo esc_html( autentik_opt( 'sk' ) ); ?></dd><button type="button" class="cp" data-copy="<?php echo esc_attr( autentik_opt( 'sk' ) ); ?>" data-copy-label="Nomor pendaftaran">Salin</button></div><?php endif; ?>
					<?php if ( autentik_opt( 'nib' ) ) : ?><div><dt>NIB</dt><dd><?php echo esc_html( autentik_opt( 'nib' ) ); ?></dd><button type="button" class="cp" data-copy="<?php echo esc_attr( autentik_opt( 'nib' ) ); ?>" data-copy-label="NIB">Salin</button></div><?php endif; ?>
					<?php if ( autentik_opt( 'npwp' ) ) : ?><div><dt>NPWP</dt><dd><?php echo esc_html( autentik_opt( 'npwp' ) ); ?></dd><span></span></div><?php endif; ?>
					<div><dt>Berdiri</dt><dd><?php echo esc_html( autentik_opt( 'founded' ) ); ?>, Medan Baru</dd><span></span></div>
					<div><dt>Kantor</dt><dd><?php echo esc_html( autentik_address() ); ?></dd><a class="cp" href="<?php echo esc_url( autentik_opt( 'maps' ) ); ?>" target="_blank" rel="noopener">Petunjuk Arah</a></div>
				</dl>
				<p class="bh-legal-f"><a class="bh-more" href="https://ahu.go.id/" target="_blank" rel="noopener">Periksa di AHU Online <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a></p>
				<span class="screen-reader-text" aria-live="polite" data-copy-status></span>
			</div>
		</div>
	</div>
</section>

<section class="bh-sec bh-way" id="alur" data-way>
	<div class="bh-way-bg" aria-hidden="true"><img src="<?php echo esc_url( autentik_img( 'tim.jpg' ) ); ?>"<?php echo autentik_srcset( autentik_img( 'tim.jpg' ), '(max-width:760px) 480px, 1024px' ); // phpcs:ignore ?> alt="" loading="lazy" width="2000" height="1333"></div>
	<div class="wrap bh-way-in">
		<header class="bh-head bh-way-h">
			<h2 class="rv">Cara kami bekerja</h2>
			<p class="rv">Kami menyampaikan perkembangan pekerjaan pada setiap tahap, dan pekerjaan baru dimulai setelah Anda menyetujui penawaran tertulis.</p>
			<a class="btn b-gold rv" href="<?php echo esc_url( autentik_konsultasi_url() ); ?>">Jadwalkan Konsultasi <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
		</header>
		<ol class="bh-way-list">
			<?php foreach ( autentik_steps() as $i => $s ) : ?>
				<li>
					<span class="dot" aria-hidden="true"><?php echo (int) ( $i + 1 ); ?></span>
					<h3><?php echo esc_html( $s[0] ); ?></h3>
					<p><?php echo esc_html( $s[1] ); ?></p>
					<?php if ( ! empty( $s[2] ) ) : ?><p class="pegang"><b>Yang Anda terima</b><?php echo esc_html( $s[2] ); ?></p><?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<?php if ( $tim ) : ?>
<section class="bh-sec bh-team">
	<div class="wrap">
		<header class="bh-head bh-head-split">
			<h2 class="rv">Tim hukum kami</h2>
			<a class="bh-more rv" href="<?php echo esc_url( home_url( '/tim/' ) ); ?>">Lihat Seluruh Tim <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
		</header>
		<div class="bh-team-grid">
			<?php foreach ( array_slice( $tim, 0, 4 ) as $t ) { get_template_part( 'template-parts/person', null, array( 'p' => $t ) ); } ?>
		</div>
	</div>
</section>
<?php endif; ?>

<?php
$posts = get_posts( array( 'numberposts' => 3 ) );
if ( $posts ) :
	usort( $posts, function ( $a, $b ) { return (int) is_sticky( $b->ID ) - (int) is_sticky( $a->ID ); } );
	$first = array_shift( $posts );
	$fcat  = get_the_category( $first->ID );
	preg_match_all( '#<h2[^>]*>(.*?)</h2>#si', (string) get_post_field( 'post_content', $first->ID ), $hh );
	$peek  = array_slice( array_map( function ( $h ) { return preg_replace( '/^\d+[.)]\s*/', '', wp_strip_all_tags( $h ) ); }, $hh[1] ), 0, 3 );
	$n_all = count( $hh[1] );
	list( $p_by, $p_rev ) = autentik_post_people( $first->ID );
	?>
<section class="bh-sec bh-alt bh-posts">
	<div class="wrap">
		<header class="bh-head bh-head-split">
			<h2 class="rv">Artikel dan panduan hukum</h2>
			<a class="bh-more rv" href="<?php echo esc_url( $blog_url ); ?>">Semua Artikel <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
		</header>
		<div class="bh-posts-grid">
			<a class="bh-feat rv" href="<?php echo esc_url( get_permalink( $first ) ); ?>">
				<?php echo autentik_post_img_tag( $first, 'autentik-wide', '(max-width:980px) 100vw, 58vw' ); // phpcs:ignore ?>
				<span class="t">
					<span class="m"><?php echo esc_html( ( $fcat ? $fcat[0]->name . ' · ' : '' ) . get_the_date( 'j F Y', $first ) . ' · ' . autentik_read_minutes( $first->ID ) . ' menit baca' ); ?></span>
					<b><?php echo esc_html( get_the_title( $first ) ); ?></b>
					<?php if ( count( $peek ) === 3 ) : ?>
						<ol class="bh-peek">
							<?php foreach ( $peek as $h ) : ?>
								<li><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8.5l3 3 7-7"/></svg><span><?php echo esc_html( $h ); ?></span></li>
							<?php endforeach; ?>
						</ol>
						<span class="go"><?php echo $n_all > 3 ? 'Baca ' . (int) ( $n_all - 3 ) . ' Bagian Lainnya' : 'Baca Artikel'; ?> <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span>
					<?php else : ?>
						<span class="x"><?php echo esc_html( get_the_excerpt( $first ) ); ?></span>
						<span class="go">Baca Artikel <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span>
					<?php endif; ?>
					<?php if ( $p_by ) : ?><span class="m">Ditulis oleh <?php echo esc_html( get_the_title( $p_by ) ); ?><?php echo $p_rev ? ' · ditinjau oleh ' . esc_html( get_the_title( $p_rev ) ) : ''; ?></span><?php endif; ?>
				</span>
			</a>
			<div class="bh-side">
				<?php foreach ( $posts as $p ) : ?>
					<?php $c = get_the_category( $p->ID ); ?>
					<a class="bh-row rv" href="<?php echo esc_url( get_permalink( $p ) ); ?>">
						<?php echo autentik_post_img_tag( $p, 'autentik-card', '(max-width:620px) 96px, 180px' ); // phpcs:ignore ?>
						<span class="t">
							<span class="m"><?php echo esc_html( ( $c ? $c[0]->name . ' · ' : '' ) . get_the_date( 'j F Y', $p ) ); ?></span>
							<b><?php echo esc_html( get_the_title( $p ) ); ?></b>
							<span class="go">Baca Artikel <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span>
						</span>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>

<?php $faq = array_slice( (array) autentik_faq_from_page( (int) get_option( 'page_on_front' ) ), 0, 5 ); ?>
<?php if ( $faq ) : ?>
<section class="bh-sec bh-faq">
	<div class="wrap faq-wrap">
		<div class="bh-faq-h">
			<h2 class="rv">Pertanyaan yang sering diajukan</h2>
			<p>Mengenai biaya jasa hukum, kerahasiaan, dan siapa yang menangani perkara Anda.</p>
			<p class="ask2">Belum menemukan jawaban yang Anda cari? <a href="<?php echo esc_url( autentik_wa( 'Halo, Law Firm Autentik Analitika. Saya ingin mengajukan pertanyaan.' ) ); ?>" target="_blank" rel="noopener">Ajukan Pertanyaan lewat WhatsApp</a></p>
		</div>
		<div><?php autentik_faq_html( $faq ); ?></div>
	</div>
</section>
<?php endif; ?>

<?php
autentik_cta();
get_footer();
