<?php
/**
 * Template Name: Landing Page (konsultasi)
 * Template Post Type: page
 *
 * Halaman fokus konsultasi untuk trafik iklan (v21): tanpa menu, formulir langsung terlihat di layar pertama HP,
 * daftar layanan yang mengisi formulir, alur penanganan, tanya jawab, penafian iklan.
 *
 * @package Autentik
 */

get_header();
the_post();
list( $h1, $dek, $rest ) = autentik_page_head( get_the_ID(), 'Konsultasi hukum bisnis, perizinan, dan *pertanahan* di Medan', 'Sampaikan persoalan hukum Anda melalui formulir ini. Tim hukum kami di Medan akan menanggapi paling lambat satu hari kerja.' );
$h1     = preg_replace( '/\*(.+?)\*/', '<em>$1</em>', esc_html( $h1 ) );
$faq    = autentik_faq_from_page( get_the_ID() );
$rest   = array_values( array_filter( $rest, function ( $b ) { return 'core/details' !== $b['blockName']; } ) );
$tim    = autentik_tim_publik();
$tugas  = autentik_layanan_tugas();
$bg     = autentik_img( 'kota.jpg' );
$pimpin = null;
foreach ( $tim as $t ) {
	if ( autentik_field( 'pimpinan', $t->ID ) ) {
		$pimpin = $t;
		break;
	}
}
$tel = preg_replace( '/\D+/', '', autentik_opt( 'phone' ) );
?>
<section class="lp2">
	<div class="lp2-bg" aria-hidden="true"><img src="<?php echo esc_url( $bg ); ?>"<?php echo autentik_srcset( $bg, '(max-width:760px) 480px, 1024px' ); // phpcs:ignore ?> alt="" width="2000" height="1333" fetchpriority="high"></div>
	<div class="wrap lp2-in">
		<div class="lp2-t">
			<h1><?php echo $h1; // phpcs:ignore -- di-escape, hanya <em> ?></h1>
			<p class="lead"><?php echo esc_html( $dek ); ?></p>
		</div>
		<div class="lp-form lp2-form" id="daftar">
			<h2>Jadwalkan Konsultasi</h2>
			<p class="sub">Uraikan pokok persoalan Anda secara singkat. Kami akan menanggapi paling lambat satu hari kerja.</p>
			<?php autentik_form( 'landing', true ); ?>
			<p class="lp2-call">Lebih nyaman menelepon? <a href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo esc_html( autentik_opt( 'phone' ) ); ?></a></p>
		</div>
		<div class="lp2-proof">
			<ul class="lp2-checks">
				<li><?php echo autentik_icon( 'check' ); // phpcs:ignore ?>Lingkup pekerjaan, jangka waktu, dan biaya disampaikan secara tertulis sejak awal</li>
				<li><?php echo autentik_icon( 'check' ); // phpcs:ignore ?>Berkoordinasi dengan notaris dan PPAT yang berwenang</li>
				<li><?php echo autentik_icon( 'check' ); // phpcs:ignore ?>Terdaftar di Kementerian Hukum RI (<?php echo esc_html( autentik_opt( 'sk' ) ); ?>)</li>
			</ul>
			<?php if ( $pimpin ) : ?>
				<figure class="lp-lead">
					<?php echo autentik_avatar( $pimpin, 'autentik-portrait', 'f' ); // phpcs:ignore ?>
					<figcaption><b><?php echo esc_html( get_the_title( $pimpin ) ); ?></b><span><?php echo esc_html( implode( ' · ', array_filter( array( (string) autentik_field( 'jabatan', $pimpin->ID ), (string) autentik_field( 'gelar', $pimpin->ID ) ) ) ) ); ?></span><a href="<?php echo esc_url( home_url( '/tim/' ) ); ?>">Lihat <?php echo (int) count( $tim ); ?> anggota tim hukum kami</a></figcaption>
				</figure>
			<?php endif; ?>
		</div>
	</div>
</section>

<section class="bh-sec">
	<div class="wrap">
		<header class="bh-head">
			<h2 class="rv">Enam bidang layanan bagi perusahaan dan perorangan</h2>
			<p class="rv">Pilih layanan yang sesuai dengan persoalan Anda, dan formulir di atas akan terisi secara otomatis.</p>
		</header>
		<ul class="lp2-lay">
			<?php foreach ( autentik_layanan() as $p ) : ?>
				<li><button type="button" data-fill="<?php echo esc_attr( get_the_title( $p ) ); ?>"><b><?php echo esc_html( get_the_title( $p ) ); ?></b><span><?php echo esc_html( isset( $tugas[ $p->post_name ] ) ? $tugas[ $p->post_name ] : '' ); ?></span><?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></button></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="bh-sec bh-way" data-way>
	<div class="wrap bh-way-in">
		<header class="bh-head bh-way-h">
			<h2 class="rv">Empat tahap penanganan</h2>
			<p class="rv">Kami menyampaikan perkembangan pada setiap tahap. Pekerjaan baru dimulai setelah Anda menyetujui penawaran tertulis.</p>
			<a class="btn b-gold rv" href="#daftar">Isi Formulir <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
		</header>
		<ol class="bh-way-list">
			<?php foreach ( autentik_steps() as $i => $s ) : ?>
				<li><span class="dot" aria-hidden="true"><?php echo (int) ( $i + 1 ); ?></span><h3><?php echo esc_html( $s[0] ); ?></h3><p><?php echo esc_html( $s[1] ); ?></p></li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<?php if ( $faq ) : ?>
<section class="bh-sec">
	<div class="wrap faq-wrap">
		<div class="bh-faq-h"><h2 class="rv">Pertanyaan yang sering diajukan sebelum berkonsultasi</h2></div>
		<div><?php autentik_faq_html( $faq ); ?></div>
	</div>
</section>
<?php endif; ?>

<section class="bh-cta lp2-cta">
	<div class="wrap bh-cta-in">
		<div class="rv">
			<h2>Ingin menghubungi kami lewat WhatsApp?</h2>
			<p>Silakan kirim pesan singkat. Tim kami menanggapi pada jam kerja, <?php echo esc_html( autentik_opt( 'hours' ) ); ?>.</p>
			<div class="acts">
				<a class="btn b-gold" href="<?php echo esc_url( autentik_wa( 'Halo, Law Firm Autentik Analitika. Saya ingin mengajukan pertanyaan sebelum menjadwalkan konsultasi.' ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>Hubungi lewat WhatsApp</a>
				<a class="btn b-line" href="#daftar">Jadwalkan Konsultasi</a>
			</div>
		</div>
	</div>
</section>

<?php if ( $rest ) : ?>
<section class="lp2-legal">
	<div class="wrap"><?php echo apply_filters( 'the_content', serialize_blocks( $rest ) ); // phpcs:ignore ?></div>
</section>
<?php endif; ?>
<?php
get_footer();
