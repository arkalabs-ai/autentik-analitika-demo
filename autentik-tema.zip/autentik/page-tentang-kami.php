<?php
/**
 * Halaman Tentang Kami (slug: tentang-kami).
 * Isi tetap diedit di editor blok; setiap Heading 2 menjadi satu bagian yang ditata sesuai isinya:
 * paragraf → profil + fakta firma, paragraf tebal → pernyataan (visi), daftar bernomor → komitmen,
 * daftar → nilai, tabel → legalitas. Bagian lain tampil sebagai teks biasa.
 *
 * @package Autentik
 */

get_header();
the_post();
list( $h1, $dek, $rest ) = autentik_page_head( get_the_ID() );
autentik_banner( $h1, $dek, array( array( get_the_title(), '' ) ), has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'autentik-wide' ) : autentik_img( 'korporasi.jpg' ) );

$secs  = autentik_sections( $rest );
$intro = false;
$alt   = false;
foreach ( $secs as $sec ) :
	$kind = autentik_section_kind( $sec );
	if ( 'text' === $kind && ! $intro ) {
		$kind  = 'intro';
		$intro = true;
	}

	if ( 'intro' === $kind ) :
		?>
		<section class="sec ab-intro">
			<div class="wrap">
				<div class="txt rv">
					<?php if ( $sec['title'] ) : ?><h2 class="screen-reader-text"><?php echo esc_html( $sec['title'] ); ?></h2><?php endif; ?>
					<div class="prose lead-first"><?php echo autentik_render_blocks( $sec['blocks'] ); // phpcs:ignore ?></div>
				</div>
				<aside class="facts rv" aria-label="Ringkasan firma">
					<dl>
						<div><dt>Berdiri</dt><dd><?php echo esc_html( autentik_opt( 'founded' ) ); ?></dd></div>
						<div><dt>Kantor</dt><dd><?php echo esc_html( trim( str_replace( 'Kecamatan', '', autentik_opt( 'district' ) ) ) . ', ' . trim( str_replace( 'Kota', '', autentik_opt( 'city' ) ) ) ); ?></dd></div>
						<div><dt>Layanan</dt><dd><a href="<?php echo esc_url( home_url( '/layanan/' ) ); ?>"><?php echo (int) count( autentik_layanan() ); ?> bidang layanan</a></dd></div>
						<div><dt>Tim</dt><dd><a href="<?php echo esc_url( home_url( '/tim/' ) ); ?>"><?php echo (int) count( autentik_tim_publik() ); ?> anggota tim hukum</a></dd></div>
						<div><dt>Terdaftar di</dt><dd>Kementerian Hukum RI<small><?php echo esc_html( autentik_opt( 'sk' ) ); ?></small></dd></div>
					</dl>
				</aside>
			</div>
		</section>
		<?php
		$pendiri = null;
		foreach ( autentik_tim_publik() as $t ) {
			if ( autentik_field( 'pimpinan', $t->ID ) ) {
				$pendiri = $t;
				break;
			}
		}
		if ( $pendiri ) :
			$bio = (string) autentik_field( 'bio', $pendiri->ID );
			?>
			<section class="sec alt ab-founder">
				<div class="wrap">
					<figure class="ph rv">
						<?php if ( has_post_thumbnail( $pendiri ) ) : ?>
							<?php echo get_the_post_thumbnail( $pendiri, 'autentik-portrait', array( 'alt' => get_the_title( $pendiri ), 'loading' => 'lazy' ) ) . autentik_demo_tag( $pendiri ); // phpcs:ignore ?>
						<?php else : ?>
							<span class="ini" aria-hidden="true"><?php echo esc_html( autentik_initials( get_the_title( $pendiri ) ) ); ?></span>
						<?php endif; ?>
					</figure>
					<div class="txt rv">
						<h2><?php echo esc_html( get_the_title( $pendiri ) ); ?></h2>
						<p class="role"><?php echo esc_html( implode( ' · ', array_filter( array( (string) autentik_field( 'jabatan', $pendiri->ID ), (string) autentik_field( 'gelar', $pendiri->ID ) ) ) ) ); ?></p>
						<p><?php echo esc_html( $bio ? $bio : get_the_title( $pendiri ) . ' mendirikan ' . autentik_opt( 'firm' ) . ' pada ' . autentik_opt( 'founded' ) . ' di Medan Baru.' ); ?></p>
						<a class="btn b-line" href="<?php echo esc_url( get_permalink( $pendiri ) ); ?>">Lihat Profil <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
					</div>
				</div>
			</section>
			<?php
		endif;

	elseif ( 'statement' === $kind ) :
		$paras = array_values( $sec['blocks'] );
		?>
		<section class="quote ab-state">
			<img src="<?php echo esc_url( autentik_img( 'tim.jpg' ) ); ?>"<?php echo autentik_srcset( autentik_img( 'tim.jpg' ), '(max-width:760px) 92vw, 50vw' ); // phpcs:ignore ?> alt="" loading="lazy">
			<div class="wrap rv">
				<?php if ( $sec['title'] ) : ?><h2 class="st-h"><?php echo esc_html( $sec['title'] ); ?></h2><?php endif; ?>
				<blockquote><?php echo esc_html( trim( wp_strip_all_tags( $paras[0]['innerHTML'] ) ) ); ?></blockquote>
			</div>
		</section>
		<?php

	elseif ( 'num' === $kind || 'vals' === $kind ) :
		$list  = null;
		$other = array();
		foreach ( $sec['blocks'] as $b ) {
			if ( ! $list && 'core/list' === $b['blockName'] ) {
				$list = $b;
			} else {
				$other[] = $b;
			}
		}
		$items = autentik_li_parts( render_block( $list ) );
		$alt   = ! $alt;
		?>
		<section class="sec <?php echo $alt ? 'alt ' : ''; ?>ab-<?php echo esc_attr( $kind ); ?>">
			<div class="wrap">
				<div class="split-h">
					<?php autentik_sh( '', $sec['title'], '', true ); ?>
					<?php if ( $other ) : ?><div class="rv"><?php echo autentik_render_blocks( $other ); // phpcs:ignore ?></div><?php endif; ?>
				</div>
				<div class="ab-items">
					<?php foreach ( $items as $i => $it ) : ?>
						<div class="it rv">
							<?php if ( $it[0] ) : ?><h3><?php echo esc_html( $it[0] ); ?></h3><?php endif; ?>
							<p><?php echo esc_html( $it[2] ); ?></p>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
		<?php

	elseif ( 'legal' === $kind ) :
		$rows  = array();
		$other = array();
		foreach ( $sec['blocks'] as $b ) {
			if ( 'core/table' === $b['blockName'] ) {
				$rows = array_merge( $rows, autentik_table_rows( render_block( $b ) ) );
			} else {
				$other[] = $b;
			}
		}
		?>
		<section class="sec ab-legal">
			<div class="wrap">
				<div class="rv">
					<h2><?php echo esc_html( $sec['title'] ); ?></h2>
					<?php if ( $other ) : ?>
						<div class="prose"><?php echo autentik_render_blocks( $other ); // phpcs:ignore ?></div>
					<?php else : ?>
						<p>Data legalitas firma sebagaimana tercatat dalam dokumen resmi. Kami mencantumkannya agar Anda dapat memeriksanya sendiri.</p>
					<?php endif; ?>
					<p><a class="bh-more" href="https://ahu.go.id/" target="_blank" rel="noopener">Periksa di AHU Online <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a></p>
				</div>
				<dl class="legal-card rv">
					<?php foreach ( $rows as $r ) : ?>
						<div><dt><?php echo esc_html( $r[0] ); ?></dt><dd><?php echo esc_html( $r[1] ); ?></dd></div>
					<?php endforeach; ?>
				</dl>
			</div>
		</section>
		<?php

	else :
		?>
		<section class="sec">
			<div class="wrap">
				<div class="prose ab-prose">
					<?php if ( $sec['title'] ) : ?><h2><?php echo esc_html( $sec['title'] ); ?></h2><?php endif; ?>
					<?php echo autentik_render_blocks( $sec['blocks'] ); // phpcs:ignore ?>
				</div>
			</div>
		</section>
		<?php
	endif;
endforeach;

$tim = array_slice( autentik_tim_publik(), 0, 4 );
if ( $tim ) :
	?>
<section class="bh-sec bh-alt">
	<div class="wrap">
		<header class="bh-head bh-head-split">
			<h2 class="rv">Tim hukum kami</h2>
			<a class="bh-more rv" href="<?php echo esc_url( home_url( '/tim/' ) ); ?>">Lihat Seluruh Tim <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
		</header>
		<div class="bh-team-grid">
			<?php foreach ( $tim as $t ) { get_template_part( 'template-parts/person', null, array( 'p' => $t ) ); } ?>
		</div>
	</div>
</section>
<?php endif; ?>
<?php
autentik_cta();
get_footer();
