<?php
/**
 * Halaman tidak ditemukan: kotak cari + daftar layanan ringkas.
 *
 * @package Autentik
 */

get_header();
autentik_banner( 'Halaman tidak ditemukan', 'Alamat halaman yang Anda tuju mungkin telah berubah atau tidak tersedia lagi. Silakan gunakan kolom pencarian, pilih salah satu layanan di bawah ini, atau hubungi kami secara langsung.', array( array( 'Halaman tidak ditemukan', '' ) ) );
$tugas = autentik_layanan_tugas();
?>
<section class="bh-sec">
	<div class="wrap">
		<form class="nf-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label for="nf-q">Cari di situs</label>
			<div><input id="nf-q" type="search" name="s" placeholder="Contoh: balik nama sertifikat, NIB, pendirian PT"><button class="btn b-navy" type="submit">Cari</button></div>
		</form>
		<h2 class="nf-h">Layanan kami</h2>
		<ul class="lp2-lay">
			<?php foreach ( autentik_layanan() as $p ) : ?>
				<li><a href="<?php echo esc_url( get_permalink( $p ) ); ?>"><b><?php echo esc_html( get_the_title( $p ) ); ?></b><span><?php echo esc_html( isset( $tugas[ $p->post_name ] ) ? $tugas[ $p->post_name ] : '' ); ?></span><?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
<?php
autentik_cta();
get_footer();
