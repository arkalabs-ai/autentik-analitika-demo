<?php
/**
 * Detail layanan.
 *
 * @package Autentik
 */

get_header();
while ( have_posts() ) :
	the_post();
	$id      = get_the_ID();
	$dek     = autentik_field( 'dek', $id ) ? (string) autentik_field( 'dek', $id ) : get_the_excerpt();
	$lingkup = autentik_rows( 'lingkup', array( 'teks', 'teks_en' ), $id );
	$dokumen = autentik_rows( 'dokumen', array( 'teks' ), $id );
	$waktu   = autentik_rows( 'waktu', array( 'tahap', 'durasi' ), $id );
	$faq     = autentik_rows( 'faq', array( 'tanya', 'jawab' ), $id );
	$map     = array_flip( autentik_cat_to_layanan() );
	$slug    = get_post_field( 'post_name', $id );
	$cat     = isset( $map[ $slug ] ) ? get_category_by_slug( $map[ $slug ] ) : null;
	$related = $cat ? get_posts( array( 'category' => $cat->term_id, 'numberposts' => 3 ) ) : array();
	$kontak  = autentik_tim_for_layanan( $id );
	$pengal  = autentik_lines( autentik_field( 'pengalaman', $id ) );

	autentik_banner( get_the_title(), $dek, array( array( 'Layanan', home_url( '/layanan/' ) ), array( get_the_title(), '' ) ), autentik_layanan_img( $id, 'autentik-wide' ) );
	$jump = array_filter( array(
		'lingkup' => $lingkup ? 'Lingkup' : '',
		'pengalaman' => $pengal ? 'Pengalaman' : '',
		'dokumen' => $dokumen ? 'Dokumen' : '',
		'waktu'   => $waktu ? 'Perkiraan Waktu' : '',
		'faq'     => $faq ? 'Tanya Jawab' : '',
	) );
	?>
	<?php if ( count( $jump ) > 1 ) : ?>
		<nav class="jump" aria-label="Bagian halaman" data-spy><div class="wrap"><ul>
			<?php foreach ( $jump as $a => $l ) : ?><li><a href="#<?php echo esc_attr( $a ); ?>"><?php echo esc_html( $l ); ?></a></li><?php endforeach; ?>
			<li class="jcta"><a href="<?php echo esc_url( autentik_konsultasi_url() ); ?>">Jadwalkan Konsultasi</a></li>
		</ul></div></nav>
	<?php endif; ?>
	<section class="bh-sec">
		<div class="wrap dt dt2">
			<div class="dt-main">
				<?php if ( autentik_field( 'jawaban_singkat', $id ) ) : ?>
					<p class="answer rv"><?php echo esc_html( (string) autentik_field( 'jawaban_singkat', $id ) ); ?></p>
				<?php endif; ?>
				<?php if ( autentik_field( 'paragraf', $id ) ) : ?>
					<p class="dt-lead"><?php echo esc_html( (string) autentik_field( 'paragraf', $id ) ); ?></p>
				<?php endif; ?>

				<?php if ( $lingkup ) : ?>
					<h2 id="lingkup"><?php echo esc_html( autentik_field( 'judul_lingkup', $id ) ? (string) autentik_field( 'judul_lingkup', $id ) : 'Lingkup pekerjaan' ); ?></h2>
					<ul class="scope">
						<?php foreach ( $lingkup as $r ) : ?>
							<li><span class="ck"><?php echo autentik_icon( 'check' ); // phpcs:ignore ?></span><div><b><?php echo esc_html( $r['teks'] ); ?></b></div></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>

				<?php if ( $pengal ) : ?>
					<h2 id="pengalaman">Pengalaman penanganan</h2>
					<ul class="exp">
						<?php foreach ( $pengal as $l ) : ?><li><?php echo esc_html( $l ); ?></li><?php endforeach; ?>
					</ul>
					<p class="note"><?php echo autentik_icon( 'info' ); // phpcs:ignore ?><span>Nama klien tidak kami sebutkan demi menjaga kerahasiaan. Hasil setiap perkara bergantung pada fakta dan proses hukumnya masing-masing.</span></p>
				<?php endif; ?>

				<?php if ( $dokumen ) : ?>
					<div class="doc-block" id="dokumen">
					<h2>Dokumen yang perlu disiapkan</h2>
					<p class="print-only">Daftar dokumen: <?php echo esc_html( get_the_title() ); ?> · <?php echo esc_html( autentik_opt( 'firm' ) ); ?> · <?php echo esc_html( autentik_opt( 'phone' ) ); ?></p>
					<p class="docs-n" aria-live="polite"><b data-docs-n>0</b> dari <?php echo (int) count( $dokumen ); ?> dokumen sudah Anda siapkan</p>
					<ul class="docs" data-checklist="<?php echo esc_attr( 'aa-cek-' . $id ); ?>">
						<?php foreach ( $dokumen as $i => $r ) : ?>
							<li><label><input type="checkbox" value="<?php echo (int) $i; ?>"><span><?php echo esc_html( $r['teks'] ); ?></span></label></li>
						<?php endforeach; ?>
					</ul>
					<p class="note"><?php echo autentik_icon( 'info' ); // phpcs:ignore ?><span>Dokumen tidak harus lengkap pada konsultasi pertama. Kami akan memberi tahu dokumen yang masih diperlukan.</span></p>
					<div class="tools">
						<button class="btn b-line b-sm" type="button" data-print-docs><?php echo autentik_icon( 'print' ); // phpcs:ignore ?>Cetak Daftar</button>
						<a class="btn b-wa b-sm" href="<?php echo esc_url( autentik_wa( 'Halo, Law Firm Autentik Analitika. Saya ingin berkonsultasi mengenai ' . autentik_plain_title() . '. Dokumen yang sudah saya miliki: ' ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>Hubungi lewat WhatsApp</a>
					</div>
					</div>
				<?php endif; ?>

				<?php if ( $waktu ) : ?>
					<h2 id="waktu">Perkiraan waktu</h2>
					<dl class="times">
						<?php foreach ( $waktu as $r ) : ?>
							<div><dt><?php echo esc_html( $r['tahap'] ); ?></dt><dd><?php echo esc_html( $r['durasi'] ); ?></dd></div>
						<?php endforeach; ?>
					</dl>
					<p class="note"><?php echo autentik_icon( 'info' ); // phpcs:ignore ?><span>Jangka waktu di atas merupakan perkiraan umum. Waktu sebenarnya bergantung pada kelengkapan dokumen dan proses di instansi terkait, dan akan kami tegaskan dalam penawaran tertulis.</span></p>
				<?php endif; ?>

				<h2 id="alur">Tahapan penanganan</h2>
				<ol class="mini-way">
					<?php foreach ( autentik_steps() as $s_i => $s_x ) : ?>
						<li><span class="dot" aria-hidden="true"><?php echo (int) ( $s_i + 1 ); ?></span><b><?php echo esc_html( $s_x[0] ); ?></b></li>
					<?php endforeach; ?>
				</ol>
				<p class="mini-way-n">Pekerjaan baru dimulai setelah Anda menyetujui penawaran tertulis. <a class="bh-more" href="<?php echo esc_url( home_url( '/layanan/#alur' ) ); ?>">Penjelasan Setiap Tahap <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a></p>

				<?php if ( $faq ) : ?>
					<h2 id="faq">Tanya jawab</h2>
					<?php autentik_faq_html( $faq ); ?>
				<?php endif; ?>

				<?php if ( trim( get_the_content() ) && ! $lingkup ) : ?>
					<div class="prose dt-prose"><?php the_content(); ?></div>
				<?php endif; ?>
			</div>

			<aside class="side">
				<?php if ( $kontak ) : ?>
					<div class="box keyc">
						<h3>Anggota tim yang menangani</h3>
						<ul>
							<?php foreach ( $kontak as $k ) : ?>
								<li><a href="<?php echo esc_url( get_permalink( $k ) ); ?>"><?php echo autentik_avatar( $k ); // phpcs:ignore ?><span><b><?php echo esc_html( get_the_title( $k ) ); ?></b><small><?php echo esc_html( implode( ' · ', array_filter( array( (string) autentik_field( 'jabatan', $k->ID ), (string) autentik_field( 'gelar', $k->ID ) ) ) ) ); ?></small></span></a></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>
				<div class="box">
					<h3>Layanan lainnya</h3>
					<ul class="slist">
						<?php foreach ( autentik_layanan() as $p ) : ?>
							<li><a href="<?php echo esc_url( get_permalink( $p ) ); ?>"<?php echo $p->ID === $id ? ' class="on" aria-current="page"' : ''; ?>><?php echo esc_html( get_the_title( $p ) ); ?><?php echo autentik_icon( 'chev' ); // phpcs:ignore ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
				<?php if ( $related ) : ?>
					<div class="box">
						<h3>Artikel terkait</h3>
						<div class="relp">
							<?php foreach ( $related as $r ) : ?>
								<a href="<?php echo esc_url( get_permalink( $r ) ); ?>"><img src="<?php echo esc_url( has_post_thumbnail( $r ) ? get_the_post_thumbnail_url( $r, 'thumbnail' ) : autentik_layanan_img( $id, 'thumbnail' ) ); ?>" alt="" loading="lazy" width="150" height="150"><b><?php echo esc_html( get_the_title( $r ) ); ?></b></a>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
				<div class="help">
					
					<h3>Ingin berkonsultasi mengenai persoalan Anda?</h3>
					<p>Sampaikan pokok persoalan Anda kepada kami. Langkah hukum, perkiraan waktu, dan biaya jasa hukum kami sampaikan secara tertulis sebelum pekerjaan dimulai.</p>
					<a class="btn b-gold" href="<?php echo esc_url( autentik_konsultasi_url() ); ?>">Jadwalkan Konsultasi</a>
					<a class="btn b-line" href="<?php echo esc_url( autentik_wa( 'Halo, Law Firm Autentik Analitika. Saya ingin berkonsultasi mengenai ' . autentik_plain_title() . '.' ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>Hubungi lewat WhatsApp</a>
					<a class="ph" href="tel:<?php echo esc_attr( preg_replace( '/\D+/', '', autentik_opt( 'phone' ) ) ); ?>"><?php echo esc_html( autentik_opt( 'phone' ) ); ?></a>
				</div>
			</aside>
		</div>
	</section>
	<?php
endwhile;
autentik_cta();
get_footer();
