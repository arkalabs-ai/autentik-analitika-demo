<?php
/**
 * Footer.
 *
 * @package Autentik
 */

$soc = array(
	'facebook'  => array( 'fb', 'Facebook' ),
	'instagram' => array( 'ig', 'Instagram' ),
	'tiktok'    => array( 'tiktok', 'TikTok' ),
	'linkedin'  => array( 'in', 'LinkedIn' ),
);
?>
</main>

<?php if ( is_page_template( 'page-templates/landing.php' ) ) : ?>
<footer class="lp-foot">
	<div class="wrap">
		&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( autentik_opt( 'firm' ) ); ?> · <?php echo esc_html( autentik_address() ); ?> ·
		<a href="<?php echo esc_url( home_url( '/kebijakan-privasi/' ) ); ?>">Kebijakan Privasi &amp; Penafian</a>
	</div>
</footer>
<?php else : ?>
<footer class="ft">
	<div class="wrap top">
		<div>
			<?php get_template_part( 'template-parts/brand' ); ?>
			<p>Firma hukum di Medan Baru yang melayani perusahaan dan perorangan dalam urusan hukum bisnis dan penyelesaian sengketa, perizinan berusaha, pertanahan, serta pendirian dan perubahan badan usaha.</p>
			<?php $mem = autentik_lines( autentik_opt( 'memberships' ) ); ?>
			<?php if ( $mem ) : ?><p class="mem"><?php echo esc_html( implode( ' · ', $mem ) ); ?></p><?php endif; ?>
			<div class="soc">
				<?php foreach ( $soc as $key => $s ) : ?>
					<?php if ( autentik_opt( $key ) ) : ?>
						<a href="<?php echo esc_url( autentik_opt( $key ) ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( $s[1] ); ?>"><?php echo autentik_icon( $s[0] ); // phpcs:ignore ?></a>
					<?php endif; ?>
				<?php endforeach; ?>
				<a href="<?php echo esc_url( autentik_wa() ); ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?></a>
			</div>
		</div>
		<div>
			<h2 class="fh">Firma</h2>
			<?php
			if ( has_nav_menu( 'footer' ) ) {
				wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1 ) );
			} else {
				echo '<ul>';
				foreach ( array( 'Tentang Kami' => '/tentang-kami/', 'Layanan' => '/layanan/', 'Tim Kami' => '/tim/', 'Artikel' => '/artikel/', 'Klien' => '/klien/', 'Kontak' => '/kontak/' ) as $t => $u ) {
					echo '<li><a href="' . esc_url( home_url( $u ) ) . '">' . esc_html( $t ) . '</a></li>';
				}
				echo '</ul>';
			}
			?>
		</div>
		<div>
			<h2 class="fh">Layanan</h2>
			<ul>
				<?php foreach ( autentik_layanan() as $p ) : ?>
					<li><a href="<?php echo esc_url( get_permalink( $p ) ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<div>
			<h2 class="fh">Kantor</h2>
			<ul class="fc">
				<li><?php echo autentik_icon( 'pin' ); // phpcs:ignore ?><span><?php echo esc_html( autentik_address() ); ?></span></li>
				<li><?php echo autentik_icon( 'phone' ); // phpcs:ignore ?><a href="tel:<?php echo esc_attr( preg_replace( '/\D+/', '', autentik_opt( 'phone' ) ) ); ?>"><?php echo esc_html( autentik_opt( 'phone' ) ); ?></a></li>
				<li><?php echo autentik_icon( 'mail' ); // phpcs:ignore ?><a href="mailto:<?php echo esc_attr( autentik_opt( 'email' ) ); ?>"><?php echo esc_html( autentik_opt( 'email' ) ); ?></a></li>
				<li><?php echo autentik_icon( 'clock' ); // phpcs:ignore ?><span><?php echo esc_html( autentik_opt( 'hours' ) ); ?></span></li>
			</ul>
		</div>
	</div>
	<div class="bot">
		<div class="wrap">
			<span>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( autentik_opt( 'firm' ) ); ?> · Terdaftar di Kementerian Hukum RI dengan Nomor <?php echo esc_html( autentik_opt( 'sk' ) ); ?></span>
			<nav class="legal" aria-label="Informasi hukum">
				<a href="<?php echo esc_url( home_url( '/kebijakan-privasi/' ) ); ?>">Kebijakan Privasi &amp; Penafian</a>
				<a href="#pengaturan-cookie">Pengaturan Cookie</a>
				<?php if ( autentik_opt( 'scam_notice' ) ) : ?><a href="<?php echo esc_url( home_url( '/kontak/#waspada' ) ); ?>">Waspada Penipuan</a><?php endif; ?>
			</nav>
			<p>Informasi dalam situs ini bersifat umum dan tidak merupakan nasihat hukum. Hasil suatu perkara tidak dapat dijamin. Hubungan advokat dan klien baru terbentuk setelah pemeriksaan benturan kepentingan dan penandatanganan perjanjian jasa hukum, bukan karena Anda menghubungi kami.</p>
		</div>
	</div>
</footer>
<?php endif; ?>

<button class="to-top" id="toTop" aria-label="Kembali ke atas"><?php echo autentik_icon( 'up' ); // phpcs:ignore ?></button>
<nav class="mbar" aria-label="Hubungi kami">
	<a class="wa" href="<?php echo esc_url( autentik_wa( autentik_wa_pesan() ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>WhatsApp</a>
	<a class="jd" href="<?php echo esc_url( ( is_page_template( 'page-templates/landing.php' ) ? '' : home_url( '/kontak/' ) ) . '#form-konsultasi' ); ?>">Jadwalkan Konsultasi</a>
</nav>
<a class="wa-float" href="<?php echo esc_url( autentik_wa( autentik_wa_pesan() ) ); ?>" target="_blank" rel="noopener" aria-label="Hubungi lewat WhatsApp">
	<svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15L2 22l5.2-1.4A10 10 0 1 0 12 2zm0 18.2c-1.6 0-3.1-.4-4.4-1.2l-.3-.2-3.1.8.8-3-.2-.3a8.2 8.2 0 1 1 7.2 3.9z"/><path d="M17.5 14.4c-.3-.2-1.7-.9-2-1-.3-.1-.5-.1-.7.1-.2.3-.7.9-.9 1.1-.2.2-.3.2-.6.1-.3-.2-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.5-.5c.1-.2.2-.3.3-.5 0-.2 0-.4 0-.5 0-.2-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.2.2 2.1 3.2 5.1 4.5.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.7-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.2-.3-.2-.5-.3z"/></svg>
	<span class="tip">Hubungi lewat WhatsApp</span>
</a>

<?php get_template_part( 'template-parts/icons' ); ?>
<?php wp_footer(); ?>
</body>
</html>
