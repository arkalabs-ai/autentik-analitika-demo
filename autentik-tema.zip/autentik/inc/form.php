<?php
/**
 * Formulir konsultasi bawaan: kirim email + simpan di menu "Pesan Masuk".
 * Tanpa plugin formulir. (Bila memakai Fluent Forms, cukup ganti formulir di halaman Kontak.)
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pilihan sah "Cara konsultasi" (kunci URL ?metode= => label yang dikirim) dan "Waktu yang diinginkan".
 */
function autentik_form_metode() {
	return array(
		'kantor'  => 'Tatap muka di kantor',
		'video'   => 'Panggilan video',
		'telepon' => 'Telepon',
	);
}

function autentik_form_waktu() {
	return array( 'Fleksibel', 'Pagi (09.00–12.00 WIB)', 'Siang (12.00–15.00 WIB)', 'Sore (15.00–17.00 WIB)' );
}

/**
 * Bidang layanan yang sah: slug => judul polos. Formulir mengirim judul; slug juga diterima lalu dipetakan ke judul.
 */
function autentik_form_bidang_sah() {
	$out = array();
	foreach ( autentik_layanan() as $p ) {
		$out[ $p->post_name ] = autentik_plain_title( $p );
	}
	return $out;
}

/**
 * Nama advokat yang diminta hanya sah bila sama persis dengan anggota tim publik; selain itu kosong.
 */
function autentik_form_advokat_sah( $nama ) {
	$nama = trim( (string) $nama );
	if ( '' === $nama || ! function_exists( 'autentik_tim_publik' ) ) {
		return '';
	}
	foreach ( autentik_tim_publik() as $t ) {
		if ( autentik_plain_title( $t ) === $nama ) {
			return $nama;
		}
	}
	return '';
}

/**
 * Stempel waktu antibot bertanda tangan server ("waktu.tanda", HMAC wp_hash). Tetap sah di halaman yang
 * di-cache selama umur cache halaman lebih pendek dari batas atas (filter autentik_form_ttl, bawaan 24 jam).
 */
function autentik_form_stempel( $ts = null ) {
	$ts = null === $ts ? time() : (int) $ts;
	return $ts . '.' . wp_hash( 'autentik_form|' . $ts, 'nonce' );
}

function autentik_form_stempel_ok( $raw ) {
	$raw   = (string) $raw;
	$parts = explode( '.', $raw, 2 );
	if ( 2 !== count( $parts ) || '' === $parts[0] || ! ctype_digit( $parts[0] ) ) {
		return false;
	}
	if ( ! hash_equals( autentik_form_stempel( (int) $parts[0] ), $raw ) ) {
		return false;
	}
	$age = time() - (int) $parts[0];
	return $age >= 3 && $age <= (int) apply_filters( 'autentik_form_ttl', DAY_IN_SECONDS );
}

/**
 * IP pengirim untuk batas kiriman: REMOTE_ADDR. Hanya bila situs di balik proksi/CDN tepercaya
 * (define( 'AUTENTIK_TRUSTED_PROXY', true ); di wp-config.php) dipakai CF-Connecting-IP atau X-Forwarded-For pertama.
 */
function autentik_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	if ( defined( 'AUTENTIK_TRUSTED_PROXY' ) && AUTENTIK_TRUSTED_PROXY ) {
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR' ) as $h ) {
			if ( empty( $_SERVER[ $h ] ) ) {
				continue;
			}
			$cand = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $h ] ) ) )[0] );
			if ( filter_var( $cand, FILTER_VALIDATE_IP ) ) {
				return $cand;
			}
		}
	}
	return $ip;
}

function autentik_form( $context = 'kontak', $compact = false ) {
	$status = isset( $_GET['konsultasi'] ) ? sanitize_key( wp_unslash( $_GET['konsultasi'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$lay    = autentik_layanan();
	$adv    = isset( $_GET['advokat'] ) ? autentik_form_advokat_sah( mb_substr( sanitize_text_field( wp_unslash( $_GET['advokat'] ) ), 0, 120 ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$pilih  = isset( $_GET['bidang'] ) ? sanitize_title( wp_unslash( $_GET['bidang'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$metode = isset( $_GET['metode'] ) ? sanitize_key( wp_unslash( $_GET['metode'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( '' === $pilih && is_singular( 'layanan' ) ) {
		$pilih = get_post_field( 'post_name', get_the_ID() );
	}

	if ( 'ok' === $status ) :
		?>
		<div class="form-ok" id="form-konsultasi">
			<div role="status" id="form-status" tabindex="-1">
				<span class="ok-i"><?php echo autentik_icon( 'check' ); // phpcs:ignore ?></span>
				<h3>Permintaan konsultasi Anda telah kami terima</h3>
				<p>Kami menelaah setiap pesan pada jam kerja dan menghubungi Anda paling lambat satu hari kerja melalui WhatsApp atau telepon. <span class="open-now" data-open-now hidden><i></i><em></em></span></p>
				<p>Bila persoalan Anda mendesak, langsung saja hubungi kami lewat WhatsApp dan sebutkan nama Anda.</p>
			</div>
			<div class="acts">
				<a class="btn b-gold" href="<?php echo esc_url( autentik_wa( autentik_sapa() . 'Saya baru saja mengirim formulir permintaan konsultasi melalui situs Anda.' ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>Hubungi lewat WhatsApp</a>
				<a class="btn b-line" href="<?php echo esc_url( home_url( '/artikel/' ) ); ?>">Baca Artikel dan Panduan Hukum</a>
			</div>
		</div>
		<?php
		return;
	endif;
	$pesan_gagal = array(
		'gagal' => 'Pesan Anda belum terkirim. Isian Anda masih tersimpan di bawah ini. Mohon pastikan nama, nomor WhatsApp, ringkasan persoalan, dan persetujuan telah diisi, lalu kirim kembali.',
		'wa'    => 'Nomor WhatsApp belum lengkap. Mohon tuliskan 10–15 angka, misalnya 0812 3456 7890, lalu kirim kembali. Isian lainnya masih tersimpan.',
		'batas' => 'Dalam satu jam terakhir sudah ada beberapa kiriman dari nomor atau jaringan ini, jadi kiriman berikutnya kami tahan sementara. Silakan hubungi kami lewat WhatsApp atau telepon.',
	);
	?>
	<form class="form form2" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="form-konsultasi" novalidate data-v>
		<input type="hidden" name="action" value="autentik_konsultasi">
		<input type="hidden" name="asal" value="<?php echo esc_attr( $context ); ?>">
		<input type="hidden" name="kembali" value="<?php echo esc_url( get_permalink() ? get_permalink() : home_url( '/' ) ); ?>">
		<?php wp_nonce_field( 'autentik_konsultasi', '_aa' ); ?>
		<?php if ( isset( $pesan_gagal[ $status ] ) ) : ?>
			<div class="fr full notice err" role="alert" id="form-status" tabindex="-1"><?php echo autentik_icon( 'info' ); // phpcs:ignore ?><?php echo esc_html( $pesan_gagal[ $status ] ); ?> <a href="<?php echo esc_url( autentik_wa() ); ?>" target="_blank" rel="noopener">Hubungi lewat WhatsApp</a></div>
		<?php endif; ?>
		<input type="hidden" name="t" value="<?php echo esc_attr( autentik_form_stempel() ); ?>" data-aa-t>
		<p class="fr full req-note" aria-hidden="true"><span class="req">*</span> wajib diisi</p>
		<?php if ( $adv ) : ?>
			<input type="hidden" name="advokat" value="<?php echo esc_attr( $adv ); ?>">
			<p class="fr full adv"><?php echo autentik_icon( 'user' ); // phpcs:ignore ?><span>Permintaan konsultasi dengan <b><?php echo esc_html( $adv ); ?></b></span></p>
		<?php endif; ?>
		<div class="hp" aria-hidden="true"><label for="aa-web">Website</label><input id="aa-web" name="website" type="text" tabindex="-1" autocomplete="off"></div>
		<div class="fr<?php echo $compact ? ' full' : ''; ?>"><label for="aa-nama">Nama lengkap<span class="req" aria-hidden="true">*</span></label><input id="aa-nama" name="nama" type="text" autocomplete="name" maxlength="120" required aria-invalid="false" aria-describedby="aa-nama-e"><small class="fe" id="aa-nama-e" hidden>Mohon tuliskan nama lengkap Anda.</small></div>
		<div class="fr<?php echo $compact ? ' full' : ''; ?>"><label for="aa-wa">Nomor WhatsApp<span class="req" aria-hidden="true">*</span></label><input id="aa-wa" name="wa" type="tel" autocomplete="tel" inputmode="tel" placeholder="0812 3456 7890" maxlength="30" required aria-invalid="false" pattern="[0-9 +().\-]{9,24}" aria-describedby="aa-wa-e"><small class="fe" id="aa-wa-e" hidden>Mohon tuliskan 10–15 angka, misalnya 0812 3456 7890.</small></div>
		<div class="fr full"><label for="aa-bidang">Bidang layanan</label>
			<select id="aa-bidang" name="bidang">
				<option value="">Belum yakin</option>
				<?php foreach ( $lay as $p ) : ?>
					<option value="<?php echo esc_attr( get_the_title( $p ) ); ?>" <?php selected( $pilih, $p->post_name ); ?>><?php echo esc_html( get_the_title( $p ) ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="fr full"><label for="aa-pesan">Ringkasan persoalan Anda<span class="req" aria-hidden="true">*</span></label><textarea id="aa-pesan" name="pesan" maxlength="5000" required aria-invalid="false" autocomplete="off" aria-describedby="aa-pesan-e" placeholder="Contoh: saya membeli sebidang tanah pada 2023, tetapi sertifikatnya belum dibalik nama dan penjual sulit dihubungi."></textarea><small class="fe" id="aa-pesan-e" hidden>Mohon uraikan pokok persoalan Anda dalam beberapa kalimat.</small></div>
		<?php if ( ! $compact ) : ?>
			<details class="fr full opt"<?php echo $metode ? ' open' : ''; ?>>
				<summary>Keterangan tambahan <small>(tidak wajib: email, cara dan waktu konsultasi, pihak lain)</small></summary>
				<div class="opt-in">
					<div class="fr"><label for="aa-email">Email</label><input id="aa-email" name="email" type="email" autocomplete="email" spellcheck="false" autocapitalize="off" placeholder="nama@perusahaan.co.id" maxlength="120"></div>
					<div class="fr"><label for="aa-metode">Cara konsultasi</label>
						<select id="aa-metode" name="metode">
							<?php foreach ( autentik_form_metode() as $mk => $ml ) : ?>
								<option value="<?php echo esc_attr( $ml ); ?>"<?php selected( $metode, $mk ); ?>><?php echo esc_html( $ml ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="fr"><label for="aa-waktu">Waktu yang diinginkan</label>
						<select id="aa-waktu" name="waktu">
							<?php foreach ( autentik_form_waktu() as $wl ) : ?>
								<option value="<?php echo esc_attr( $wl ); ?>"><?php echo esc_html( $wl ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="fr"><label for="aa-pihak">Pihak lain yang terlibat</label><input id="aa-pihak" name="pihak" type="text" maxlength="200" autocomplete="off" placeholder="Contoh: PT Contoh Jaya">
						<small class="hint">Kami memerlukannya untuk memeriksa benturan kepentingan sebelum menanggapi persoalan Anda.</small></div>
				</div>
			</details>
		<?php endif; ?>
		<p class="fr full conf"><?php echo autentik_icon( 'shield' ); // phpcs:ignore ?><span>Ringkasan singkat sudah memadai. Mohon tidak mengirim dokumen atau keterangan yang bersifat rahasia sebelum perjanjian jasa hukum ditandatangani; kami akan memintanya bila diperlukan.</span></p>
		<div class="fr full"><label class="consent" for="aa-setuju"><input id="aa-setuju" name="setuju" type="checkbox" value="1" required aria-invalid="false" aria-describedby="aa-setuju-e">
			<span><span class="req" aria-hidden="true">*</span> Saya menyetujui pemrosesan data yang saya kirimkan, termasuk uraian persoalan dan nama pihak lain, oleh <?php echo esc_html( autentik_opt( 'firm' ) ); ?> untuk menanggapi permintaan konsultasi ini sebagaimana dijelaskan dalam <a href="<?php echo esc_url( home_url( '/kebijakan-privasi/' ) ); ?>">Kebijakan Privasi</a>. Persetujuan ini dapat saya tarik sewaktu-waktu. Saya memahami bahwa pengiriman formulir ini belum menimbulkan hubungan advokat dan klien.</span></label><small class="fe" id="aa-setuju-e" hidden>Mohon centang persetujuan ini agar pesan Anda dapat kami proses.</small></div>
		<div class="fr full send">
			<p class="next"><?php echo autentik_icon( 'clock' ); // phpcs:ignore ?><span>Kami akan menghubungi Anda paling lambat satu hari kerja setelah pesan diterima, melalui WhatsApp atau telepon.</span></p>
			<button class="btn b-gold" type="submit">Kirim Permintaan Konsultasi <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></button>
		</div>
	</form>
	<?php
}

/**
 * Tujuan setelah formulir terkirim: halaman /terima-kasih/ (noindex) bila ada; bila belum dibuat, panel konfirmasi di halaman asal.
 */
function autentik_form_ok_url( $back, $asal ) {
	$ty = get_page_by_path( 'terima-kasih' );
	if ( $ty && 'publish' === $ty->post_status ) {
		return add_query_arg( 'dari', rawurlencode( $asal ? $asal : 'kontak' ), get_permalink( $ty ) );
	}
	return add_query_arg( 'konsultasi', 'ok', $back ) . '#form-konsultasi';
}

function autentik_form_handle() {
	$back = isset( $_POST['kembali'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_POST['kembali'] ) ), home_url( '/' ) ) : home_url( '/' );
	$fail = add_query_arg( 'konsultasi', 'gagal', $back ) . '#form-konsultasi';

	// Nonce hanya untuk pengguna yang login: bagi tamu nilainya sama untuk semua orang dan
	// kedaluwarsa di halaman yang di-cache (LiteSpeed), sehingga kiriman sah ikut gagal.
	if ( is_user_logged_in() && ( ! isset( $_POST['_aa'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_aa'] ) ), 'autentik_konsultasi' ) ) ) {
		wp_safe_redirect( $fail );
		exit;
	}
	$asal = isset( $_POST['asal'] ) ? sanitize_key( wp_unslash( $_POST['asal'] ) ) : '';
	// Jebakan bot: kolom tersembunyi terisi, atau stempel waktu server hilang/palsu/terlalu cepat (< 3 detik)/kedaluwarsa.
	// Ditolak diam-diam (tampak sukses) dan tidak menghabiskan kuota siapa pun.
	$t = isset( $_POST['t'] ) ? sanitize_text_field( wp_unslash( $_POST['t'] ) ) : '';
	if ( ! empty( $_POST['website'] ) || ! autentik_form_stempel_ok( $t ) ) {
		wp_safe_redirect( autentik_form_ok_url( $back, $asal ) );
		exit;
	}
	$nama   = isset( $_POST['nama'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['nama'] ) ), 0, 120 ) : '';
	$wa     = isset( $_POST['wa'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['wa'] ) ), 0, 30 ) : '';
	$email  = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$pesan  = isset( $_POST['pesan'] ) ? mb_substr( sanitize_textarea_field( wp_unslash( $_POST['pesan'] ) ), 0, 5000 ) : '';
	$one    = function ( $k, $n = 120 ) { return isset( $_POST[ $k ] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST[ $k ] ) ), 0, $n ) : ''; }; // phpcs:ignore WordPress.Security.NonceVerification
	$pihak  = $one( 'pihak', 200 );
	$setuju = ! empty( $_POST['setuju'] );

	// Nilai pilihan hanya dari daftar sah; nilai asing dikosongkan (tidak masuk subjek email maupun judul Pesan).
	$bidang = $one( 'bidang' );
	$sah    = autentik_form_bidang_sah();
	if ( isset( $sah[ $bidang ] ) ) {
		$bidang = $sah[ $bidang ];
	} elseif ( ! in_array( $bidang, $sah, true ) ) {
		$bidang = '';
	}
	$metode = $one( 'metode' );
	$metode = in_array( $metode, autentik_form_metode(), true ) ? $metode : '';
	$waktu  = $one( 'waktu' );
	$waktu  = in_array( $waktu, autentik_form_waktu(), true ) ? $waktu : '';
	$adv    = autentik_form_advokat_sah( $one( 'advokat' ) );

	if ( '' === $nama || '' === $wa || '' === $pesan || ! $setuju ) {
		wp_safe_redirect( $fail );
		exit;
	}
	$wa_digit = preg_replace( '/\D+/', '', $wa );
	if ( strlen( $wa_digit ) < 9 || strlen( $wa_digit ) > 15 ) {
		wp_safe_redirect( add_query_arg( 'konsultasi', 'wa', $back ) . '#form-konsultasi' );
		exit;
	}

	// Batas kiriman: hanya kiriman yang lolos jebakan & validasi yang dihitung.
	// Per IP (bawaan 8/jam, longgar untuk CGNAT seluler) dan per nomor WhatsApp (bawaan 3/jam).
	$rl_ip = 'aa_rl_' . md5( autentik_client_ip() );
	$rl_wa = 'aa_rlw_' . md5( $wa_digit );
	$n_ip  = (int) get_transient( $rl_ip );
	$n_wa  = (int) get_transient( $rl_wa );
	if ( $n_ip >= (int) apply_filters( 'autentik_rate_limit', 8 ) || $n_wa >= (int) apply_filters( 'autentik_rate_limit_wa', 3 ) ) {
		wp_safe_redirect( add_query_arg( 'konsultasi', 'batas', $back ) . '#form-konsultasi' );
		exit;
	}
	set_transient( $rl_ip, $n_ip + 1, HOUR_IN_SECONDS );
	set_transient( $rl_wa, $n_wa + 1, HOUR_IN_SECONDS );

	$extra = '';
	foreach ( array( 'Advokat yang diminta' => $adv, 'Cara konsultasi' => $metode, 'Waktu yang diinginkan' => $waktu, 'Pihak lain (untuk pemeriksaan benturan kepentingan)' => $pihak ) as $lbl => $val ) {
		if ( '' !== $val ) {
			$extra .= "\n{$lbl}: {$val}";
		}
	}
	$body = "Nama: {$nama}\nWhatsApp: {$wa}\nEmail: {$email}\nBidang layanan: " . ( $bidang ? $bidang : 'Belum yakin' ) . $extra . "\nDikirim dari halaman: {$back} ({$asal})\nWaktu pengiriman: " . wp_date( 'j F Y H:i' ) . " WIB\n\n{$pesan}\n\nPersetujuan pemrosesan data: diberikan";

	$id = 0;
	if ( post_type_exists( 'pesan' ) ) {
		$id = wp_insert_post(
			array(
				'post_type'    => 'pesan',
				'post_status'  => 'private',
				'post_title'   => $nama . ' — ' . ( $bidang ? $bidang : 'Konsultasi' ), // pemisah sama dengan kolom "Pengirim — layanan"
				'post_content' => $body,
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			$meta = array(
				'nama'     => $nama, // sapaan balasan WhatsApp di Pesan Masuk
				'wa'       => $wa,
				'wa_digit' => $wa_digit, // pengenal permintaan ekspor/hapus data UU PDP bila email kosong
				'email'    => $email,
				'bidang'   => $bidang,
				'metode'   => $metode,
				'waktu'    => $waktu,
				'pihak'    => $pihak,
				'advokat'  => $adv,
			);
			foreach ( $meta as $mk => $mv ) {
				update_post_meta( $id, $mk, $mv );
			}
		}
	}

	$to      = autentik_opt( 'lead_email' ) ? autentik_opt( 'lead_email' ) : get_option( 'admin_email' );
	$headers = array();
	if ( $email ) {
		$headers[] = 'Reply-To: ' . $email;
	}
	$ringkas = "Terdapat permintaan konsultasi baru melalui situs web.

Nama: {$nama}
WhatsApp: {$wa}
Bidang layanan: " . ( $bidang ? $bidang : 'Belum yakin' ) . $extra . "

Uraian lengkap dapat dibaca pada menu Pesan Masuk (masuk sebagai admin):
" . admin_url( 'edit.php?post_type=pesan' ) . "

Demi menjaga kerahasiaan, uraian persoalan tidak disertakan dalam email ini.";
	$sent    = wp_mail( $to, '[Situs Web] Permintaan konsultasi baru: ' . $nama . ( $bidang ? ' - ' . $bidang : '' ), $ringkas, $headers );
	if ( ! $sent ) {
		error_log( 'Autentik: email formulir konsultasi gagal dikirim (pesan ' . ( $id ? 'tersimpan #' . $id : 'TIDAK tersimpan' ) . ').' ); // phpcs:ignore
	}
	if ( ! $sent && ( ! $id || is_wp_error( $id ) ) ) {
		wp_safe_redirect( $fail );
		exit;
	}

	wp_safe_redirect( autentik_form_ok_url( $back, $asal ) );
	exit;
}
add_action( 'admin_post_nopriv_autentik_konsultasi', 'autentik_form_handle' );
add_action( 'admin_post_autentik_konsultasi', 'autentik_form_handle' );
