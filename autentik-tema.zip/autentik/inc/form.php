<?php
/**
 * Formulir konsultasi bawaan: kirim email + simpan di menu "Pesan Masuk".
 * Tanpa plugin formulir. (Bila memakai Fluent Forms, cukup ganti formulir di halaman Kontak.)
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function autentik_form( $context = 'kontak', $compact = false ) {
	$status = isset( $_GET['konsultasi'] ) ? sanitize_key( wp_unslash( $_GET['konsultasi'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$lay    = autentik_layanan();
	$adv    = isset( $_GET['advokat'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_GET['advokat'] ) ), 0, 120 ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$pilih  = isset( $_GET['bidang'] ) ? sanitize_title( wp_unslash( $_GET['bidang'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( '' === $pilih && is_singular( 'layanan' ) ) {
		$pilih = get_post_field( 'post_name', get_the_ID() );
	}

	if ( 'ok' === $status ) :
		?>
		<div class="form-ok" id="form-konsultasi">
			<div role="status" id="form-status" tabindex="-1">
				<span class="ok-i"><?php echo autentik_icon( 'check' ); // phpcs:ignore ?></span>
				<h3>Permintaan konsultasi Anda telah kami terima</h3>
				<p>Kami menelaah setiap pesan pada hari kerja yang sama dan akan menghubungi Anda paling lambat satu hari kerja melalui WhatsApp atau telepon. <span class="open-now" data-open-now hidden><i></i><em></em></span></p>
				<p>Apabila persoalan Anda mendesak, silakan hubungi kami langsung lewat WhatsApp dengan menyebutkan nama Anda.</p>
			</div>
			<div class="acts">
				<a class="btn b-gold" href="<?php echo esc_url( autentik_wa( 'Halo, Law Firm Autentik Analitika. Saya baru saja mengirim formulir permintaan konsultasi melalui situs Anda.' ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>Hubungi lewat WhatsApp</a>
				<a class="btn b-line" href="<?php echo esc_url( home_url( '/artikel/' ) ); ?>">Baca Artikel dan Panduan Hukum</a>
			</div>
		</div>
		<?php
		return;
	endif;
	$pesan_gagal = array(
		'gagal' => 'Pesan Anda belum terkirim. Isian Anda masih tersimpan di bawah ini. Mohon pastikan nama, nomor WhatsApp, ringkasan persoalan, dan persetujuan telah diisi, lalu kirim kembali.',
		'wa'    => 'Nomor WhatsApp belum lengkap. Mohon tuliskan 10–15 angka, misalnya 0812 3456 7890, lalu kirim kembali. Isian lainnya masih tersimpan.',
		'batas' => 'Kami telah menerima beberapa kiriman dari jaringan ini dalam satu jam terakhir, sehingga kiriman berikutnya untuk sementara kami tahan. Silakan hubungi kami lewat WhatsApp atau telepon.',
	);
	?>
	<form class="form form2" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="form-konsultasi" novalidate data-v>
		<input type="hidden" name="action" value="autentik_konsultasi">
		<input type="hidden" name="asal" value="<?php echo esc_attr( $context ); ?>">
		<input type="hidden" name="kembali" value="<?php echo esc_url( get_permalink() ? get_permalink() : home_url( '/' ) ); ?>">
		<?php wp_nonce_field( 'autentik_konsultasi', '_aa' ); ?>
		<?php if ( isset( $pesan_gagal[ $status ] ) ) : ?>
			<div class="fr full notice err" role="alert" id="form-status" tabindex="-1"><?php echo autentik_icon( 'info' ); // phpcs:ignore ?><?php echo esc_html( $pesan_gagal[ $status ] ); ?> <a href="<?php echo esc_url( autentik_wa() ); ?>" target="_blank" rel="noopener">Hubungi lewat WhatsApp</a></div>
		<?php endif; ?>
		<input type="hidden" name="t" value="<?php echo esc_attr( (string) time() ); ?>" data-aa-t>
		<?php if ( $adv ) : ?>
			<input type="hidden" name="advokat" value="<?php echo esc_attr( $adv ); ?>">
			<p class="fr full adv"><?php echo autentik_icon( 'user' ); // phpcs:ignore ?><span>Permintaan konsultasi dengan <b><?php echo esc_html( $adv ); ?></b></span></p>
		<?php endif; ?>
		<div class="hp" aria-hidden="true"><label for="aa-web">Website</label><input id="aa-web" name="website" type="text" tabindex="-1" autocomplete="off"></div>
		<div class="fr<?php echo $compact ? ' full' : ''; ?>"><label for="aa-nama">Nama lengkap</label><input id="aa-nama" name="nama" type="text" autocomplete="name" maxlength="120" required aria-describedby="aa-nama-e"><small class="fe" id="aa-nama-e" hidden>Mohon tuliskan nama lengkap Anda.</small></div>
		<div class="fr<?php echo $compact ? ' full' : ''; ?>"><label for="aa-wa">Nomor WhatsApp</label><input id="aa-wa" name="wa" type="tel" autocomplete="tel" inputmode="tel" placeholder="0812 3456 7890" maxlength="30" required pattern="[0-9 +().\-]{9,24}" aria-describedby="aa-wa-e"><small class="fe" id="aa-wa-e" hidden>Mohon tuliskan 10–15 angka, misalnya 0812 3456 7890.</small></div>
		<div class="fr full"><label for="aa-bidang">Bidang layanan</label>
			<select id="aa-bidang" name="bidang">
				<option value="">Belum yakin</option>
				<?php foreach ( $lay as $p ) : ?>
					<option value="<?php echo esc_attr( get_the_title( $p ) ); ?>" <?php selected( $pilih, $p->post_name ); ?>><?php echo esc_html( get_the_title( $p ) ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="fr full"><label for="aa-pesan">Ringkasan persoalan Anda</label><textarea id="aa-pesan" name="pesan" maxlength="5000" required autocomplete="off" aria-describedby="aa-pesan-e" placeholder="Contoh: saya membeli sebidang tanah pada 2023, tetapi sertifikatnya belum dibalik nama dan penjual sulit dihubungi."></textarea><small class="fe" id="aa-pesan-e" hidden>Mohon uraikan pokok persoalan Anda dalam beberapa kalimat.</small></div>
		<?php if ( ! $compact ) : ?>
			<details class="fr full opt">
				<summary>Keterangan tambahan <small>(tidak wajib: email, cara dan waktu konsultasi, pihak lain)</small></summary>
				<div class="opt-in">
					<div class="fr"><label for="aa-email">Email</label><input id="aa-email" name="email" type="email" autocomplete="email" spellcheck="false" autocapitalize="off" placeholder="nama@perusahaan.co.id" maxlength="120"></div>
					<div class="fr"><label for="aa-metode">Cara konsultasi</label>
						<select id="aa-metode" name="metode">
							<option>Tatap muka di kantor</option>
							<option>Panggilan video</option>
							<option>Telepon</option>
						</select>
					</div>
					<div class="fr"><label for="aa-waktu">Waktu yang diinginkan</label>
						<select id="aa-waktu" name="waktu">
							<option>Fleksibel</option>
							<option>Pagi (09.00–12.00 WIB)</option>
							<option>Siang (12.00–15.00 WIB)</option>
							<option>Sore (15.00–17.00 WIB)</option>
						</select>
					</div>
					<div class="fr"><label for="aa-pihak">Pihak lain yang terlibat</label><input id="aa-pihak" name="pihak" type="text" maxlength="200" autocomplete="off" placeholder="Contoh: PT Contoh Jaya">
						<small class="hint">Kami memerlukannya untuk memeriksa benturan kepentingan sebelum menanggapi persoalan Anda.</small></div>
				</div>
			</details>
		<?php endif; ?>
		<p class="fr full conf"><?php echo autentik_icon( 'shield' ); // phpcs:ignore ?><span>Ringkasan singkat sudah memadai. Mohon tidak mengirim dokumen atau keterangan yang bersifat rahasia sebelum perjanjian jasa hukum ditandatangani; kami akan memintanya bila diperlukan.</span></p>
		<div class="fr full"><label class="consent" for="aa-setuju"><input id="aa-setuju" name="setuju" type="checkbox" value="1" required aria-describedby="aa-setuju-e">
			<span>Saya menyetujui pemrosesan data yang saya kirimkan, termasuk uraian persoalan, oleh Law Firm Autentik Analitika untuk menanggapi permintaan konsultasi ini sebagaimana dijelaskan dalam <a href="<?php echo esc_url( home_url( '/kebijakan-privasi/' ) ); ?>">Kebijakan Privasi</a>. Saya memahami bahwa pengiriman formulir ini belum menimbulkan hubungan advokat dan klien.</span></label><small class="fe" id="aa-setuju-e" hidden>Mohon centang persetujuan ini agar pesan Anda dapat kami proses.</small></div>
		<div class="fr full send">
			<p class="next"><?php echo autentik_icon( 'clock' ); // phpcs:ignore ?><span>Kami akan menghubungi Anda paling lambat satu hari kerja setelah pesan diterima, melalui WhatsApp atau telepon.</span></p>
			<button class="btn b-gold" type="submit">Kirim Pesan <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></button>
		</div>
	</form>
	<?php
}

function autentik_form_handle() {
	$back = isset( $_POST['kembali'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_POST['kembali'] ) ), home_url( '/' ) ) : home_url( '/' );
	$fail = add_query_arg( 'konsultasi', 'gagal', $back ) . '#form-konsultasi';

	// Nonce hanya untuk pengguna yang login: bagi tamu nilainya sama untuk semua orang dan
	// kedaluwarsa di halaman yang di-cache (LiteSpeed), sehingga kiriman sah ikut gagal.
	if ( is_user_logged_in() && ( ! isset( $_POST['_aa'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_aa'] ) ), 'autentik_konsultasi' ) ) ) {
		wp_safe_redirect( $fail );
		exit;
	}
	// Batas 5 kiriman per jam per IP.
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$rl = 'aa_rl_' . md5( $ip );
	$n  = (int) get_transient( $rl );
	if ( $n >= 5 ) {
		wp_safe_redirect( add_query_arg( 'konsultasi', 'batas', $back ) . '#form-konsultasi' );
		exit;
	}
	set_transient( $rl, $n + 1, HOUR_IN_SECONDS );
	// Jebakan bot: kolom tersembunyi terisi, atau formulir dikirim kurang dari 3 detik setelah dibuka.
	$t = isset( $_POST['t'] ) ? (int) $_POST['t'] : 0;
	if ( ! empty( $_POST['website'] ) || ( $t && time() - $t < 3 ) ) {
		wp_safe_redirect( add_query_arg( 'konsultasi', 'ok', $back ) . '#form-konsultasi' );
		exit;
	}
	$nama   = isset( $_POST['nama'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['nama'] ) ), 0, 120 ) : '';
	$wa     = isset( $_POST['wa'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['wa'] ) ), 0, 30 ) : '';
	$email  = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$bidang = isset( $_POST['bidang'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['bidang'] ) ), 0, 120 ) : '';
	$pesan  = isset( $_POST['pesan'] ) ? mb_substr( sanitize_textarea_field( wp_unslash( $_POST['pesan'] ) ), 0, 5000 ) : '';
	$asal   = isset( $_POST['asal'] ) ? sanitize_key( wp_unslash( $_POST['asal'] ) ) : '';
	$one    = function ( $k, $n = 120 ) { return isset( $_POST[ $k ] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST[ $k ] ) ), 0, $n ) : ''; }; // phpcs:ignore WordPress.Security.NonceVerification
	$metode = $one( 'metode' );
	$waktu  = $one( 'waktu' );
	$pihak  = $one( 'pihak', 200 );
	$adv    = $one( 'advokat' );
	$setuju = ! empty( $_POST['setuju'] );

	if ( '' === $nama || '' === $wa || '' === $pesan || ! $setuju ) {
		wp_safe_redirect( $fail );
		exit;
	}
	$wa_digit = preg_replace( '/\D+/', '', $wa );
	if ( strlen( $wa_digit ) < 9 || strlen( $wa_digit ) > 15 ) {
		wp_safe_redirect( add_query_arg( 'konsultasi', 'wa', $back ) . '#form-konsultasi' );
		exit;
	}

	$extra = '';
	foreach ( array( 'Advokat yang diminta' => $adv, 'Cara konsultasi' => $metode, 'Waktu yang diinginkan' => $waktu, 'Pihak lain (untuk pemeriksaan benturan kepentingan)' => $pihak ) as $lbl => $val ) {
		if ( '' !== $val ) {
			$extra .= "\n{$lbl}: {$val}";
		}
	}
	$body = "Nama: {$nama}\nWhatsApp: {$wa}\nEmail: {$email}\nBidang layanan: " . ( $bidang ? $bidang : 'Belum yakin' ) . $extra . "\nDikirim dari halaman: {$back} ({$asal})\nWaktu pengiriman: " . wp_date( 'j F Y H:i' ) . " WIB\n\n{$pesan}\n\n— Persetujuan pemrosesan data: diberikan";

	$id = 0;
	if ( post_type_exists( 'pesan' ) ) {
		$id = wp_insert_post(
			array(
				'post_type'    => 'pesan',
				'post_status'  => 'private',
				'post_title'   => $nama . ' — ' . ( $bidang ? $bidang : 'Konsultasi' ),
				'post_content' => $body,
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, 'wa', $wa );
			update_post_meta( $id, 'email', $email );
			update_post_meta( $id, 'bidang', $bidang );
			update_post_meta( $id, 'pihak', $pihak );
			update_post_meta( $id, 'advokat', $adv );
		}
	}

	$to      = autentik_opt( 'lead_email' ) ? autentik_opt( 'lead_email' ) : get_option( 'admin_email' );
	$headers = array();
	if ( $email ) {
		$headers[] = 'Reply-To: ' . $email;
	}
	$ringkas = "Terdapat permintaan konsultasi baru melalui situs web.

Nama: {$nama}
WhatsApp: {$wa}
Bidang layanan: " . ( $bidang ? $bidang : 'Belum yakin' ) . $extra . "

Uraian lengkap dapat dibaca pada menu Pesan Masuk (masuk sebagai admin):
" . admin_url( 'edit.php?post_type=pesan' ) . "

Demi menjaga kerahasiaan, uraian persoalan tidak disertakan dalam email ini.";
	$sent    = wp_mail( $to, '[Situs Web] Permintaan konsultasi baru: ' . $nama . ( $bidang ? ' - ' . $bidang : '' ), $ringkas, $headers );
	if ( ! $sent ) {
		error_log( 'Autentik: email formulir konsultasi gagal dikirim (pesan ' . ( $id ? 'tersimpan #' . $id : 'TIDAK tersimpan' ) . ').' ); // phpcs:ignore
	}
	if ( ! $sent && ( ! $id || is_wp_error( $id ) ) ) {
		wp_safe_redirect( $fail );
		exit;
	}

	wp_safe_redirect( add_query_arg( 'konsultasi', 'ok', $back ) . '#form-konsultasi' );
	exit;
}
add_action( 'admin_post_nopriv_autentik_konsultasi', 'autentik_form_handle' );
add_action( 'admin_post_autentik_konsultasi', 'autentik_form_handle' );
