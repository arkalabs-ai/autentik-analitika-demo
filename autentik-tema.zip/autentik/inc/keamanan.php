<?php
/**
 * Pengerasan keamanan lapis aplikasi (qa/46b T3, S2, R1, R2, R4).
 * Header dasar dikirim dari tema agar berlaku di Apache, Nginx, maupun LiteSpeed.
 * HSTS dan CSP penuh sengaja TIDAK dipasang di sini: HSTS milik server (setelah HTTPS stabil),
 * CSP penuh menunggu skrip inline dipindah ke berkas.
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Header keamanan untuk halaman publik (bukan wp-admin, bukan pratinjau Customizer).
 */
function autentik_header_keamanan() {
	if ( is_admin() || is_customize_preview() || headers_sent() ) {
		return;
	}
	header( 'X-Content-Type-Options: nosniff' );
	header( 'X-Frame-Options: SAMEORIGIN' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
}
add_action( 'send_headers', 'autentik_header_keamanan' );

/**
 * Pesan galat login generik: tidak membenarkan apakah nama pengguna/email terdaftar.
 */
function autentik_login_errors() {
	return '<strong>Gagal masuk.</strong> Nama pengguna, email, atau kata sandi tidak cocok.';
}
add_filter( 'login_errors', 'autentik_login_errors' );

/**
 * Versi WordPress tidak diumumkan (feed RSS/Atom, OPML, dsb.; meta generator di <head> sudah dicabut di functions.php).
 */
add_filter( 'the_generator', '__return_empty_string' );

/**
 * REST: ID akun penulis tidak dibuka kepada tamu (artikel, halaman, dan jenis konten publik).
 */
function autentik_rest_sembunyikan_penulis( $response ) {
	if ( is_user_logged_in() || ! ( $response instanceof WP_REST_Response ) ) {
		return $response;
	}
	$data = $response->get_data();
	if ( is_array( $data ) && array_key_exists( 'author', $data ) ) {
		$data['author'] = 0;
		$response->set_data( $data );
	}
	$response->remove_link( 'author' );
	return $response;
}
function autentik_rest_penulis_hooks() {
	$types = array_unique( array_merge( array( 'post', 'page' ), get_post_types( array( 'public' => true, 'show_in_rest' => true ) ) ) );
	foreach ( $types as $type ) {
		if ( 'attachment' === $type ) {
			continue;
		}
		add_filter( 'rest_prepare_' . $type, 'autentik_rest_sembunyikan_penulis', 20 );
	}
}
add_action( 'rest_api_init', 'autentik_rest_penulis_hooks' );

/**
 * XML-RPC dimatikan seluruhnya (termasuk metode tanpa autentikasi seperti pingback.* dan system.*).
 */
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'xmlrpc_methods', '__return_empty_array' );
add_filter(
	'wp_headers',
	function ( $h ) {
		unset( $h['X-Pingback'] );
		return $h;
	}
);
