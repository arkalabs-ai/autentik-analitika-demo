<?php
/**
 * Analitik berbasis persetujuan (UU PDP No. 27/2022).
 * - ID GA4 / GTM & kode verifikasi diisi di Tampilan › Sesuaikan › Analitik & Verifikasi.
 * - Consent Mode v2 mode DASAR: default semua "denied"; skrip Google baru dimuat setelah pengunjung menekan "Izinkan".
 * - Tidak ada yang dimuat bila ID kosong, di Customizer, atau untuk staf yang login (lalu lintas internal).
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customizer: ID & verifikasi.
 */
function autentik_analytics_customize( $wp_customize ) {
	$wp_customize->add_section( 'aa_analitik', array( 'title' => 'Analitik & Verifikasi', 'priority' => 160 ) );
	$fields = array(
		'ga4_id'      => array( 'ID GA4 (G-XXXXXXXXXX)', 'Kosongkan bila memakai GTM.', '/^G-[A-Z0-9]{6,12}$/' ),
		'gtm_id'      => array( 'ID Google Tag Manager (GTM-XXXXXXX)', 'Bila diisi, GTM dipakai dan ID GA4 di atas diabaikan (GA4 dipasang di dalam GTM).', '/^GTM-[A-Z0-9]{5,10}$/' ),
		'gsc_verify'  => array( 'Verifikasi Google Search Console', 'Isi nilai content="…" saja. Lewati bila memakai verifikasi DNS atau Rank Math.', '/^[A-Za-z0-9_\-]{20,80}$/' ),
		'bing_verify' => array( 'Verifikasi Bing Webmaster (msvalidate.01)', 'Isi nilai content="…" saja.', '/^[A-F0-9]{32}$/' ),
	);
	foreach ( $fields as $key => $f ) {
		$re = $f[2];
		$up = in_array( $key, array( 'ga4_id', 'gtm_id', 'bing_verify' ), true );
		$wp_customize->add_setting(
			'aa_' . $key,
			array(
				'default'           => '',
				'sanitize_callback' => function ( $v ) use ( $re, $up ) {
					$v = trim( (string) $v );
					if ( $up ) {
						$v = strtoupper( $v );
					}
					return preg_match( $re, $v ) ? $v : '';
				},
			)
		);
		$wp_customize->add_control( 'aa_' . $key, array( 'label' => $f[0], 'description' => $f[1], 'section' => 'aa_analitik', 'type' => 'text' ) );
	}
}
add_action( 'customize_register', 'autentik_analytics_customize' );

/**
 * Apakah analitik aktif untuk permintaan ini.
 */
function autentik_analytics_on() {
	if ( is_admin() || is_customize_preview() || current_user_can( 'edit_posts' ) ) {
		return false;
	}
	return (bool) ( autentik_opt( 'gtm_id' ) || autentik_opt( 'ga4_id' ) );
}

/**
 * Jenis halaman → content_group GA4.
 */
function autentik_analytics_page_type() {
	if ( is_front_page() ) {
		return 'beranda';
	}
	if ( is_page_template( 'page-templates/landing.php' ) ) {
		return 'landing';
	}
	if ( is_singular( 'layanan' ) ) {
		return 'bidang-praktik';
	}
	if ( is_singular( 'tim' ) ) {
		return 'profil-tim';
	}
	if ( is_singular( 'post' ) ) {
		return 'artikel';
	}
	if ( is_search() ) {
		return 'pencarian';
	}
	if ( is_home() || is_archive() ) {
		return 'publikasi';
	}
	if ( is_404() ) {
		return '404';
	}
	if ( is_page( array( 'layanan', 'tim', 'kontak', 'tentang-kami', 'klien', 'kebijakan-privasi' ) ) ) {
		return get_post_field( 'post_name', get_queried_object_id() );
	}
	return 'halaman';
}

/**
 * <head>: verifikasi (selalu) + konfigurasi & consent default (tanpa permintaan jaringan).
 */
function autentik_analytics_head() {
	if ( autentik_opt( 'gsc_verify' ) ) {
		echo '<meta name="google-site-verification" content="' . esc_attr( autentik_opt( 'gsc_verify' ) ) . '">' . "\n";
	}
	if ( autentik_opt( 'bing_verify' ) ) {
		echo '<meta name="msvalidate.01" content="' . esc_attr( autentik_opt( 'bing_verify' ) ) . '">' . "\n";
	}
	if ( ! autentik_analytics_on() ) {
		return;
	}
	$cfg = array(
		'ga4'  => autentik_opt( 'ga4_id' ),
		'gtm'  => autentik_opt( 'gtm_id' ),
		'v'    => 1,   // naikkan bila isi banner/tujuan berubah → semua pengunjung ditanya ulang
		'days' => 365, // persetujuan berlaku 12 bulan
		'pt'   => autentik_analytics_page_type(),
		'pa'   => is_singular( 'layanan' ) ? autentik_plain_title() : '',
		'adv'  => is_singular( 'tim' ) ? autentik_plain_title() : '',
	);
	echo "<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}"
		. "gtag('consent','default',{ad_storage:'denied',ad_user_data:'denied',ad_personalization:'denied',analytics_storage:'denied',functionality_storage:'granted',security_storage:'granted'});"
		. 'window.AA_AN=' . wp_json_encode( $cfg ) . ";</script>\n";
}
add_action( 'wp_head', 'autentik_analytics_head', 1 );

/**
 * Skrip pendengar event + banner.
 */
function autentik_analytics_assets() {
	if ( autentik_analytics_on() ) {
		wp_enqueue_script( 'autentik-analytics', AUTENTIK_URI . '/assets/js/analytics.js', array(), AUTENTIK_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
	}
}
add_action( 'wp_enqueue_scripts', 'autentik_analytics_assets' );

function autentik_analytics_banner() {
	if ( ! autentik_analytics_on() ) {
		autentik_analytics_status_panel();
		return;
	}
	?>
	<div class="aa-cc" id="aa-cc" role="region" aria-label="Persetujuan cookie analitik" hidden>
		<p class="aa-cc-t">Bolehkah kami menghitung kunjungan Anda?</p>
		<p>Dengan izin Anda, kami memakai Google Analytics untuk melihat halaman yang dibuka dan tombol yang diklik, agar situs ini bisa kami perbaiki. Isi formulir konsultasi tidak dikirim ke Google. Anda bisa mengubah pilihan kapan saja lewat tautan <a href="#pengaturan-cookie">Pengaturan cookie</a> di <a href="<?php echo esc_url( home_url( '/kebijakan-privasi/#analitik' ) ); ?>">Kebijakan Privasi</a>.</p>
		<div class="aa-cc-b">
			<button type="button" data-cc="denied">Tolak</button>
			<button type="button" data-cc="granted">Izinkan</button>
		</div>
	</div>
	<style>
	/* Tolak & Izinkan sengaja setara (tanpa dark pattern). */
	.aa-cc{position:fixed;z-index:1000;left:16px;right:16px;bottom:16px;max-width:520px;background:var(--bg,#fff);color:var(--ink-2,#3E4A5E);border:1px solid var(--line-2,rgba(10,50,102,.22));border-top:3px solid var(--gold,#EAB466);border-radius:var(--r,4px);box-shadow:var(--sh-h);padding:18px 20px;font:14px/1.6 var(--sans)}
	.aa-cc[hidden]{display:none}
	.aa-cc-t{margin:0 0 6px;font:600 1.05rem/1.3 var(--serif);color:var(--ink,#0B1F3F)}
	.aa-cc p{margin:0}.aa-cc a{color:var(--navy,#0A3266)}
	.aa-cc-b{display:flex;gap:10px;margin-top:14px}
	.aa-cc-b button{flex:1;min-height:44px;border-radius:var(--r-s,2px);font:600 .9rem var(--sans);cursor:pointer;border:1.5px solid var(--navy,#0A3266);background:var(--bg,#fff);color:var(--navy,#0A3266)}
	.aa-cc-b button:hover{background:var(--navy,#0A3266);color:#fff}
	@media print{.aa-cc{display:none!important}}
	</style>
	<?php
}
add_action( 'wp_footer', 'autentik_analytics_banner', 5 );

/**
 * Saat analitik TIDAK aktif, tautan "Pengaturan cookie" (footer & Kebijakan Privasi) tetap berfungsi:
 * membuka panel kecil yang menjelaskan status analitik. Tanpa JS, panel terbuka lewat :target (#pengaturan-cookie).
 */
function autentik_analytics_status_panel() {
	if ( is_admin() || is_customize_preview() ) {
		return;
	}
	$ada_id = (bool) ( autentik_opt( 'gtm_id' ) || autentik_opt( 'ga4_id' ) );
	$teks   = $ada_id
		? 'Analitik tidak dimuat untuk kunjungan Anda saat ini (staf yang sedang masuk ke dasbor tidak dihitung). Tidak ada cookie Google Analytics yang dipasang.'
		: 'Situs ini sedang tidak memakai analitik atau cookie pelacak. Kami hanya menyimpan data teknis yang diperlukan agar situs berfungsi, misalnya isian formulir yang belum terkirim di peramban Anda sendiri.';
	?>
	<div class="aa-cc aa-cc-off" id="pengaturan-cookie" role="dialog" aria-modal="false" aria-labelledby="aa-cc-off-t" tabindex="-1" hidden>
		<p class="aa-cc-t" id="aa-cc-off-t">Pengaturan cookie</p>
		<p><?php echo esc_html( $teks ); ?> Bila kelak analitik diaktifkan, kami akan meminta izin Anda lebih dulu. Rinciannya ada di <a href="<?php echo esc_url( home_url( '/kebijakan-privasi/#analitik' ) ); ?>">Kebijakan Privasi</a>.</p>
		<div class="aa-cc-b"><a class="aa-cc-x" href="#" data-cc-close>Tutup</a></div>
	</div>
	<style>
	.aa-cc{position:fixed;z-index:1000;left:16px;right:16px;bottom:16px;max-width:520px;background:var(--bg,#fff);color:var(--ink-2,#3E4A5E);border:1px solid var(--line-2,rgba(10,50,102,.22));border-top:3px solid var(--gold,#EAB466);border-radius:var(--r,4px);box-shadow:var(--sh-h);padding:18px 20px;font:14px/1.6 var(--sans)}
	.aa-cc[hidden]{display:none}
	.aa-cc-off:not(.js):target{display:block} /* tanpa JS */
	.aa-cc-t{margin:0 0 6px;font:600 1.05rem/1.3 var(--serif);color:var(--ink,#0B1F3F)}
	.aa-cc p{margin:0}.aa-cc a{color:var(--navy,#0A3266)}
	.aa-cc-b{display:flex;gap:10px;margin-top:14px}
	.aa-cc-x{flex:1;display:grid;place-items:center;min-height:44px;border-radius:var(--r-s,2px);font:600 .9rem var(--sans);text-decoration:none;border:1.5px solid var(--navy,#0A3266);background:var(--bg,#fff);color:var(--navy,#0A3266)}
	.aa-cc-x:hover{background:var(--navy,#0A3266);color:#fff}
	@media (max-width:760px){.aa-cc{bottom:calc(76px + env(safe-area-inset-bottom))}}
	@media print{.aa-cc{display:none!important}}
	</style>
	<script>
	(function(){var p=document.getElementById('pengaturan-cookie');if(!p)return;p.classList.add('js');var back=null;
	function show(){back=document.activeElement;p.hidden=false;p.focus();}
	function hide(){p.hidden=true;if(location.hash==='#pengaturan-cookie')history.replaceState(null,'',location.pathname+location.search);if(back&&back.focus)back.focus();}
	document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href$="#pengaturan-cookie"]');if(a){e.preventDefault();show();return;}if(e.target.closest&&e.target.closest('[data-cc-close]')){e.preventDefault();hide();}});
	document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!p.hidden)hide();});
	function fromHash(){if(location.hash==='#pengaturan-cookie')show();}
	addEventListener('hashchange',fromHash);fromHash();})();
	</script>
	<?php
}
