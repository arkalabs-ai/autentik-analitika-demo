<?php
/**
 * Penata halaman: isi tetap diedit di editor blok, lalu dipecah per Heading 2
 * agar bisa ditampilkan sebagai bagian-bagian yang dirancang (Tentang Kami, dokumen hukum).
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pecah blok menjadi bagian per Heading 2.
 *
 * @return array<int, array{title:string, blocks:array}>
 */
function autentik_sections( array $blocks ) {
	$out = array();
	$cur = array( 'title' => '', 'blocks' => array() );
	foreach ( $blocks as $b ) {
		if ( 'core/heading' === $b['blockName'] && 2 === (int) ( $b['attrs']['level'] ?? 2 ) ) {
			if ( $cur['title'] || $cur['blocks'] ) {
				$out[] = $cur;
			}
			$cur = array( 'title' => trim( wp_strip_all_tags( $b['innerHTML'] ) ), 'blocks' => array() );
			continue;
		}
		if ( $b['blockName'] || '' !== trim( $b['innerHTML'] ) ) {
			$cur['blocks'][] = $b;
		}
	}
	if ( $cur['title'] || $cur['blocks'] ) {
		$out[] = $cur;
	}
	return $out;
}

/**
 * Jenis bagian berdasarkan isinya: legal (tabel), num (daftar bernomor), vals (daftar), statement, text.
 */
function autentik_section_kind( array $sec ) {
	$types = wp_list_pluck( $sec['blocks'], 'blockName' );
	if ( in_array( 'core/table', $types, true ) ) {
		return 'legal';
	}
	foreach ( $sec['blocks'] as $b ) {
		if ( 'core/list' === $b['blockName'] ) {
			return ! empty( $b['attrs']['ordered'] ) || false !== strpos( $b['innerHTML'], '<ol' ) ? 'num' : 'vals';
		}
	}
	$paras = array_filter( $sec['blocks'], function ( $b ) { return 'core/paragraph' === $b['blockName']; } );
	if ( $paras && count( $paras ) <= 2 && count( $paras ) === count( $sec['blocks'] ) && false !== strpos( reset( $paras )['innerHTML'], '<strong>' ) ) {
		return 'statement';
	}
	return 'text';
}

/**
 * Render blok seperti isi biasa (shortcode, embed, dll. tetap jalan).
 */
function autentik_render_blocks( array $blocks ) {
	return apply_filters( 'the_content', serialize_blocks( $blocks ) );
}

/**
 * Butir daftar "<strong>Judul</strong> <em>(Inggris)</em> — teks" → [judul, inggris, teks].
 *
 * @return array<int, array{0:string,1:string,2:string}>
 */
function autentik_li_parts( $html ) {
	preg_match_all( '#<li[^>]*>(.*?)</li>#s', $html, $m );
	$out = array();
	foreach ( $m[1] as $li ) {
		$t  = preg_match( '#<strong>(.*?)</strong>#s', $li, $a ) ? trim( wp_strip_all_tags( $a[1] ) ) : '';
		$en = preg_match( '#<em>(.*?)</em>#s', $li, $b ) ? trim( wp_strip_all_tags( $b[1] ), " ()" ) : '';
		$tx = trim( wp_strip_all_tags( preg_replace( '#<strong>.*?</strong>|<em>.*?</em>#s', '', $li ) ) );
		$tx = preg_replace( '/^[\s—–:-]+/u', '', $tx );
		$out[] = array( $t, $en, $tx );
	}
	return $out;
}

/**
 * Baris tabel dua kolom → [label, nilai].
 *
 * @return array<int, array{0:string,1:string}>
 */
function autentik_table_rows( $html ) {
	preg_match_all( '#<tr[^>]*>(.*?)</tr>#s', $html, $rows );
	$out = array();
	foreach ( $rows[1] as $r ) {
		preg_match_all( '#<t[dh][^>]*>(.*?)</t[dh]>#s', $r, $c );
		if ( count( $c[1] ) >= 2 ) {
			$out[] = array( trim( wp_strip_all_tags( $c[1][0] ) ), trim( wp_strip_all_tags( $c[1][1] ) ) );
		}
	}
	return $out;
}
