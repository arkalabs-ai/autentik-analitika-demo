<?php
/**
 * Fungsi bantu.
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ambil field SCF/ACF — tetap berfungsi walau plugin SCF nonaktif (baca post meta langsung).
 */
function autentik_field( $name, $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( function_exists( 'get_field' ) ) {
		return get_field( $name, $post_id );
	}
	return get_post_meta( $post_id, $name, true );
}

/**
 * Ambil baris repeater tanpa bergantung pada SCF.
 *
 * @return array<int, array<string,string>>
 */
function autentik_rows( $name, array $subs, $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( function_exists( 'get_field' ) ) {
		$v = get_field( $name, $post_id );
		if ( is_array( $v ) ) {
			return $v;
		}
	}
	$n    = (int) get_post_meta( $post_id, $name, true );
	$rows = array();
	for ( $i = 0; $i < $n; $i++ ) {
		$row = array();
		foreach ( $subs as $s ) {
			$row[ $s ] = (string) get_post_meta( $post_id, "{$name}_{$i}_{$s}", true );
		}
		$rows[] = $row;
	}
	return $rows;
}

/**
 * Ikon dari sprite SVG di footer.
 */
function autentik_icon( $name, $class = '' ) {
	return '<svg class="ico ' . esc_attr( $class ) . '" aria-hidden="true"><use href="#i-' . esc_attr( $name ) . '"/></svg>';
}

/**
 * Gambar bawaan tema (dipakai bila belum ada gambar unggulan).
 */
function autentik_img( $file ) {
	// Tema tidak lagi membawa JPEG 2000 px asli (zip ringan, 46g T5): "nama.jpg" dialihkan ke "nama-1600.webp".
	if ( preg_match( '/\.jpe?g$/i', $file ) && ! file_exists( AUTENTIK_DIR . '/assets/img/' . $file ) ) {
		$webp = preg_replace( '/\.jpe?g$/i', '-1600.webp', $file );
		if ( file_exists( AUTENTIK_DIR . '/assets/img/' . $webp ) ) {
			$file = $webp;
		}
	}
	return AUTENTIK_URI . '/assets/img/' . $file;
}

/**
 * Gambar bawaan untuk tiap layanan.
 */
function autentik_layanan_img( $post_id, $size = 'autentik-card' ) {
	if ( has_post_thumbnail( $post_id ) ) {
		return get_the_post_thumbnail_url( $post_id, $size );
	}
	$map = array(
		'hukum'              => 'hukum.jpg',
		'perizinan'          => 'perizinan.jpg',
		'kenotariatan'       => 'kenotariatan.jpg',
		'pertanahan'         => 'pertanahan.jpg',
		'korporasi'          => 'korporasi.jpg',
		'investasi-properti' => 'investasi.jpg',
	);
	$slug = get_post_field( 'post_name', $post_id );
	return autentik_img( isset( $map[ $slug ] ) ? $map[ $slug ] : 'hukum.jpg' );
}

/**
 * Keterangan berbasis tugas per layanan (menu, pencarian): kata yang dipakai orang saat mencari.
 */
function autentik_layanan_tugas() {
	return apply_filters(
		'autentik_layanan_tugas',
		array(
			'hukum'              => 'Kontrak, somasi, dan gugatan',
			'perizinan'          => 'NIB, OSS, dan izin usaha',
			'kenotariatan'       => 'Pendirian PT, CV, dan yayasan',
			'pertanahan'         => 'Pemeriksaan sertifikat, balik nama, dan waris',
			'korporasi'          => 'RUPS, kepatuhan, dan uji tuntas',
			'investasi-properti' => 'Pembelian lahan dan properti',
		)
	);
}

/**
 * Ikon per layanan (nama simbol di sprite).
 */
function autentik_layanan_icon( $post_id ) {
	$map  = array(
		'hukum'              => 'scale',
		'perizinan'          => 'badge',
		'kenotariatan'       => 'pen',
		'pertanahan'         => 'map',
		'korporasi'          => 'building',
		'investasi-properti' => 'chart',
	);
	$slug = get_post_field( 'post_name', $post_id );
	return isset( $map[ $slug ] ) ? $map[ $slug ] : 'scale';
}

/**
 * Kategori artikel ↔ layanan (untuk artikel terkait dan layanan terkait).
 */
function autentik_cat_to_layanan() {
	return apply_filters(
		'autentik_cat_to_layanan',
		array(
			'hukum'        => 'hukum',
			'perizinan'    => 'perizinan',
			'kenotariatan' => 'kenotariatan',
			'pertanahan'   => 'pertanahan',
			'korporasi'    => 'korporasi',
			'investasi'    => 'investasi-properti',
		)
	);
}

/**
 * Inisial nama untuk avatar cadangan.
 */
function autentik_initials( $name ) {
	$name  = preg_replace( '/^Dr\.?\s*/i', '', $name );
	$parts = preg_split( '/\s+/', trim( $name ) );
	$a     = isset( $parts[0] ) ? mb_substr( $parts[0], 0, 1 ) : '';
	$b     = isset( $parts[1] ) ? mb_substr( $parts[1], 0, 1 ) : '';
	return mb_strtoupper( $a . $b );
}

/**
 * srcset WebP untuk gambar tema (assets/img/{nama}-{480|768|1024|1600}.webp).
 * Menerima URL apa pun; bila bukan gambar tema atau varian tidak ada, mengembalikan string kosong.
 */
function autentik_srcset( $url, $sizes = '(max-width:760px) 100vw, 50vw' ) {
	$base = trailingslashit( AUTENTIK_URI ) . 'assets/img/';
	if ( 0 !== strpos( (string) $url, $base ) ) {
		return '';
	}
	$stem = preg_replace( '/(-\d+)?\.(jpe?g|png|webp)$/', '', substr( $url, strlen( $base ) ) );
	$out  = array();
	foreach ( array( 480, 768, 1024, 1600 ) as $w ) {
		if ( file_exists( AUTENTIK_DIR . "/assets/img/{$stem}-{$w}.webp" ) ) {
			$out[] = esc_url( $base . "{$stem}-{$w}.webp" ) . " {$w}w";
		}
	}
	return $out ? ' srcset="' . esc_attr( implode( ', ', $out ) ) . '" sizes="' . esc_attr( $sizes ) . '"' : '';
}

/**
 * Judul polos (tanpa entitas HTML) untuk WhatsApp, JSON-LD, dan llms.txt.
 */
function autentik_plain_title( $p = null ) {
	return html_entity_decode( wp_strip_all_tags( get_the_title( $p ) ), ENT_QUOTES, 'UTF-8' );
}

/**
 * Perkiraan waktu baca.
 */
function autentik_read_minutes( $post_id = null ) {
	$words = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ? $post_id : get_the_ID() ) ) );
	return max( 1, (int) ceil( $words / 200 ) );
}

/**
 * Link WhatsApp dengan pesan pra-isi.
 */
function autentik_wa( $pesan = '' ) {
	$no = preg_replace( '/\D+/', '', (string) autentik_opt( 'wa' ) );
	if ( 0 === strpos( $no, '0' ) ) {
		$no = '62' . substr( $no, 1 );
	}
	if ( '' === $no ) {
		return home_url( '/kontak/' );
	}
	if ( '' === $pesan ) {
		$pesan = autentik_sapa() . 'Saya ingin berkonsultasi mengenai persoalan hukum.';
	}
	return 'https://wa.me/' . $no . '?text=' . rawurlencode( $pesan );
}

/**
 * Daftar layanan (CPT), terurut.
 */
function autentik_layanan( $exclude = 0 ) {
	return get_posts(
		array(
			'post_type'   => 'layanan',
			'numberposts' => 12,
			'orderby'     => 'menu_order',
			'order'       => 'ASC',
			'exclude'     => $exclude ? array( $exclude ) : array(),
		)
	);
}

/**
 * Breadcrumb HTML (skemanya dibuat di seo-geo.php).
 */
function autentik_breadcrumb( array $items ) {
	echo '<nav aria-label="Remah roti"><ol class="crumb">';
	echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Beranda</a></li>';
	foreach ( $items as $it ) {
		if ( ! empty( $it[1] ) ) {
			echo '<li><a href="' . esc_url( $it[1] ) . '">' . esc_html( $it[0] ) . '</a></li>';
		} else {
			echo '<li aria-current="page">' . esc_html( $it[0] ) . '</li>';
		}
	}
	echo '</ol></nav>';
	$GLOBALS['autentik_crumbs'] = $items;
}

/**
 * Gambar banner halaman dalam untuk permintaan ini (satu sumber: dipakai template dan preload di <head>).
 */
function autentik_banner_bg() {
	static $bg = null;
	if ( null !== $bg ) {
		return $bg;
	}
	$id  = get_queried_object_id();
	$def = array( 'tentang-kami' => 'korporasi.jpg', 'layanan' => 'kenotariatan.jpg', 'kontak' => 'kontak.jpg', 'tim' => 'tim.jpg', 'klien' => 'investasi.jpg' );
	$bg  = '';
	if ( is_front_page() || is_page_template( 'page-templates/landing.php' ) || is_singular( 'tim' ) ) {
		return $bg;
	}
	if ( is_singular( 'layanan' ) ) {
		$bg = autentik_layanan_img( $id, 'autentik-wide' );
	} elseif ( is_singular( 'post' ) ) {
		$lay = autentik_post_layanan( $id );
		$bg  = has_post_thumbnail( $id ) ? get_the_post_thumbnail_url( $id, 'autentik-wide' ) : ( $lay ? autentik_layanan_img( $lay->ID, 'autentik-wide' ) : autentik_img( 'hukum.jpg' ) );
	} elseif ( is_home() || is_archive() || ( is_search() && 'post' === get_query_var( 'post_type' ) ) ) {
		$bg = autentik_img( 'publikasi.jpg' );
	} elseif ( is_search() ) {
		$bg = autentik_img( 'hukum.jpg' );
	} elseif ( is_page() ) {
		$slug = get_post_field( 'post_name', $id );
		$bg   = has_post_thumbnail( $id ) ? get_the_post_thumbnail_url( $id, 'autentik-wide' ) : autentik_img( isset( $def[ $slug ] ) ? $def[ $slug ] : 'kota.jpg' );
	} else {
		$bg = autentik_img( 'kota.jpg' );
	}
	return $bg;
}

/**
 * Daftar "url lebar" untuk srcset: varian WebP tema, atau ukuran lampiran WordPress bila gambar diunggah.
 */
function autentik_srcset_urls( $url ) {
	$base = trailingslashit( AUTENTIK_URI ) . 'assets/img/';
	if ( 0 === strpos( (string) $url, $base ) ) {
		$stem = preg_replace( '/(-\d+)?\.(jpe?g|png|webp)$/', '', substr( $url, strlen( $base ) ) );
		$out  = array();
		foreach ( array( 480, 768, 1024, 1600 ) as $w ) {
			if ( file_exists( AUTENTIK_DIR . "/assets/img/{$stem}-{$w}.webp" ) ) {
				$out[] = $base . "{$stem}-{$w}.webp {$w}w";
			}
		}
		return implode( ', ', $out );
	}
	$att = $url ? attachment_url_to_postid( $url ) : 0;
	return $att ? (string) wp_get_attachment_image_srcset( $att, 'autentik-wide' ) : '';
}

/**
 * Ukuran tampil banner. Desktop: foto ±66% lebar layar (qa/45 E1).
 * HP: foto hanya pita tipis di atas judul; 256px sengaja di bawah lebar tampil agar layar 3x
 * memilih varian 768 (±60 KB), bukan 1600 (±300 KB) yang menjadi LCP (qa/46c T1).
 */
if ( ! defined( 'AUTENTIK_BANNER_SIZES' ) ) {
	define( 'AUTENTIK_BANNER_SIZES', '(max-width:760px) 256px, 66vw' );
}

/**
 * Preload gambar banner di <head> agar LCP halaman dalam di HP tidak menunggu CSS (qa/41 P0-3).
 */
function autentik_preload_banner() {
	$bg = autentik_banner_bg();
	if ( ! $bg ) {
		return;
	}
	$set = autentik_srcset_urls( $bg );
	echo '<link rel="preload" as="image" href="' . esc_url( $bg ) . '"' . ( $set ? ' imagesrcset="' . esc_attr( $set ) . '" imagesizes="' . esc_attr( AUTENTIK_BANNER_SIZES ) . '"' : '' ) . ' fetchpriority="high">' . "\n";
}
add_action( 'wp_head', 'autentik_preload_banner', 1 );

/**
 * Banner halaman dalam: judul rata kiri bergaris emas, foto kontekstual di kanan (HP: foto tipis di atas).
 */
function autentik_banner( $title, $dek = '', array $crumbs = array(), $bg = '' ) {
	$bg = $bg ? $bg : autentik_banner_bg();
	$bg = $bg ? $bg : autentik_img( 'kota.jpg' );
	$set = autentik_srcset_urls( $bg );
	?>
	<section class="ban ban2">
		<div class="wrap ban-in">
			<div class="ban-t">
				<?php autentik_breadcrumb( $crumbs ); ?>
				<h1><?php echo esc_html( $title ); ?></h1>
				<?php if ( $dek ) : ?>
					<p class="dek"><?php echo esc_html( $dek ); ?></p>
				<?php endif; ?>
			</div>
			<figure class="ban-ph" aria-hidden="true"><img class="bg" src="<?php echo esc_url( $bg ); ?>"<?php echo $set ? ' srcset="' . esc_attr( $set ) . '" sizes="' . esc_attr( AUTENTIK_BANNER_SIZES ) . '"' : ''; // phpcs:ignore ?> alt="" width="1000" height="667" fetchpriority="high"></figure>
		</div>
	</section>
	<?php
}

/**
 * Judul seksi.
 */
function autentik_sh( $eyebrow, $title, $text = '', $left = false ) {
	echo '<div class="sh' . ( $left ? ' left' : '' ) . ' rv"><h2>' . esc_html( $title ) . '</h2>'; // $eyebrow tidak dicetak lagi (judul cukup berdiri sendiri)
	if ( $text ) {
		echo '<p>' . esc_html( $text ) . '</p>';
	}
	echo '</div>';
}

/**
 * Nilai unggulan & langkah kerja (dapat diubah lewat filter).
 */
function autentik_why() {
	return apply_filters(
		'autentik_why',
		array(
			array( 'receipt', 'Biaya disepakati di awal', 'Lingkup pekerjaan, perkiraan waktu, dan biaya jasa hukum kami cantumkan dalam penawaran. Pekerjaan baru berjalan setelah Anda setuju.' ),
			array( 'user', 'Satu penanggung jawab', 'Setiap perkara dipegang satu penanggung jawab yang namanya tercantum dalam penawaran. Selama pekerjaan berjalan, Anda cukup menghubungi orang yang sama.' ),
			array( 'layers', 'Satu tim untuk urusan yang saling terkait', 'Kontrak, izin, dan tanah sering bertemu dalam satu persoalan. Karena ditangani satu tim, Anda tidak perlu mengulang cerita yang sama kepada beberapa pihak.' ),
			array( 'shield', 'Kerahasiaan dan benturan kepentingan', 'Sebelum menerima perkara, kami pastikan tidak sedang mewakili pihak lawan Anda. Keterangan dan dokumen Anda hanya dibahas tim yang menangani.' ),
		)
	);
}

/**
 * Alur penanganan. Kolom ke-3: yang dipegang klien di tahap itu (tampil di beranda).
 */
function autentik_steps() {
	return apply_filters(
		'autentik_steps',
		array(
			array( 'Konsultasi', 'Anda menceritakan persoalannya, kami bertanya sampai duduk perkaranya jelas. Di tahap ini kami juga memastikan persoalan Anda memang masuk bidang yang kami tangani.', 'Kepastian bahwa kami tidak sedang mewakili pihak lawan Anda. Keterangan Anda hanya diketahui tim yang menangani.' ),
			array( 'Telaah', 'Kami membaca dokumen Anda, memeriksa dasar hukumnya, dan menilai kedudukan masing-masing pihak. Setelah itu kami jelaskan pilihan langkah yang ada, lengkap dengan risikonya.', 'Pilihan langkah hukum beserta risikonya, dan daftar dokumen yang masih kurang.' ),
			array( 'Penawaran', 'Anda menerima penawaran berisi lingkup pekerjaan, dokumen yang perlu disiapkan, perkiraan waktu, dan biaya jasa hukum. Tidak ada pekerjaan yang berjalan sebelum Anda setuju.', 'Lingkup, waktu, biaya, dan nama penanggung jawab, jelas sebelum Anda memutuskan.' ),
			array( 'Pelaksanaan', 'Setelah perjanjian jasa hukum ditandatangani, kami kerjakan urusan Anda sesuai lingkup yang disepakati dan mengabarkan perkembangannya di setiap tahap penting.', 'Satu penanggung jawab yang dapat Anda hubungi langsung, dan laporan di setiap tahap penting.' ),
		)
	);
}

/**
 * FAQ dari blok "Details" di sebuah halaman (agar bisa diedit lewat editor).
 *
 * @return array<int, array{0:string,1:string}>
 */
function autentik_faq_from_page( $page_id ) {
	$out = array();
	if ( ! $page_id ) {
		return $out;
	}
	foreach ( parse_blocks( get_post_field( 'post_content', $page_id ) ) as $b ) {
		if ( 'core/details' !== $b['blockName'] ) {
			continue;
		}
		if ( preg_match( '#<summary>(.*?)</summary>#s', $b['innerHTML'], $m ) ) {
			$a = '';
			foreach ( $b['innerBlocks'] as $ib ) {
				$a .= ' ' . wp_strip_all_tags( render_block( $ib ) );
			}
			$out[] = array( wp_strip_all_tags( $m[1] ), trim( $a ) );
		}
	}
	return $out;
}

/**
 * Cetak akordeon FAQ.
 */
function autentik_faq_html( array $faq ) {
	if ( ! $faq ) {
		return;
	}
	echo '<div class="faq">';
	foreach ( $faq as $i => $q ) {
		$tanya = isset( $q['tanya'] ) ? $q['tanya'] : $q[0];
		$jawab = isset( $q['jawab'] ) ? $q['jawab'] : $q[1];
		echo '<details' . ( 0 === $i ? ' open' : '' ) . '><summary>' . esc_html( $tanya ) . '<span class="pm">' . autentik_icon( 'plus' ) . '</span></summary><div class="a">' . esc_html( $jawab ) . '</div></details>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</div>';
	$GLOBALS['autentik_faq'] = array_merge( isset( $GLOBALS['autentik_faq'] ) ? $GLOBALS['autentik_faq'] : array(), $faq );
}

/**
 * Kartu artikel.
 */
function autentik_post_img( $post, $size = 'autentik-card' ) {
	if ( has_post_thumbnail( $post ) ) {
		return get_the_post_thumbnail_url( $post, $size );
	}
	$cat  = get_the_category( $post->ID );
	$map  = autentik_cat_to_layanan();
	$slug = ( $cat && isset( $map[ $cat[0]->slug ] ) ) ? $map[ $cat[0]->slug ] : '';
	$lay  = $slug ? get_page_by_path( $slug, OBJECT, 'layanan' ) : null;
	return $lay ? autentik_layanan_img( $lay->ID, $size ) : autentik_img( 'hukum.jpg' );
}

/**
 * Tag <img> gambar artikel dengan srcset (gambar unggulan WordPress atau gambar tema WebP).
 */
function autentik_post_img_tag( $post, $size = 'autentik-card', $sizes = '(max-width:760px) 92vw, 33vw', $lazy = true ) {
	if ( has_post_thumbnail( $post ) ) {
		return get_the_post_thumbnail( $post, $size, array( 'alt' => '', 'sizes' => $sizes, 'loading' => $lazy ? 'lazy' : false, 'fetchpriority' => $lazy ? false : 'high' ) );
	}
	$url = autentik_post_img( $post, $size );
	return '<img src="' . esc_url( $url ) . '"' . autentik_srcset( $url, $sizes ) . ' alt="" ' . ( $lazy ? 'loading="lazy"' : 'fetchpriority="high"' ) . ' width="1000" height="667">';
}

function autentik_post_card( $post ) {
	$cat = get_the_category( $post->ID );
	?>
	<a class="pc rv" href="<?php echo esc_url( get_permalink( $post ) ); ?>">
		<div class="img"><?php echo autentik_post_img_tag( $post ); // phpcs:ignore ?>
			<?php if ( $cat ) : ?><span class="cat"><?php echo esc_html( $cat[0]->name ); ?></span><?php endif; ?>
		</div>
		<div class="body">
			<div class="meta"><span><?php echo esc_html( get_the_date( 'j M Y', $post ) ); ?></span><span><?php echo (int) autentik_read_minutes( $post->ID ); ?> menit baca</span></div>
			<h3><?php echo esc_html( get_the_title( $post ) ); ?></h3>
			<p><?php echo esc_html( get_the_excerpt( $post ) ); ?></p>
			<?php list( $by ) = autentik_post_people( $post->ID ); ?>
			<?php if ( $by ) : ?><span class="by"><?php echo autentik_avatar( $by, 'thumbnail', 'f' ); // phpcs:ignore ?><?php echo esc_html( get_the_title( $by ) ); ?></span><?php endif; ?>
			<span class="more">Baca Artikel <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span>
		</div>
	</a>
	<?php
}

/**
 * Publikasi utama (paling baru) di halaman daftar publikasi.
 */
function autentik_post_lead( $post ) {
	$cat = get_the_category( $post->ID );
	list( $by, $rev ) = autentik_post_people( $post->ID );
	?>
	<a class="plead rv" href="<?php echo esc_url( get_permalink( $post ) ); ?>">
		<span class="img"><?php echo autentik_post_img_tag( $post, 'autentik-wide', '(max-width:760px) 92vw, 50vw', false ); // phpcs:ignore ?></span>
		<span class="body">
			<?php if ( $cat ) : ?><span class="eyebrow"><?php echo esc_html( $cat[0]->name ); ?></span><?php endif; ?>
			<h3><?php echo esc_html( get_the_title( $post ) ); ?></h3>
			<span class="ex"><?php echo esc_html( get_the_excerpt( $post ) ); ?></span>
			<span class="meta"><?php echo esc_html( get_the_date( 'j F Y', $post ) ); ?> · <?php echo (int) autentik_read_minutes( $post->ID ); ?> menit baca</span>
			<?php if ( $by ) : ?><span class="meta">Ditulis oleh <?php echo esc_html( get_the_title( $by ) ); ?><?php echo $rev ? ', ditinjau oleh ' . esc_html( get_the_title( $rev ) ) : ''; ?></span><?php endif; ?>
			<span class="more">Baca Artikel <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span>
		</span>
	</a>
	<?php
}

/**
 * Kartu layanan.
 */
function autentik_layanan_card( $p, $n, $link = true ) {
	$lingkup = autentik_rows( 'lingkup', array( 'teks', 'teks_en' ), $p->ID );
	$tag     = $link ? 'a' : 'div';
	?>
	<<?php echo $tag; // phpcs:ignore ?> class="svc rv<?php echo $link ? '' : ' static'; ?>"<?php echo $link ? ' href="' . esc_url( get_permalink( $p ) ) . '"' : ''; // phpcs:ignore ?>>
		<div class="img"><img src="<?php echo esc_url( autentik_layanan_img( $p->ID ) ); ?>"<?php echo autentik_srcset( autentik_layanan_img( $p->ID ), '(max-width:760px) 92vw, 50vw' ); // phpcs:ignore ?> alt="" loading="lazy" width="720" height="405"></div>
		<div class="body">
			<h3><?php echo esc_html( get_the_title( $p ) ); ?></h3>
			<p><?php echo esc_html( autentik_field( 'dek', $p->ID ) ? (string) autentik_field( 'dek', $p->ID ) : get_the_excerpt( $p ) ); ?></p>
			<?php if ( $lingkup ) : ?><ul class="sc3"><?php foreach ( array_slice( $lingkup, 0, 3 ) as $r ) : ?><li><?php echo esc_html( $r['teks'] ); ?></li><?php endforeach; ?></ul><?php endif; ?>
			<?php if ( $link ) : ?><span class="go" aria-hidden="true"><?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span><?php endif; ?>
		</div>
	</<?php echo $tag; // phpcs:ignore ?>>
	<?php
}

/**
 * Varian CTA penutup per halaman (qa/41 §2.3). Kunci varian dipilih otomatis dari konteks halaman.
 * Setiap varian: judul, teks, mikro (baris penenang di bawah tombol), tombol utama [label, url], tombol kedua [label, url, wa?], foto, pesan WhatsApp, terang (latar #F4F6F9),
 * bentuk: 'penuh' (navy + foto + kartu kantor), 'pita' (panel ringkas satu baris untuk halaman pendek, qa/47).
 * Copy konversi (v2.3): judul menyentuh masalah khas halaman, teks menyebut hasil yang diterima, mikro mengurangi keraguan.
 * Etika KEAI: tanpa superlatif, testimoni, janji hasil, atau kata "gratis".
 *
 * @return array<string,mixed>
 */
function autentik_cta_varian( $varian = '' ) {
	$qid  = get_queried_object_id();
	$firm = autentik_sapa();
	if ( '' === $varian ) {
		if ( is_front_page() ) {
			$varian = 'beranda';
		} elseif ( is_404() || is_search() ) {
			$varian = 'cari';
		} elseif ( is_singular( 'layanan' ) ) {
			$varian = 'layanan-' . get_post_field( 'post_name', $qid );
		} elseif ( is_singular( 'tim' ) ) {
			$varian = 'profil';
		} elseif ( is_singular( 'post' ) ) {
			$varian = 'artikel';
		} elseif ( is_home() || is_archive() ) {
			$varian = 'artikel-daftar';
		} elseif ( is_page() ) {
			$varian = get_post_field( 'post_name', $qid );
		}
	}
	$kontak = autentik_konsultasi_url();
	$wa     = array( 'Hubungi lewat WhatsApp', '', true );
	$v      = array(
		'beranda'      => array(
			'judul' => 'Persoalan hukum jangan dibiarkan berlarut-larut',
			'teks'  => 'Sampaikan saja pokok persoalannya kepada kami, walaupun dokumennya belum lengkap. Kami jelaskan secara terus terang: langkah yang perlu diambil, dokumen yang harus disiapkan, dan perkiraan biaya jasa hukumnya.',
			'foto'  => 'kontak.jpg',
		),
		'tentang-kami' => array(
			'judul' => 'Silakan datang dan bicarakan langsung di kantor kami',
			'teks'  => 'Persoalan hukum lebih jernih bila dibahas bertatap muka. Kantor kami di Medan Baru, dan sebelum masuk ke pokok persoalan, kami pastikan dulu tidak ada benturan kepentingan.',
			'mikro' => autentik_opt( 'hours' ) . '. Buat janji dulu supaya Anda tidak perlu menunggu.',
			'utama' => array( 'Jadwalkan Konsultasi', add_query_arg( 'metode', 'kantor', home_url( '/kontak/' ) ) . '#form-konsultasi' ),
			'kedua' => array( 'Lihat Tim Kami', home_url( '/tim/' ) ),
			'foto'  => 'kota.jpg',
			'wa'    => $firm . 'Saya ingin membuat janji untuk konsultasi tatap muka di kantor Anda.',
		),
		'layanan'      => array(
			'judul'  => 'Belum tahu persoalan Anda masuk bidang yang mana?',
			'teks'   => 'Tidak perlu menebak-nebak. Ceritakan duduk perkaranya kepada kami, lalu kami yang menentukan bidang yang sesuai, menunjuk penanggung jawab, dan menyampaikan dokumen yang perlu disiapkan.',
			'wa'     => $firm . 'Saya belum tahu persoalan saya masuk bidang layanan yang mana dan ingin bertanya.',
			'terang' => true,
		),
		'layanan-hukum'              => array(
			'judul' => 'Menerima somasi? Tanggapi sebelum tenggatnya lewat',
			'teks'  => 'Kirimkan salinan somasi atau perjanjiannya kepada kami. Kami telaah kedudukan hukum Anda, lalu kami sampaikan secara terus terang pilihan langkah dan risikonya, supaya Anda dapat menanggapi tepat waktu.',
			'mikro' => 'Catat tanggal surat diterima; tenggat dalam somasi menentukan waktu yang Anda miliki.',
			'foto'  => 'kontak.jpg',
			'wa'    => $firm . 'Saya menerima somasi atau menghadapi sengketa kontrak dan ingin berkonsultasi.',
		),
		'layanan-perizinan'          => array(
			'judul' => 'Izin usaha tertahan di OSS? Kami telusuri persyaratan yang belum terpenuhi',
			'teks'  => 'Sampaikan NIB, KBLI, dan status permohonan Anda. Kami periksa kekurangannya satu per satu, lalu kami dampingi penyelesaiannya dengan DPMPTSP dan instansi terkait.',
			'mikro' => 'Lampirkan tangkapan layar status permohonan di OSS agar penelaahan lebih cepat.',
			'foto'  => 'kota.jpg',
			'wa'    => $firm . 'Izin usaha saya belum terbit atau tertahan di OSS dan saya ingin berkonsultasi.',
		),
		'layanan-kenotariatan'       => array(
			'judul' => 'Mendirikan PT, CV, atau yayasan? Pastikan dasarnya kuat dari awal',
			'teks'  => 'Kami bantu memilih bentuk badan usaha yang sesuai, menyusun anggaran dasar, dan menyiapkan dokumen pendirian sampai terdaftar. Akta pendiriannya dibuat oleh notaris yang berwenang.',
			'mikro' => 'Untuk konsultasi awal, cukup siapkan KTP dan NPWP para pendiri serta rencana penyertaan modal.',
			'foto'  => 'korporasi.jpg',
			'wa'    => $firm . 'Saya hendak mendirikan badan usaha dan ingin berkonsultasi.',
		),
		'layanan-pertanahan'         => array(
			'judul' => 'Membeli tanah di Medan atau Deli Serdang? Periksa dulu sertifikatnya',
			'teks'  => 'Sengketa tanah sering berawal dari pemeriksaan yang terlewat, mulai dari alas hak grant sultan dan SK Camat hingga sertifikat ganda. Kami telusuri riwayatnya di kantor pertanahan (BPN) dan kami jelaskan risikonya sebelum Anda membayar.',
			'mikro' => 'Untuk penelaahan awal, cukup sebutkan letak tanah dan jenis sertifikatnya; salinan dokumen kami minta setelah jadwal konsultasi disepakati.',
			'foto'  => 'kota.jpg',
			'wa'    => $firm . 'Saya hendak membeli tanah atau menghadapi masalah sertifikat dan ingin berkonsultasi.',
		),
		'layanan-korporasi'          => array(
			'judul' => 'RUPS atau perubahan pengurus? Pastikan sah dan tercatat',
			'teks'  => 'Kami telaah anggaran dasar, susunan pengurus, dan kepatuhan perusahaan Anda, lalu kami siapkan dokumen keputusan yang diperlukan sebelum diajukan ke Kementerian Hukum.',
			'mikro' => 'Tersedia pendampingan hukum berkala bagi perusahaan dengan kebutuhan rutin.',
			'foto'  => 'kontak.jpg',
			'wa'    => $firm . 'Saya ingin berkonsultasi mengenai RUPS, perubahan perusahaan, atau uji tuntas.',
		),
		'layanan-investasi-properti' => array(
			'judul' => 'Berinvestasi lahan di Sumatera Utara? Periksa dulu aspek hukumnya',
			'teks'  => 'Kami periksa status hak, kesesuaian tata ruang, perizinan, dan rancangan perjanjiannya, lalu kami laporkan temuan kami apa adanya sebelum Anda mengambil keputusan.',
			'mikro' => 'Lebih baik diperiksa sebelum pembayaran daripada diselesaikan setelah timbul sengketa.',
			'foto'  => 'kota.jpg',
			'wa'    => $firm . 'Saya hendak berinvestasi lahan atau properti dan ingin berkonsultasi.',
		),
		'tim'          => array(
			'judul' => 'Satu perkara, satu penanggung jawab yang jelas',
			'teks'  => 'Sampaikan bidang persoalan Anda. Kami tunjuk anggota tim yang sesuai, dan namanya kami cantumkan dalam penawaran sebelum pekerjaan dimulai.',
			'mikro' => 'Anda dapat menghubungi penanggung jawab secara langsung selama pekerjaan berlangsung.',
			'kedua'  => array( 'Lihat Layanan', home_url( '/layanan/' ) ),
			'foto'   => 'kontak.jpg',
			'bentuk' => 'pita',
		),
		'klien'        => array(
			'judul' => 'Perusahaan Anda membutuhkan pendampingan hukum rutin?',
			'teks'  => 'Kami menyediakan pendampingan hukum berkala (retainer) untuk kontrak proyek, perizinan, dan urusan korporasi, dengan lingkup dan biaya yang disepakati di awal.',
			'mikro' => 'Cocok bagi perusahaan konstruksi, energi, transportasi, dan industri yang rutin menyusun kontrak atau mengurus perizinan.',
			'utama' => array( 'Jadwalkan Konsultasi', autentik_konsultasi_url( 'korporasi' ) ),
			'kedua' => array( 'Lihat Layanan', home_url( '/layanan/' ) ),
			'foto'   => 'korporasi.jpg',
			'wa'     => $firm . 'Perusahaan kami membutuhkan pendampingan hukum berkala.',
			'bentuk' => 'pita',
		),
		'artikel-daftar' => array(
			'judul' => 'Persoalan Anda tidak persis sama dengan contoh di artikel?',
			'teks'  => 'Setiap perkara punya fakta sendiri. Artikel menjelaskan ketentuan umumnya; untuk persoalan Anda, fakta dan dokumennya perlu kami telaah lebih dulu.',
			'mikro'  => 'Uraikan dahulu pokok persoalannya; dokumen dapat Anda kirimkan kemudian.',
			'foto'   => 'kontak.jpg',
			'wa'     => $firm . 'Saya sudah membaca artikel di situs Anda dan ingin bertanya.',
			'terang' => true,
		),
		'cari'         => array(
			'judul' => 'Informasi yang Anda cari belum ada?',
			'teks'  => 'Tanyakan langsung kepada tim kami, termasuk persoalan yang belum dibahas di situs ini.',
			'foto'   => 'kota.jpg',
			'wa'     => $firm . 'Saya tidak menemukan informasi yang saya cari di situs Anda dan ingin bertanya.',
			'bentuk' => 'pita',
		),
		'kebijakan-privasi' => array(
			'judul'  => 'Ingin mengajukan permintaan terkait data pribadi Anda?',
			'teks'   => 'Permintaan akses, perbaikan, atau penghapusan data pribadi dapat Anda sampaikan melalui email kantor kami.',
			'mikro'  => 'Permintaan Anda kami tanggapi dalam tenggat yang ditetapkan UU Pelindungan Data Pribadi.',
			'utama'  => array( 'Kirim Email', 'mailto:' . autentik_opt( 'email' ) ),
			'wa'     => $firm . 'Saya ingin mengajukan permintaan mengenai data pribadi saya.',
			'terang' => true,
		),
		'umum'         => array(
			'judul' => 'Konsultasikan persoalan hukum Anda',
			'teks'  => 'Sampaikan pokok persoalannya secara singkat. Kami jelaskan langkah awal dan dokumen yang perlu disiapkan.',
			'foto'  => 'kontak.jpg',
		),
	);

	if ( 'profil' === $varian && $qid ) {
		$nama  = autentik_plain_title( $qid );
		$first = 0 === strpos( $nama, 'Dr.' ) ? $nama : strtok( $nama, ' ' );
		$v['profil'] = autentik_is_advokat( $qid ) ? array(
			'judul' => 'Bicarakan persoalan Anda langsung dengan ' . $first,
			'teks'  => 'Permintaan Anda kami teruskan kepada ' . $nama . ' setelah pemeriksaan benturan kepentingan, lalu kami hubungi Anda untuk menentukan jadwal konsultasi.',
			'utama' => array( 'Jadwalkan Konsultasi dengan ' . $first, add_query_arg( 'advokat', rawurlencode( $nama ), home_url( '/kontak/' ) ) . '#form-konsultasi' ),
			'foto'  => 'kontak.jpg',
			'wa'    => $firm . 'Saya ingin berkonsultasi dengan ' . $nama . '.',
		) : array(
			'judul' => 'Bicarakan persoalan Anda dengan tim hukum kami',
			'teks'  => 'Sampaikan pokok persoalan Anda. Kami tunjuk anggota tim yang sesuai dengan bidangnya, lalu kami hubungi Anda untuk menentukan jadwal.',
			'kedua' => array( 'Lihat Tim Kami', home_url( '/tim/' ) ),
			'foto'  => 'kontak.jpg',
		);
	}
	if ( 'artikel' === $varian && $qid ) {
		$lay   = autentik_post_layanan( $qid );
		$frasa = array(
			'hukum'              => 'kontrak atau sengketa bisnis',
			'perizinan'          => 'perizinan berusaha',
			'kenotariatan'       => 'pendirian badan usaha',
			'pertanahan'         => 'pertanahan',
			'korporasi'          => 'korporasi dan kepatuhan',
			'investasi-properti' => 'investasi dan properti',
		);
		$v['artikel'] = array(
			'judul' => $lay && isset( $frasa[ $lay->post_name ] ) ? 'Sedang menghadapi urusan ' . $frasa[ $lay->post_name ] . '?' : 'Sedang menghadapi persoalan serupa?',
			'teks'  => 'Artikel ini menjelaskan ketentuan umumnya. Untuk keadaan Anda, dokumennya perlu kami periksa lebih dulu sebelum kami berpendapat.',
			'mikro' => 'Uraikan dahulu pokok persoalannya; dokumen dapat Anda kirimkan kemudian.',
			'kedua' => $lay ? array( 'Lihat Layanan', get_permalink( $lay ) ) : $wa,
			'foto'  => 'kontak.jpg',
		);
	}

	$c = isset( $v[ $varian ] ) ? $v[ $varian ] : $v['umum'];
	$c = wp_parse_args( $c, array( 'utama' => array( 'Jadwalkan Konsultasi', $kontak ), 'kedua' => $wa, 'foto' => 'kontak.jpg', 'wa' => autentik_wa_pesan(), 'terang' => false, 'bentuk' => 'penuh', 'mikro' => 'Kami tanggapi paling lambat satu hari kerja. Menghubungi kami tidak mewajibkan Anda memakai jasa kami.' ) );
	$c['varian'] = isset( $v[ $varian ] ) ? $varian : 'umum';
	if ( autentik_opt( 'cta_bg' ) ) {
		$c['foto_url'] = autentik_opt( 'cta_bg' ); // Customizer › Foto Latar menimpa foto bawaan per halaman (46g T3)
	}

	// Kolom CMS "Judul/Teks/Baris penenang CTA penutup" (halaman & layanan) menimpa isi bawaan.
	if ( $qid && is_singular( array( 'page', 'layanan' ) ) ) {
		foreach ( array( 'judul' => 'cta_judul', 'teks' => 'cta_teks', 'mikro' => 'cta_mikro' ) as $k => $f ) {
			$isi = trim( (string) autentik_field( $f, $qid ) );
			if ( '' !== $isi ) {
				$c[ $k ] = $isi;
			}
		}
	}
	return apply_filters( 'autentik_cta_varian', $c, $varian );
}

/**
 * Seksi CTA penutup (dipakai di semua halaman): isi berbeda per halaman (autentik_cta_varian), foto, kartu kantor dengan status buka.
 * $varian kosong = dipilih otomatis dari konteks halaman.
 */
function autentik_cta( $varian = '' ) {
	$tel = preg_replace( '/\D+/', '', autentik_opt( 'phone' ) );
	$c   = autentik_cta_varian( $varian );
	$wa  = autentik_wa( $c['wa'] );
	$u2  = empty( $c['kedua'][2] ) ? $c['kedua'][1] : $wa;
	if ( 'pita' === $c['bentuk'] ) :
		// Pita ringkas (qa/47, 45 A2): halaman pendek tidak dihabiskan oleh penutup; tanpa kartu kantor, alamat tetap di footer.
		?>
		<section class="bh-pita" data-cta="<?php echo esc_attr( $c['varian'] ); ?>">
			<div class="wrap">
				<div class="pita-in rv">
					<div class="pita-ph" aria-hidden="true"><img src="<?php echo esc_url( ( empty( $c['foto_url'] ) ? autentik_img( $c['foto'] ) : $c['foto_url'] ) ); ?>"<?php echo autentik_srcset( ( empty( $c['foto_url'] ) ? autentik_img( $c['foto'] ) : $c['foto_url'] ), '(max-width:760px) 1px, 320px' ); // phpcs:ignore ?> alt="" loading="lazy" width="2000" height="1333"></div>
					<div class="pita-t">
						<h2><?php echo esc_html( $c['judul'] ); ?></h2>
						<p><?php echo esc_html( $c['teks'] ); ?></p>
					</div>
					<div class="acts">
						<a class="btn b-gold" href="<?php echo esc_url( $c['utama'][1] ); ?>"><?php echo esc_html( $c['utama'][0] ); ?> <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
						<a class="btn b-line" href="<?php echo esc_url( $u2 ); ?>"<?php echo empty( $c['kedua'][2] ) ? '' : ' target="_blank" rel="noopener"'; ?>><?php echo empty( $c['kedua'][2] ) ? '' : autentik_icon( 'wa' ); // phpcs:ignore ?><?php echo esc_html( $c['kedua'][0] ); ?></a>
					</div>
				</div>
			</div>
		</section>
		<?php
		return;
	endif;
	?>
	<section class="bh-cta<?php echo $c['terang'] ? ' terang' : ''; ?>" data-cta="<?php echo esc_attr( $c['varian'] ); ?>">
		<?php if ( ! $c['terang'] ) : ?>
		<div class="bh-cta-bg" aria-hidden="true"><img src="<?php echo esc_url( ( empty( $c['foto_url'] ) ? autentik_img( $c['foto'] ) : $c['foto_url'] ) ); ?>"<?php echo autentik_srcset( ( empty( $c['foto_url'] ) ? autentik_img( $c['foto'] ) : $c['foto_url'] ), '(max-width:760px) 256px, 100vw' ); // phpcs:ignore ?> alt="" loading="lazy" width="2000" height="1333"></div>
		<?php endif; ?>
		<div class="wrap bh-cta-in">
			<div class="rv">
				<h2><?php echo esc_html( $c['judul'] ); ?></h2>
				<p><?php echo esc_html( $c['teks'] ); ?></p>
				<div class="acts">
					<a class="btn b-gold" href="<?php echo esc_url( $c['utama'][1] ); ?>"><?php echo esc_html( $c['utama'][0] ); ?> <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
					<a class="btn b-line" href="<?php echo esc_url( $u2 ); ?>"<?php echo empty( $c['kedua'][2] ) ? '' : ' target="_blank" rel="noopener"'; ?>><?php echo empty( $c['kedua'][2] ) ? '' : autentik_icon( 'wa' ); // phpcs:ignore ?><?php echo esc_html( $c['kedua'][0] ); ?></a>
				</div>
				<?php if ( $c['mikro'] ) : ?><p class="cta-mikro"><?php echo autentik_icon( 'shield' ); // phpcs:ignore ?><span><?php echo esc_html( $c['mikro'] ); ?></span></p><?php endif; ?>
			</div>
			<address class="bh-office rv">
				<b>Kantor Medan Baru</b>
				<span class="ln"><?php echo autentik_icon( 'pin' ); // phpcs:ignore ?><span><?php echo esc_html( autentik_address() ); ?></span></span>
				<span class="ln"><?php echo autentik_icon( 'phone' ); // phpcs:ignore ?><span><a href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo esc_html( autentik_opt( 'phone' ) ); ?></a></span></span>
				<span class="ln"><?php echo autentik_icon( 'clock' ); // phpcs:ignore ?><span><?php echo esc_html( autentik_opt( 'hours' ) ); ?> <span class="open-now" data-open-now hidden><i></i><em></em></span></span></span>
				<a class="bh-map" href="<?php echo esc_url( autentik_opt( 'maps' ) ); ?>" target="_blank" rel="noopener">Petunjuk Arah <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
			</address>
		</div>
	</section>
	<?php
}

/**
 * Tautan formulir konsultasi yang membawa konteks halaman (bidang layanan) ke formulir.
 */
function autentik_konsultasi_url( $bidang = '' ) {
	if ( '' === $bidang ) {
		if ( is_singular( 'layanan' ) ) {
			$bidang = get_post_field( 'post_name', get_queried_object_id() );
		} elseif ( is_singular( 'post' ) ) {
			$lay    = autentik_post_layanan( get_queried_object_id() );
			$bidang = $lay ? $lay->post_name : '';
		}
	}
	$url = home_url( '/kontak/' );
	return ( $bidang ? add_query_arg( 'bidang', rawurlencode( $bidang ), $url ) : $url ) . '#form-konsultasi';
}

/**
 * Layanan terkait sebuah artikel: kolom term `layanan_terkait` (CMS) atau pemetaan slug kategori.
 */
function autentik_post_layanan( $post_id ) {
	foreach ( get_the_category( $post_id ) as $c ) {
		$id = (int) get_term_meta( $c->term_id, 'layanan_terkait', true );
		if ( $id && 'layanan' === get_post_type( $id ) ) {
			return get_post( $id );
		}
		$map = autentik_cat_to_layanan();
		if ( isset( $map[ $c->slug ] ) ) {
			$p = get_page_by_path( $map[ $c->slug ], OBJECT, 'layanan' );
			if ( $p ) {
				return $p;
			}
		}
	}
	return null;
}

/**
 * Pesan WhatsApp pra-isi sesuai halaman yang sedang dibaca.
 */
function autentik_wa_pesan() {
	if ( is_singular( array( 'layanan', 'post' ) ) ) {
		return autentik_sapa() . 'Saya telah membaca "' . autentik_plain_title( get_queried_object_id() ) . '" di situs Anda dan ingin mengajukan pertanyaan.';
	}
	return '';
}

/**
 * Anggota tim yang ditampilkan sebagai bagian firma (notaris mitra tidak ditampilkan sebagai anggota).
 *
 * @return WP_Post[]
 */
function autentik_tim_publik() {
	return array_values( array_filter( autentik_tim_all(), function ( $t ) { return 'notaris_mitra' !== (string) autentik_field( 'status_profesi', $t->ID ); } ) );
}

/**
 * Apakah anggota tim berstatus advokat (sudah disumpah) menurut data CMS.
 */
function autentik_is_advokat( $id ) {
	return 'advokat' === (string) autentik_field( 'status_profesi', $id );
}

/**
 * Penanda "Foto contoh" untuk gambar demo (judul lampiran diawali "DEMO"): hilang sendiri saat foto asli diunggah.
 */
function autentik_demo_tag( $post_or_attachment ) {
	$att = is_numeric( $post_or_attachment ) ? (int) $post_or_attachment : 0;
	if ( ! $att && $post_or_attachment instanceof WP_Post ) {
		$att = 'attachment' === $post_or_attachment->post_type ? $post_or_attachment->ID : (int) get_post_thumbnail_id( $post_or_attachment );
	}
	return ( $att && 0 === stripos( (string) get_the_title( $att ), 'DEMO' ) ) ? '<span class="demo-tag">Foto contoh</span>' : '';
}

/**
 * Klien yang boleh tampil. $semua = true untuk menghitung seluruh klien.
 */
function autentik_klien( $semua = false ) {
	$all = get_posts( array( 'post_type' => 'klien', 'numberposts' => 50, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $semua || autentik_opt( 'preview_klien' ) ) {
		return $all;
	}
	return array_values(
		array_filter(
			$all,
			function ( $k ) {
				return (bool) autentik_field( 'izin_tayang', $k->ID );
			}
		)
	);
}

/**
 * Satu petak logo klien: logo asli bila ada, bila belum ada tampil sebagai logotype nama perusahaan.
 */
function autentik_klien_tile( $k, $tag = 'li' ) {
	$name = get_the_title( $k );
	$bare = preg_replace( '/^PT\.?\s+/i', '', $name );
	$site = (string) autentik_field( 'situs', $k->ID );
	echo '<' . $tag . ' class="lg-tile' . ( has_post_thumbnail( $k ) ? '' : ' wm' ) . '">';
	echo $site ? '<a href="' . esc_url( $site ) . '" target="_blank" rel="noopener nofollow">' : '<span class="in">';
	if ( has_post_thumbnail( $k ) ) {
		echo get_the_post_thumbnail( $k, 'medium', array( 'alt' => $name, 'loading' => 'lazy' ) );
	} else {
		echo '<span class="wmk" role="img" aria-label="' . esc_attr( $name ) . '"><small aria-hidden="true">PT</small><b aria-hidden="true">' . esc_html( $bare ) . '</b></span>';
	}
	echo $site ? '</a>' : '</span>';
	if ( has_post_thumbnail( $k ) ) {
		echo '<span class="lg-name">' . esc_html( $bare ) . '</span>';
	}
	echo '</' . $tag . '>';
}

/**
 * Ambil judul (Heading 1 pertama) + paragraf pembuka dari isi halaman, sisanya dikembalikan sebagai blok.
 * Dengan ini teks banner tiap halaman bisa diedit klien lewat editor.
 *
 * @return array{0:string,1:string,2:array}
 */
function autentik_page_head( $post_id, $title_default = '', $dek_default = '' ) {
	$blocks = parse_blocks( get_post_field( 'post_content', $post_id ) );
	$blocks = array_values( array_filter( $blocks, function ( $b ) { return $b['blockName'] || trim( $b['innerHTML'] ) !== ''; } ) );
	$title  = $title_default ? $title_default : get_the_title( $post_id );
	$dek    = has_excerpt( $post_id ) ? get_the_excerpt( $post_id ) : $dek_default;
	if ( $blocks && 'core/heading' === $blocks[0]['blockName'] && 1 === (int) ( $blocks[0]['attrs']['level'] ?? 2 ) ) {
		$title = trim( wp_strip_all_tags( $blocks[0]['innerHTML'] ) );
		array_shift( $blocks );
		if ( $blocks && 'core/paragraph' === $blocks[0]['blockName'] ) {
			$dek = trim( wp_strip_all_tags( $blocks[0]['innerHTML'] ) );
			array_shift( $blocks );
		}
	}
	return array( $title, $dek, $blocks );
}

/**
 * Versi kecil gambar tema untuk thumbnail: assets/img/{nama}.jpg → {nama}-480.webp bila ada (qa/46c T2).
 */
function autentik_img_kecil( $url ) {
	$base = trailingslashit( AUTENTIK_URI ) . 'assets/img/';
	if ( 0 !== strpos( (string) $url, $base ) ) {
		return $url;
	}
	$stem = preg_replace( '/(-\d+)?\.(jpe?g|png|webp)$/', '', substr( $url, strlen( $base ) ) );
	return file_exists( AUTENTIK_DIR . "/assets/img/{$stem}-480.webp" ) ? $base . "{$stem}-480.webp" : $url;
}

/**
 * Teks ber-escape dengan kata kunci pencarian disorot <mark> (hasil cari, 45 B3).
 */
function autentik_sorot( $text, $q ) {
	$text = esc_html( (string) $text );
	$kata = array_filter( preg_split( '/\s+/', trim( (string) $q ) ), function ( $k ) { return mb_strlen( $k ) >= 2; } );
	if ( ! $kata ) {
		return $text;
	}
	$pola = implode( '|', array_map( function ( $k ) { return preg_quote( esc_html( $k ), '/' ); }, $kata ) );
	return preg_replace( '/(' . $pola . ')/iu', '<mark>$1</mark>', $text );
}

/**
 * Nama firma tanpa awalan "Law Firm" (logo teks, akhiran judul, schema). Sumber: Customizer › Nama firma (46g T2).
 */
function autentik_firm_singkat() {
	$f = trim( preg_replace( '/^\s*(Law\s+Firm|Kantor\s+Hukum)\s+/i', '', (string) autentik_opt( 'firm' ) ) );
	return '' !== $f ? $f : (string) autentik_opt( 'firm' );
}

/**
 * Sapaan pembuka pesan WhatsApp bawaan: "Halo, {Nama firma}. " (46g T2).
 */
function autentik_sapa() {
	return 'Halo, ' . autentik_opt( 'firm' ) . '. ';
}

