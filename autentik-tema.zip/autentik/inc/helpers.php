<?php
/**
 * Fungsi bantu.
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ambil field SCF/ACF — tetap berfungsi walau plugin SCF nonaktif (baca post meta langsung).
 */
function autentik_field( $name, $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( function_exists( 'get_field' ) ) {
		return get_field( $name, $post_id );
	}
	return get_post_meta( $post_id, $name, true );
}

/**
 * Ambil baris repeater tanpa bergantung pada SCF.
 *
 * @return array<int, array<string,string>>
 */
function autentik_rows( $name, array $subs, $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( function_exists( 'get_field' ) ) {
		$v = get_field( $name, $post_id );
		if ( is_array( $v ) ) {
			return $v;
		}
	}
	$n    = (int) get_post_meta( $post_id, $name, true );
	$rows = array();
	for ( $i = 0; $i < $n; $i++ ) {
		$row = array();
		foreach ( $subs as $s ) {
			$row[ $s ] = (string) get_post_meta( $post_id, "{$name}_{$i}_{$s}", true );
		}
		$rows[] = $row;
	}
	return $rows;
}

/**
 * Ikon dari sprite SVG di footer.
 */
function autentik_icon( $name, $class = '' ) {
	return '<svg class="ico ' . esc_attr( $class ) . '" aria-hidden="true"><use href="#i-' . esc_attr( $name ) . '"/></svg>';
}

/**
 * Gambar bawaan tema (dipakai bila belum ada gambar unggulan).
 */
function autentik_img( $file ) {
	return AUTENTIK_URI . '/assets/img/' . $file;
}

/**
 * Gambar bawaan untuk tiap layanan.
 */
function autentik_layanan_img( $post_id, $size = 'autentik-card' ) {
	if ( has_post_thumbnail( $post_id ) ) {
		return get_the_post_thumbnail_url( $post_id, $size );
	}
	$map = array(
		'hukum'              => 'hukum.jpg',
		'perizinan'          => 'perizinan.jpg',
		'kenotariatan'       => 'kenotariatan.jpg',
		'pertanahan'         => 'pertanahan.jpg',
		'korporasi'          => 'korporasi.jpg',
		'investasi-properti' => 'investasi.jpg',
	);
	$slug = get_post_field( 'post_name', $post_id );
	return autentik_img( isset( $map[ $slug ] ) ? $map[ $slug ] : 'hukum.jpg' );
}

/**
 * Keterangan berbasis tugas per layanan (menu, pencarian): kata yang dipakai orang saat mencari.
 */
function autentik_layanan_tugas() {
	return apply_filters(
		'autentik_layanan_tugas',
		array(
			'hukum'              => 'Kontrak, somasi, dan gugatan',
			'perizinan'          => 'NIB, OSS, dan izin usaha',
			'kenotariatan'       => 'Pendirian PT, CV, dan yayasan',
			'pertanahan'         => 'Pemeriksaan sertifikat, balik nama, dan waris',
			'korporasi'          => 'RUPS, kepatuhan, dan uji tuntas',
			'investasi-properti' => 'Pembelian lahan dan properti',
		)
	);
}

/**
 * Ikon per layanan (nama simbol di sprite).
 */
function autentik_layanan_icon( $post_id ) {
	$map  = array(
		'hukum'              => 'scale',
		'perizinan'          => 'badge',
		'kenotariatan'       => 'pen',
		'pertanahan'         => 'map',
		'korporasi'          => 'building',
		'investasi-properti' => 'chart',
	);
	$slug = get_post_field( 'post_name', $post_id );
	return isset( $map[ $slug ] ) ? $map[ $slug ] : 'scale';
}

/**
 * Kategori artikel ↔ layanan (untuk artikel terkait dan layanan terkait).
 */
function autentik_cat_to_layanan() {
	return apply_filters(
		'autentik_cat_to_layanan',
		array(
			'hukum'        => 'hukum',
			'perizinan'    => 'perizinan',
			'kenotariatan' => 'kenotariatan',
			'pertanahan'   => 'pertanahan',
			'korporasi'    => 'korporasi',
			'investasi'    => 'investasi-properti',
		)
	);
}

/**
 * Inisial nama untuk avatar cadangan.
 */
function autentik_initials( $name ) {
	$name  = preg_replace( '/^Dr\.?\s*/i', '', $name );
	$parts = preg_split( '/\s+/', trim( $name ) );
	$a     = isset( $parts[0] ) ? mb_substr( $parts[0], 0, 1 ) : '';
	$b     = isset( $parts[1] ) ? mb_substr( $parts[1], 0, 1 ) : '';
	return mb_strtoupper( $a . $b );
}

/**
 * srcset WebP untuk gambar tema (assets/img/{nama}-{480|768|1024|1600}.webp).
 * Menerima URL apa pun; bila bukan gambar tema atau varian tidak ada, mengembalikan string kosong.
 */
function autentik_srcset( $url, $sizes = '(max-width:760px) 100vw, 50vw' ) {
	$base = trailingslashit( AUTENTIK_URI ) . 'assets/img/';
	if ( 0 !== strpos( (string) $url, $base ) ) {
		return '';
	}
	$stem = preg_replace( '/(-\d+)?\.(jpe?g|png|webp)$/', '', substr( $url, strlen( $base ) ) );
	$out  = array();
	foreach ( array( 480, 768, 1024, 1600 ) as $w ) {
		if ( file_exists( AUTENTIK_DIR . "/assets/img/{$stem}-{$w}.webp" ) ) {
			$out[] = esc_url( $base . "{$stem}-{$w}.webp" ) . " {$w}w";
		}
	}
	return $out ? ' srcset="' . esc_attr( implode( ', ', $out ) ) . '" sizes="' . esc_attr( $sizes ) . '"' : '';
}

/**
 * Judul polos (tanpa entitas HTML) untuk WhatsApp, JSON-LD, dan llms.txt.
 */
function autentik_plain_title( $p = null ) {
	return html_entity_decode( wp_strip_all_tags( get_the_title( $p ) ), ENT_QUOTES, 'UTF-8' );
}

/**
 * Perkiraan waktu baca.
 */
function autentik_read_minutes( $post_id = null ) {
	$words = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ? $post_id : get_the_ID() ) ) );
	return max( 1, (int) ceil( $words / 200 ) );
}

/**
 * Link WhatsApp dengan pesan pra-isi.
 */
function autentik_wa( $pesan = '' ) {
	$no = preg_replace( '/\D+/', '', (string) autentik_opt( 'wa' ) );
	if ( 0 === strpos( $no, '0' ) ) {
		$no = '62' . substr( $no, 1 );
	}
	if ( '' === $no ) {
		return home_url( '/kontak/' );
	}
	if ( '' === $pesan ) {
		$pesan = 'Halo, Law Firm Autentik Analitika. Saya ingin berkonsultasi mengenai persoalan hukum.';
	}
	return 'https://wa.me/' . $no . '?text=' . rawurlencode( $pesan );
}

/**
 * Daftar layanan (CPT), terurut.
 */
function autentik_layanan( $exclude = 0 ) {
	return get_posts(
		array(
			'post_type'   => 'layanan',
			'numberposts' => 12,
			'orderby'     => 'menu_order',
			'order'       => 'ASC',
			'exclude'     => $exclude ? array( $exclude ) : array(),
		)
	);
}

/**
 * Breadcrumb HTML (skemanya dibuat di seo-geo.php).
 */
function autentik_breadcrumb( array $items ) {
	echo '<nav aria-label="Remah roti"><ol class="crumb">';
	echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Beranda</a></li>';
	foreach ( $items as $it ) {
		if ( ! empty( $it[1] ) ) {
			echo '<li><a href="' . esc_url( $it[1] ) . '">' . esc_html( $it[0] ) . '</a></li>';
		} else {
			echo '<li aria-current="page">' . esc_html( $it[0] ) . '</li>';
		}
	}
	echo '</ol></nav>';
	$GLOBALS['autentik_crumbs'] = $items;
}

/**
 * Banner halaman dalam: judul rata kiri bergaris emas, foto kontekstual di kanan (HP: foto tipis di atas).
 */
function autentik_banner( $title, $dek = '', array $crumbs = array(), $bg = '' ) {
	$bg = $bg ? $bg : autentik_img( 'kota.jpg' );
	?>
	<section class="ban ban2">
		<div class="wrap ban-in">
			<div class="ban-t">
				<?php autentik_breadcrumb( $crumbs ); ?>
				<h1><?php echo esc_html( $title ); ?></h1>
				<?php if ( $dek ) : ?>
					<p class="dek"><?php echo esc_html( $dek ); ?></p>
				<?php endif; ?>
			</div>
			<figure class="ban-ph" aria-hidden="true"><img class="bg" src="<?php echo esc_url( $bg ); ?>"<?php echo autentik_srcset( $bg, '(max-width:760px) 100vw, 42vw' ); // phpcs:ignore ?> alt="" width="1000" height="667" fetchpriority="high"></figure>
		</div>
	</section>
	<?php
}

/**
 * Judul seksi.
 */
function autentik_sh( $eyebrow, $title, $text = '', $left = false ) {
	echo '<div class="sh' . ( $left ? ' left' : '' ) . ' rv"><h2>' . esc_html( $title ) . '</h2>'; // $eyebrow tidak dicetak lagi (judul cukup berdiri sendiri)
	if ( $text ) {
		echo '<p>' . esc_html( $text ) . '</p>';
	}
	echo '</div>';
}

/**
 * Nilai unggulan & langkah kerja (dapat diubah lewat filter).
 */
function autentik_why() {
	return apply_filters(
		'autentik_why',
		array(
			array( 'receipt', 'Biaya disepakati di awal', 'Kami menyampaikan lingkup pekerjaan, perkiraan waktu, dan biaya jasa hukum dalam penawaran tertulis. Pekerjaan baru dimulai setelah Anda menyetujuinya.' ),
			array( 'user', 'Satu penanggung jawab', 'Setiap perkara atau urusan ditangani oleh satu penanggung jawab yang namanya tercantum dalam penawaran tertulis. Anda dapat menghubunginya selama pekerjaan berlangsung.' ),
			array( 'layers', 'Urusan yang berkaitan ditangani satu tim', 'Kontrak, perizinan, dan pertanahan sering berkaitan dalam satu persoalan. Karena ditangani oleh satu tim, Anda tidak perlu menjelaskan persoalan yang sama kepada beberapa kantor hukum.' ),
			array( 'shield', 'Kerahasiaan dan benturan kepentingan', 'Sebelum menerima perkara, kami memeriksa kemungkinan benturan kepentingan. Keterangan dan dokumen Anda hanya dibahas oleh tim yang menangani perkara tersebut.' ),
		)
	);
}

/**
 * Alur penanganan. Kolom ke-3: yang dipegang klien di tahap itu (tampil di beranda).
 */
function autentik_steps() {
	return apply_filters(
		'autentik_steps',
		array(
			array( 'Konsultasi', 'Anda menyampaikan persoalan yang dihadapi, lalu kami mengajukan pertanyaan untuk memahami duduk perkaranya. Pada tahap ini kami juga memastikan bahwa persoalan tersebut termasuk dalam bidang yang kami tangani.', 'Pemeriksaan benturan kepentingan sebelum kami menanggapi pokok persoalan. Keterangan Anda hanya diketahui oleh tim yang menangani.' ),
			array( 'Telaah', 'Kami menelaah dokumen, memeriksa dasar hukum dan kedudukan hukum para pihak, lalu menjelaskan pilihan langkah hukum beserta risikonya.', 'Penjelasan pilihan langkah hukum beserta risikonya, serta daftar dokumen yang masih diperlukan.' ),
			array( 'Penawaran', 'Kami menyampaikan penawaran tertulis yang memuat lingkup pekerjaan, dokumen yang perlu disiapkan, perkiraan waktu, dan biaya jasa hukum. Pekerjaan dimulai setelah Anda menyetujuinya.', 'Penawaran tertulis yang memuat lingkup pekerjaan, perkiraan waktu, biaya, dan nama penanggung jawab.' ),
			array( 'Pelaksanaan', 'Setelah perjanjian jasa hukum ditandatangani, kami menangani perkara atau urusan Anda hingga selesai dan melaporkan perkembangannya pada setiap tahap penting.', 'Satu penanggung jawab yang dapat Anda hubungi, serta laporan perkembangan pada setiap tahap penting.' ),
		)
	);
}

/**
 * FAQ dari blok "Details" di sebuah halaman (agar bisa diedit lewat editor).
 *
 * @return array<int, array{0:string,1:string}>
 */
function autentik_faq_from_page( $page_id ) {
	$out = array();
	if ( ! $page_id ) {
		return $out;
	}
	foreach ( parse_blocks( get_post_field( 'post_content', $page_id ) ) as $b ) {
		if ( 'core/details' !== $b['blockName'] ) {
			continue;
		}
		if ( preg_match( '#<summary>(.*?)</summary>#s', $b['innerHTML'], $m ) ) {
			$a = '';
			foreach ( $b['innerBlocks'] as $ib ) {
				$a .= ' ' . wp_strip_all_tags( render_block( $ib ) );
			}
			$out[] = array( wp_strip_all_tags( $m[1] ), trim( $a ) );
		}
	}
	return $out;
}

/**
 * Cetak akordeon FAQ.
 */
function autentik_faq_html( array $faq ) {
	if ( ! $faq ) {
		return;
	}
	echo '<div class="faq">';
	foreach ( $faq as $i => $q ) {
		$tanya = isset( $q['tanya'] ) ? $q['tanya'] : $q[0];
		$jawab = isset( $q['jawab'] ) ? $q['jawab'] : $q[1];
		echo '<details' . ( 0 === $i ? ' open' : '' ) . '><summary>' . esc_html( $tanya ) . '<span class="pm">' . autentik_icon( 'plus' ) . '</span></summary><div class="a">' . esc_html( $jawab ) . '</div></details>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</div>';
	$GLOBALS['autentik_faq'] = array_merge( isset( $GLOBALS['autentik_faq'] ) ? $GLOBALS['autentik_faq'] : array(), $faq );
}

/**
 * Kartu artikel.
 */
function autentik_post_img( $post, $size = 'autentik-card' ) {
	if ( has_post_thumbnail( $post ) ) {
		return get_the_post_thumbnail_url( $post, $size );
	}
	$cat  = get_the_category( $post->ID );
	$map  = autentik_cat_to_layanan();
	$slug = ( $cat && isset( $map[ $cat[0]->slug ] ) ) ? $map[ $cat[0]->slug ] : '';
	$lay  = $slug ? get_page_by_path( $slug, OBJECT, 'layanan' ) : null;
	return $lay ? autentik_layanan_img( $lay->ID, $size ) : autentik_img( 'hukum.jpg' );
}

/**
 * Tag <img> gambar artikel dengan srcset (gambar unggulan WordPress atau gambar tema WebP).
 */
function autentik_post_img_tag( $post, $size = 'autentik-card', $sizes = '(max-width:760px) 92vw, 33vw', $lazy = true ) {
	if ( has_post_thumbnail( $post ) ) {
		return get_the_post_thumbnail( $post, $size, array( 'alt' => '', 'sizes' => $sizes, 'loading' => $lazy ? 'lazy' : false, 'fetchpriority' => $lazy ? false : 'high' ) );
	}
	$url = autentik_post_img( $post, $size );
	return '<img src="' . esc_url( $url ) . '"' . autentik_srcset( $url, $sizes ) . ' alt="" ' . ( $lazy ? 'loading="lazy"' : 'fetchpriority="high"' ) . ' width="1000" height="667">';
}

function autentik_post_card( $post ) {
	$cat = get_the_category( $post->ID );
	?>
	<a class="pc rv" href="<?php echo esc_url( get_permalink( $post ) ); ?>">
		<div class="img"><?php echo autentik_post_img_tag( $post ); // phpcs:ignore ?>
			<?php if ( $cat ) : ?><span class="cat"><?php echo esc_html( $cat[0]->name ); ?></span><?php endif; ?>
		</div>
		<div class="body">
			<div class="meta"><span><?php echo esc_html( get_the_date( 'j M Y', $post ) ); ?></span><span><?php echo (int) autentik_read_minutes( $post->ID ); ?> menit baca</span></div>
			<h3><?php echo esc_html( get_the_title( $post ) ); ?></h3>
			<p><?php echo esc_html( get_the_excerpt( $post ) ); ?></p>
			<?php list( $by ) = autentik_post_people( $post->ID ); ?>
			<?php if ( $by ) : ?><span class="by"><?php echo autentik_avatar( $by, 'thumbnail', 'f' ); // phpcs:ignore ?><?php echo esc_html( get_the_title( $by ) ); ?></span><?php endif; ?>
			<span class="more">Baca Artikel <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span>
		</div>
	</a>
	<?php
}

/**
 * Publikasi utama (paling baru) di halaman daftar publikasi.
 */
function autentik_post_lead( $post ) {
	$cat = get_the_category( $post->ID );
	list( $by, $rev ) = autentik_post_people( $post->ID );
	?>
	<a class="plead rv" href="<?php echo esc_url( get_permalink( $post ) ); ?>">
		<span class="img"><?php echo autentik_post_img_tag( $post, 'autentik-wide', '(max-width:760px) 92vw, 50vw', false ); // phpcs:ignore ?></span>
		<span class="body">
			<?php if ( $cat ) : ?><span class="eyebrow"><?php echo esc_html( $cat[0]->name ); ?></span><?php endif; ?>
			<h3><?php echo esc_html( get_the_title( $post ) ); ?></h3>
			<span class="ex"><?php echo esc_html( get_the_excerpt( $post ) ); ?></span>
			<span class="meta"><?php echo esc_html( get_the_date( 'j F Y', $post ) ); ?> · <?php echo (int) autentik_read_minutes( $post->ID ); ?> menit baca<?php echo $by ? ' · Ditulis oleh ' . esc_html( get_the_title( $by ) ) : ''; ?><?php echo $rev ? ' · Ditinjau oleh ' . esc_html( get_the_title( $rev ) ) : ''; ?></span>
			<span class="more">Baca Artikel <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span>
		</span>
	</a>
	<?php
}

/**
 * Kartu layanan.
 */
function autentik_layanan_card( $p, $n, $link = true ) {
	$lingkup = autentik_rows( 'lingkup', array( 'teks', 'teks_en' ), $p->ID );
	$tag     = $link ? 'a' : 'div';
	?>
	<<?php echo $tag; // phpcs:ignore ?> class="svc rv<?php echo $link ? '' : ' static'; ?>"<?php echo $link ? ' href="' . esc_url( get_permalink( $p ) ) . '"' : ''; // phpcs:ignore ?>>
		<div class="img"><img src="<?php echo esc_url( autentik_layanan_img( $p->ID ) ); ?>"<?php echo autentik_srcset( autentik_layanan_img( $p->ID ), '(max-width:760px) 92vw, 50vw' ); // phpcs:ignore ?> alt="" loading="lazy" width="720" height="405"></div>
		<div class="body">
			<h3><?php echo esc_html( get_the_title( $p ) ); ?></h3>
			<p><?php echo esc_html( autentik_field( 'dek', $p->ID ) ? (string) autentik_field( 'dek', $p->ID ) : get_the_excerpt( $p ) ); ?></p>
			<?php if ( $lingkup ) : ?><ul class="sc3"><?php foreach ( array_slice( $lingkup, 0, 3 ) as $r ) : ?><li><?php echo esc_html( $r['teks'] ); ?></li><?php endforeach; ?></ul><?php endif; ?>
			<?php if ( $link ) : ?><span class="go" aria-hidden="true"><?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></span><?php endif; ?>
		</div>
	</<?php echo $tag; // phpcs:ignore ?>>
	<?php
}

/**
 * Seksi CTA penutup (dipakai di semua halaman): foto kantor, ajakan, kartu kantor dengan status buka.
 */
function autentik_cta() {
	$tel = preg_replace( '/\D+/', '', autentik_opt( 'phone' ) );
	?>
	<section class="bh-cta">
		<div class="bh-cta-bg" aria-hidden="true"><img src="<?php echo esc_url( autentik_img( 'kontak.jpg' ) ); ?>"<?php echo autentik_srcset( autentik_img( 'kontak.jpg' ), '(max-width:760px) 100vw, 60vw' ); // phpcs:ignore ?> alt="" loading="lazy" width="2000" height="1333"></div>
		<div class="wrap bh-cta-in">
			<div class="rv">
				<h2>Dokumen belum lengkap? Anda tetap dapat berkonsultasi</h2>
				<p>Anda cukup menyampaikan persoalannya terlebih dahulu. Setelah itu, kami akan memberi tahu dokumen apa saja yang diperlukan beserta perkiraan biaya jasa hukumnya.</p>
				<div class="acts">
					<a class="btn b-gold" href="<?php echo esc_url( autentik_konsultasi_url() ); ?>">Jadwalkan Konsultasi <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
					<a class="btn b-line" href="<?php echo esc_url( autentik_wa( autentik_wa_pesan() ) ); ?>" target="_blank" rel="noopener"><?php echo autentik_icon( 'wa' ); // phpcs:ignore ?>Hubungi lewat WhatsApp</a>
				</div>
			</div>
			<address class="bh-office rv">
				<b>Kantor Medan Baru</b>
				<span class="ln"><?php echo autentik_icon( 'pin' ); // phpcs:ignore ?><span><?php echo esc_html( autentik_address() ); ?></span></span>
				<span class="ln"><?php echo autentik_icon( 'phone' ); // phpcs:ignore ?><span><a href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo esc_html( autentik_opt( 'phone' ) ); ?></a></span></span>
				<span class="ln"><?php echo autentik_icon( 'clock' ); // phpcs:ignore ?><span><?php echo esc_html( autentik_opt( 'hours' ) ); ?> <span class="open-now" data-open-now hidden><i></i><em></em></span></span></span>
				<a class="bh-map" href="<?php echo esc_url( autentik_opt( 'maps' ) ); ?>" target="_blank" rel="noopener">Petunjuk Arah <?php echo autentik_icon( 'arrow' ); // phpcs:ignore ?></a>
			</address>
		</div>
	</section>
	<?php
}

/**
 * Tautan formulir konsultasi yang membawa konteks halaman (bidang layanan) ke formulir.
 */
function autentik_konsultasi_url( $bidang = '' ) {
	if ( '' === $bidang ) {
		if ( is_singular( 'layanan' ) ) {
			$bidang = get_post_field( 'post_name', get_queried_object_id() );
		} elseif ( is_singular( 'post' ) ) {
			$lay    = autentik_post_layanan( get_queried_object_id() );
			$bidang = $lay ? $lay->post_name : '';
		}
	}
	$url = home_url( '/kontak/' );
	return ( $bidang ? add_query_arg( 'bidang', rawurlencode( $bidang ), $url ) : $url ) . '#form-konsultasi';
}

/**
 * Layanan terkait sebuah artikel: kolom term `layanan_terkait` (CMS) atau pemetaan slug kategori.
 */
function autentik_post_layanan( $post_id ) {
	foreach ( get_the_category( $post_id ) as $c ) {
		$id = (int) get_term_meta( $c->term_id, 'layanan_terkait', true );
		if ( $id && 'layanan' === get_post_type( $id ) ) {
			return get_post( $id );
		}
		$map = autentik_cat_to_layanan();
		if ( isset( $map[ $c->slug ] ) ) {
			$p = get_page_by_path( $map[ $c->slug ], OBJECT, 'layanan' );
			if ( $p ) {
				return $p;
			}
		}
	}
	return null;
}

/**
 * Pesan WhatsApp pra-isi sesuai halaman yang sedang dibaca.
 */
function autentik_wa_pesan() {
	if ( is_singular( array( 'layanan', 'post' ) ) ) {
		return 'Halo, Law Firm Autentik Analitika. Saya telah membaca "' . autentik_plain_title( get_queried_object_id() ) . '" di situs Anda dan ingin mengajukan pertanyaan.';
	}
	return '';
}

/**
 * Anggota tim yang ditampilkan sebagai bagian firma (notaris mitra tidak ditampilkan sebagai anggota).
 *
 * @return WP_Post[]
 */
function autentik_tim_publik() {
	return array_values( array_filter( autentik_tim_all(), function ( $t ) { return 'notaris_mitra' !== (string) autentik_field( 'status_profesi', $t->ID ); } ) );
}

/**
 * Apakah anggota tim berstatus advokat (sudah disumpah) menurut data CMS.
 */
function autentik_is_advokat( $id ) {
	return 'advokat' === (string) autentik_field( 'status_profesi', $id );
}

/**
 * Penanda "Foto contoh" untuk gambar demo (judul lampiran diawali "DEMO"): hilang sendiri saat foto asli diunggah.
 */
function autentik_demo_tag( $post_or_attachment ) {
	$att = is_numeric( $post_or_attachment ) ? (int) $post_or_attachment : 0;
	if ( ! $att && $post_or_attachment instanceof WP_Post ) {
		$att = 'attachment' === $post_or_attachment->post_type ? $post_or_attachment->ID : (int) get_post_thumbnail_id( $post_or_attachment );
	}
	return ( $att && 0 === stripos( (string) get_the_title( $att ), 'DEMO' ) ) ? '<span class="demo-tag">Foto contoh</span>' : '';
}

/**
 * Klien yang boleh tampil. $semua = true untuk menghitung seluruh klien.
 */
function autentik_klien( $semua = false ) {
	$all = get_posts( array( 'post_type' => 'klien', 'numberposts' => 50, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $semua || autentik_opt( 'preview_klien' ) ) {
		return $all;
	}
	return array_values(
		array_filter(
			$all,
			function ( $k ) {
				return (bool) autentik_field( 'izin_tayang', $k->ID );
			}
		)
	);
}

/**
 * Satu petak logo klien: logo asli bila ada, bila belum ada tampil sebagai logotype nama perusahaan.
 */
function autentik_klien_tile( $k, $tag = 'li' ) {
	$name = get_the_title( $k );
	$bare = preg_replace( '/^PT\.?\s+/i', '', $name );
	$site = (string) autentik_field( 'situs', $k->ID );
	echo '<' . $tag . ' class="lg-tile' . ( has_post_thumbnail( $k ) ? '' : ' wm' ) . '">';
	echo $site ? '<a href="' . esc_url( $site ) . '" target="_blank" rel="noopener nofollow">' : '<span class="in">';
	if ( has_post_thumbnail( $k ) ) {
		echo get_the_post_thumbnail( $k, 'medium', array( 'alt' => $name, 'loading' => 'lazy' ) );
	} else {
		echo '<span class="wmk" role="img" aria-label="' . esc_attr( $name ) . '"><small aria-hidden="true">PT</small><b aria-hidden="true">' . esc_html( $bare ) . '</b></span>';
	}
	echo $site ? '</a>' : '</span>';
	if ( has_post_thumbnail( $k ) ) {
		echo '<span class="lg-name">' . esc_html( $bare ) . '</span>';
	}
	echo '</' . $tag . '>';
}

/**
 * Ambil judul (Heading 1 pertama) + paragraf pembuka dari isi halaman, sisanya dikembalikan sebagai blok.
 * Dengan ini teks banner tiap halaman bisa diedit klien lewat editor.
 *
 * @return array{0:string,1:string,2:array}
 */
function autentik_page_head( $post_id, $title_default = '', $dek_default = '' ) {
	$blocks = parse_blocks( get_post_field( 'post_content', $post_id ) );
	$blocks = array_values( array_filter( $blocks, function ( $b ) { return $b['blockName'] || trim( $b['innerHTML'] ) !== ''; } ) );
	$title  = $title_default ? $title_default : get_the_title( $post_id );
	$dek    = has_excerpt( $post_id ) ? get_the_excerpt( $post_id ) : $dek_default;
	if ( $blocks && 'core/heading' === $blocks[0]['blockName'] && 1 === (int) ( $blocks[0]['attrs']['level'] ?? 2 ) ) {
		$title = trim( wp_strip_all_tags( $blocks[0]['innerHTML'] ) );
		array_shift( $blocks );
		if ( $blocks && 'core/paragraph' === $blocks[0]['blockName'] ) {
			$dek = trim( wp_strip_all_tags( $blocks[0]['innerHTML'] ) );
			array_shift( $blocks );
		}
	}
	return array( $title, $dek, $blocks );
}
