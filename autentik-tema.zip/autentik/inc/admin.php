<?php
/**
 * CMS bermerek Autentik: halaman login, warna admin navy–emas, menu & label berbahasa Indonesia,
 * dasbor sesuai hak akses, Customizer terkunci untuk non-Administrator, nama akun tidak bocor ke publik,
 * halaman inti & plugin inti terlindung dari penghapusan.
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------------------------------------------------------------- Halaman login */
function autentik_login_css() {
	$f    = AUTENTIK_URI . '/assets/fonts/';
	$logo = AUTENTIK_URI . '/assets/img/logo-96.webp';
	$png  = AUTENTIK_URI . '/assets/img/logo-160.png';
	?>
	<style>
		@font-face{font-family:'Plus Jakarta Sans';font-style:normal;font-weight:400 800;font-display:swap;src:url(<?php echo esc_url( $f . 'plus-jakarta-sans-normal-latin.woff2' ); ?>) format('woff2')}
		@font-face{font-family:'Source Serif 4';font-style:normal;font-weight:500 700;font-display:swap;src:url(<?php echo esc_url( $f . 'source-serif-4-normal-latin.woff2' ); ?>) format('woff2')}
		body.login{background:#061C3B linear-gradient(160deg,#0A3266 0%,#061C3B 70%);font-family:'Plus Jakarta Sans',system-ui,sans-serif;color:#D3DBE8}
		body.login #login{width:360px;max-width:calc(100% - 32px);padding-top:8vh}
		body.login h1 a{background:url(<?php echo esc_url( $png ); ?>) center/contain no-repeat;background-image:image-set(url(<?php echo esc_url( $logo ); ?>) type('image/webp'),url(<?php echo esc_url( $png ); ?>) type('image/png'));width:88px;height:88px;margin-bottom:12px}
		body.login h1::after{content:"Law Firm Autentik Analitika";display:block;text-align:center;color:#fff;font:600 1.3rem/1.25 'Source Serif 4',Georgia,serif;margin-top:4px}
		body.login h1 + p,body.login .message,body.login .notice,body.login .success{border-left-color:#EAB466;border-radius:2px;color:#0B1F3F}
		body.login .aa-login-sub{text-align:center;margin:-6px 0 18px;font-size:13px;color:#9FB2CF;letter-spacing:.02em}
		body.login form{border:0;border-radius:4px;box-shadow:0 30px 60px -20px rgba(3,12,28,.6);padding:28px 26px}
		body.login label{color:#0B1F3F;font-weight:600;font-size:14px}
		body.login input[type=text],body.login input[type=password],body.login input[type=email]{border-radius:2px;border-color:#9AA8BC;font-size:16px}
		body.login input:focus{border-color:#0A3266;box-shadow:0 0 0 2px rgba(10,50,102,.25)}
		body.login .button.button-primary,body.login .wp-core-ui .button-primary{background:#0A3266!important;border-color:#0A3266!important;color:#fff!important;border-radius:2px;font-weight:700;padding:0 20px;min-height:40px}
		body.login .button.button-primary:hover,body.login .button.button-primary:focus{background:#1A4C86!important;border-color:#1A4C86!important}
		body.login .button.button-primary:focus-visible{outline:2px solid #EAB466;outline-offset:2px}
		body.login .button.wp-hide-pw .dashicons{color:#0A3266}
		body.login #nav,body.login #backtoblog{text-align:center}
		body.login #nav a,body.login #backtoblog a,body.login .privacy-policy-page-link a{color:#D3DBE8}
		body.login #nav a:hover,body.login #backtoblog a:hover,body.login #nav a:focus,body.login #backtoblog a:focus{color:#EAB466}
		.login .language-switcher{display:none}
	</style>
	<?php
}
add_action( 'login_enqueue_scripts', 'autentik_login_css' );
add_filter( 'login_headerurl', function () { return home_url( '/' ); } );
add_filter( 'login_headertext', function () { return autentik_opt( 'firm' ); } );
add_filter(
	'login_message',
	function ( $m ) {
		return '<p class="aa-login-sub">Halaman pengelolaan situs · khusus tim kantor</p>' . $m;
	}
);
// Teks login tetap Indonesia walau bahasa situs belum diubah.
add_action(
	'login_init',
	function () {
		add_filter(
			'gettext',
			function ( $tr, $text, $domain ) {
				if ( 'default' !== $domain ) {
					return $tr;
				}
				$map = array(
					'Username or Email Address' => 'Nama pengguna atau email',
					'Password'                  => 'Kata sandi',
					'Remember Me'               => 'Ingat saya',
					'Log In'                    => 'Masuk',
					'Lost your password?'       => 'Lupa kata sandi?',
					'&larr; Go to %s'           => '&larr; Kembali ke %s',
					'Get New Password'          => 'Minta kata sandi baru',
					'Please enter your username or email address. You will receive an email message with instructions on how to reset your password.' => 'Masukkan nama pengguna atau email Anda. Petunjuk untuk mengatur ulang kata sandi akan dikirim ke email Anda.',
					'Show password'             => 'Tampilkan kata sandi',
					'Hide password'             => 'Sembunyikan kata sandi',
					'You are now logged out.'   => 'Anda telah keluar.',
				);
				return $map[ $text ] ?? $tr;
			},
			10,
			3
		);
		add_filter(
			'gettext_with_context',
			function ( $tr, $text ) {
				return '&larr; Go to %s' === $text ? '&larr; Kembali ke %s' : $tr;
			},
			10,
			2
		);
	}
);

/* ---------------------------------------------------------------- Nama menu sesuai glosarium (Artikel, Layanan, Tim) */
function autentik_rename_posts() {
	global $wp_post_types;
	if ( empty( $wp_post_types['post'] ) ) {
		return;
	}
	$l                     = $wp_post_types['post']->labels;
	$l->name               = 'Artikel';
	$l->singular_name      = 'Artikel';
	$l->menu_name          = 'Artikel';
	$l->name_admin_bar     = 'Artikel';
	$l->all_items          = 'Semua Artikel';
	$l->add_new            = 'Tulis Artikel';
	$l->add_new_item       = 'Tulis Artikel Baru';
	$l->edit_item          = 'Ubah Artikel';
	$l->new_item           = 'Artikel Baru';
	$l->view_item          = 'Lihat Artikel';
	$l->view_items         = 'Lihat Artikel';
	$l->search_items       = 'Cari Artikel';
	$l->not_found          = 'Belum ada artikel';
	$l->not_found_in_trash = 'Tidak ada artikel di tempat sampah';
	$l->item_published     = 'Artikel diterbitkan.';
	$l->item_updated       = 'Artikel diperbarui.';
	$l->item_scheduled     = 'Artikel dijadwalkan.';
	$l->item_reverted_to_draft = 'Artikel dikembalikan ke draf.';
}
add_action( 'init', 'autentik_rename_posts', 20 );

function autentik_cpt_labels( $args, $type ) {
	$set = array(
		'layanan' => array( 'Layanan', 'Layanan', 'Layanan' ),
		'tim'     => array( 'Tim Hukum', 'Anggota Tim', 'Tim Hukum' ),
		'klien'   => array( 'Klien', 'Klien', 'Klien' ),
	);
	if ( isset( $set[ $type ] ) ) {
		list( $jamak, $tunggal, $menu ) = $set[ $type ];
		$args['labels'] = array_merge(
			(array) ( $args['labels'] ?? array() ),
			array(
				'name'          => $jamak,
				'singular_name' => $tunggal,
				'menu_name'     => $menu,
				'all_items'     => 'Semua ' . $jamak,
				'add_new'       => 'Tambah ' . $tunggal,
				'add_new_item'  => 'Tambah ' . $tunggal,
				'edit_item'     => 'Ubah ' . $tunggal,
				'view_item'     => 'Lihat ' . $tunggal,
				'search_items'  => 'Cari',
				'not_found'     => 'Belum ada data',
			)
		);
	}
	return $args;
}
add_filter( 'register_post_type_args', 'autentik_cpt_labels', 10, 2 );

/* ---------------------------------------------------------------- Menu: rapi, lencana pesan belum ditangani */
function autentik_pesan_belum() {
	$n = get_transient( 'autentik_pesan_baru' );
	if ( false === $n ) {
		$n = count(
			get_posts(
				array(
					'post_type'   => 'pesan',
					'post_status' => 'private',
					'numberposts' => 500,
					'fields'      => 'ids',
					'meta_query'  => array( array( 'key' => 'ditangani', 'compare' => 'NOT EXISTS' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
				)
			)
		);
		set_transient( 'autentik_pesan_baru', $n, 10 * MINUTE_IN_SECONDS );
	}
	return (int) $n;
}

function autentik_admin_menu() {
	remove_menu_page( 'edit-comments.php' ); // situs tidak memakai komentar
	if ( ! current_user_can( 'manage_options' ) ) {
		remove_menu_page( 'tools.php' );
	}
	global $menu;
	$baru = post_type_exists( 'pesan' ) && current_user_can( 'autentik_pesan' ) ? autentik_pesan_belum() : 0;
	if ( $baru && is_array( $menu ) ) {
		foreach ( $menu as $k => $item ) {
			if ( isset( $item[2] ) && 'edit.php?post_type=pesan' === $item[2] ) {
				$menu[ $k ][0] .= ' <span class="awaiting-mod" title="Belum ditangani"><span class="pending-count">' . (int) $baru . '</span></span>'; // phpcs:ignore
			}
		}
	}
}
add_action( 'admin_menu', 'autentik_admin_menu', 99 );
add_action( 'save_post_pesan', function () { delete_transient( 'autentik_pesan_baru' ); } );
add_action( 'deleted_post', function () { delete_transient( 'autentik_pesan_baru' ); } );

function autentik_menu_order( $order ) {
	$first = array( 'index.php', 'edit.php', 'edit.php?post_type=layanan', 'edit.php?post_type=tim', 'edit.php?post_type=klien', 'edit.php?post_type=pesan', 'edit.php?post_type=page', 'upload.php' );
	return array_merge( $first, array_diff( (array) $order, $first ) );
}
add_filter( 'custom_menu_order', '__return_true' );
add_filter( 'menu_order', 'autentik_menu_order' );

function autentik_admin_bar( $bar ) {
	$bar->remove_node( 'wp-logo' );
	$bar->remove_node( 'comments' );
}
add_action( 'admin_bar_menu', 'autentik_admin_bar', 99 );

/* ---------------------------------------------------------------- Warna admin navy–emas */
function autentik_admin_css() {
	?>
	<style>
		#adminmenuback,#adminmenuwrap,#adminmenu{background:#0A3266}
		#adminmenu a{color:#D3DBE8}
		#adminmenu div.wp-menu-image::before{color:#9FB2CF}
		#adminmenu li.menu-top:hover,#adminmenu li.opensub>a.menu-top,#adminmenu li>a.menu-top:focus{background:#082A56;color:#fff}
		#adminmenu li.menu-top:hover div.wp-menu-image::before{color:#EAB466}
		#adminmenu li.wp-has-current-submenu a.wp-has-current-submenu,#adminmenu li.current a.menu-top,#adminmenu .wp-menu-arrow,#adminmenu .wp-menu-arrow div{background:#EAB466;color:#0B2445}
		#adminmenu li.wp-has-current-submenu div.wp-menu-image::before,#adminmenu li.current div.wp-menu-image::before{color:#0B2445}
		#adminmenu .wp-submenu,#adminmenu .wp-has-current-submenu .wp-submenu,#adminmenu a.wp-has-current-submenu:focus+.wp-submenu{background:#061C3B}
		#adminmenu .wp-submenu a{color:#C3CEDF}
		#adminmenu .wp-submenu a:hover,#adminmenu .wp-submenu li.current a{color:#EAB466}
		#adminmenu .awaiting-mod,#adminmenu .update-plugins{background:#EAB466;color:#0B2445}
		#collapse-button{color:#9FB2CF}
		#wpadminbar{background:#061C3B}
		#wpadminbar .ab-item,#wpadminbar a.ab-item,#wpadminbar>#wp-toolbar span.ab-label{color:#D3DBE8}
		#wpadminbar .ab-top-menu>li:hover>.ab-item{background:#0A3266;color:#EAB466}
		.wp-core-ui .button-primary{background:#0A3266;border-color:#0A3266}
		.wp-core-ui .button-primary:hover,.wp-core-ui .button-primary:focus{background:#1A4C86;border-color:#1A4C86}
		a{color:#0A3266}
		#autentik_cms .aa-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin-top:6px}
		#autentik_cms .aa-grid a{display:block;padding:14px 16px;border:1px solid #CAD4E1;border-radius:4px;text-decoration:none;color:#0B1F3F;background:#fff}
		#autentik_cms .aa-grid a:hover,#autentik_cms .aa-grid a:focus{border-color:#0A3266;box-shadow:0 0 0 1px #0A3266}
		#autentik_cms .aa-grid b{display:block;font-size:14px}
		#autentik_cms .aa-grid span{display:block;margin-top:4px;color:#5E6A7D;font-size:12px}
		#autentik_cms .aa-grid .n{float:right;background:#EAB466;color:#0B2445;border-radius:10px;padding:0 8px;font-weight:700;font-size:12px}
		#autentik_cms ol{margin:14px 0 0 18px}
		#autentik_cms h3{margin:18px 0 0;font-size:13px}
		.aa-inti{color:#5E6A7D;font-weight:400}
	</style>
	<?php
}
add_action( 'admin_head', 'autentik_admin_css' );

add_filter(
	'admin_footer_text',
	function () {
		return 'CMS ' . esc_html( autentik_opt( 'firm' ) ) . ' · Memerlukan bantuan? Hubungi pengelola situs (ARKA LABS). Panduan: PANDUAN-MENULIS-ARTIKEL.';
	}
);

/* ---------------------------------------------------------------- Dasbor: tombol cepat sesuai hak akses */
function autentik_dashboard() {
	foreach ( array( 'dashboard_primary', 'dashboard_quick_press', 'dashboard_site_health', 'dashboard_activity' ) as $w ) {
		remove_meta_box( $w, 'dashboard', 'side' );
		remove_meta_box( $w, 'dashboard', 'normal' );
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		remove_meta_box( 'dashboard_right_now', 'dashboard', 'normal' );
	}
	remove_action( 'welcome_panel', 'wp_welcome_panel' );
	wp_add_dashboard_widget( 'autentik_cms', 'Pengelolaan Situs ' . autentik_opt( 'firm' ), 'autentik_dashboard_widget' );
}
add_action( 'wp_dashboard_setup', 'autentik_dashboard' );

function autentik_dashboard_widget() {
	$items = array(
		array( admin_url( 'post-new.php' ), 'Tulis artikel', 'Artikel dan panduan hukum baru', 0, 'edit_posts' ),
		array( admin_url( 'edit.php' ), 'Artikel saya', 'Draf, menunggu tinjauan, dan telah terbit', 0, 'edit_posts' ),
		array( admin_url( 'edit.php?post_type=pesan' ), 'Pesan masuk', 'Permintaan konsultasi dari formulir', post_type_exists( 'pesan' ) && current_user_can( 'autentik_pesan' ) ? autentik_pesan_belum() : 0, 'autentik_pesan' ),
		array( admin_url( 'edit.php?post_type=tim' ), 'Tim hukum', 'Foto, status profesi, dan kualifikasi', 0, 'edit_others_posts' ),
		array( admin_url( 'edit.php?post_type=layanan' ), 'Layanan', 'Lingkup, daftar dokumen, dan tanya jawab', 0, 'edit_others_posts' ),
		array( admin_url( 'edit.php?post_type=klien' ), 'Klien', 'Logo dan izin tertulis', 0, 'edit_others_posts' ),
		array( admin_url( 'customize.php' ), 'Kontak dan tampilan', 'Nomor WhatsApp, alamat, jam kerja, serta teks dan foto bagian pembuka beranda. Foto pendiri dan advokat diganti melalui menu Tim Hukum.', 0, 'edit_theme_options' ),
		array( home_url( '/' ), 'Lihat situs', 'Buka situs di tab ini', 0, 'read' ),
	);
	echo '<div class="aa-grid">';
	foreach ( $items as $it ) {
		if ( ! current_user_can( $it[4] ) ) {
			continue;
		}
		echo '<a href="' . esc_url( $it[0] ) . '"><b>' . esc_html( $it[1] ) . ( $it[3] ? ' <span class="n">' . (int) $it[3] . ' belum ditangani</span>' : '' ) . '</b><span>' . esc_html( $it[2] ) . '</span></a>';
	}
	echo '</div>';
	echo '<h3>Menulis artikel yang baik</h3><ol>';
	echo '<li>Blok pertama berisi <b>Jawaban singkat</b> (40–60 kata). Ringkasan pada kartu artikel dan Google diambil otomatis dari blok ini.</li>';
	echo '<li>Subjudul memakai <b>Heading 2</b> agar daftar isi terbentuk otomatis. Panjang judul 30–65 karakter.</li>';
	echo '<li>Pada panel kanan, pasang <b>gambar sampul</b>, pilih <b>kategori</b>, lalu isi <b>Ditulis oleh</b> dan <b>Ditinjau oleh</b>. Keduanya wajib; tanpa keduanya tombol Terbitkan tidak dapat digunakan.</li>';
	echo '<li>Jangan menyebut nama klien, pihak lawan, atau nomor perkara tanpa izin tertulis.</li>';
	echo '</ol>';
}
add_filter( 'screen_layout_columns', function ( $c ) { $c['dashboard'] = 1; return $c; } );
add_filter( 'get_user_option_screen_layout_dashboard', function () { return 1; } );

/* ---------------------------------------------------------------- Customizer: Legalitas, Analitik, Identitas situs, Beranda statis hanya Administrator */
function autentik_customizer_kunci( $wp ) {
	$kunci = array( 'aa_legal', 'aa_analitik', 'title_tagline', 'static_front_page' );
	foreach ( $kunci as $sid ) {
		$sec = $wp->get_section( $sid );
		if ( $sec ) {
			$sec->capability = 'manage_options';
		}
	}
	foreach ( $wp->controls() as $c ) {
		if ( in_array( $c->section, $kunci, true ) ) {
			$c->capability = 'manage_options';
			foreach ( (array) $c->settings as $st ) {
				if ( $st instanceof WP_Customize_Setting ) {
					$st->capability = 'manage_options';
				}
			}
		}
	}
	if ( $wp->get_section( 'colors' ) ) {
		$wp->remove_section( 'colors' );
	}
}
add_action( 'customize_register', 'autentik_customizer_kunci', 99 );

/* ---------------------------------------------------------------- Nama akun WP tidak pernah tampil sebagai penulis publik */
function autentik_penulis_publik( $name ) {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return $name;
	}
	return 'Tim Hukum ' . preg_replace( '/^Law Firm\s+/i', '', (string) autentik_opt( 'firm' ) );
}
add_filter( 'the_author', 'autentik_penulis_publik' );
add_filter(
	'oembed_response_data',
	function ( $d ) {
		$d['author_name'] = autentik_penulis_publik( '' );
		$d['author_url']  = home_url( '/tim/' );
		return $d;
	}
);

/* ---------------------------------------------------------------- Halaman inti tidak bisa dibuang (non-Administrator) */
function autentik_halaman_inti( $id ) {
	$id = (int) $id;
	if ( ! $id || 'page' !== get_post_type( $id ) ) {
		return false;
	}
	if ( in_array( $id, array( (int) get_option( 'page_on_front' ), (int) get_option( 'page_for_posts' ), (int) get_option( 'wp_page_for_privacy_policy' ) ), true ) ) {
		return true;
	}
	return in_array( get_post_field( 'post_name', $id ), array( 'beranda', 'kontak', 'artikel', 'kebijakan-privasi', 'konsultasi', 'tentang-kami', 'tim', 'klien', 'layanan' ), true );
}
add_filter(
	'map_meta_cap',
	function ( $caps, $cap, $uid, $args ) {
		if ( in_array( $cap, array( 'delete_post', 'delete_page' ), true ) && ! empty( $args[0] ) && autentik_halaman_inti( $args[0] ) && ! user_can( $uid, 'manage_options' ) ) {
			$caps[] = 'do_not_allow';
		}
		return $caps;
	},
	10,
	4
);
add_filter(
	'display_post_states',
	function ( $s, $p ) {
		if ( 'page' === $p->post_type && autentik_halaman_inti( $p->ID ) ) {
			$s['aa_inti'] = '<span class="aa-inti">Halaman inti</span>';
		}
		return $s;
	},
	10,
	2
);

/* ---------------------------------------------------------------- Plugin "Autentik — Jenis Konten" tidak bisa dihapus dari layar Plugin
 * (berlaku juga saat plugin nonaktif, karena kode ini ada di tema). Menghapusnya = Layanan, Tim, Klien,
 * dan Pesan Masuk hilang dari admin & situs. */
define( 'AUTENTIK_PLUGIN_INTI', 'autentik-jenis-konten/autentik-jenis-konten.php' );
add_filter(
	'plugin_action_links_' . AUTENTIK_PLUGIN_INTI,
	function ( $l ) {
		unset( $l['delete'] );
		return $l;
	}
);
add_filter(
	'plugin_row_meta',
	function ( $m, $file ) {
		if ( AUTENTIK_PLUGIN_INTI === $file ) {
			$m[] = '<strong>Wajib aktif: memuat Layanan, Tim, Klien, Pesan Masuk, dan CMS staf.</strong>';
		}
		return $m;
	},
	10,
	2
);
add_action(
	'delete_plugin',
	function ( $file ) {
		if ( AUTENTIK_PLUGIN_INTI === $file ) {
			wp_die( 'Plugin "Autentik — Jenis Konten" tidak boleh dihapus karena memuat Layanan, Tim, Klien, dan Pesan Masuk. Silakan hubungi pengelola situs.', 'Tidak diizinkan', array( 'back_link' => true ) );
		}
	}
);
