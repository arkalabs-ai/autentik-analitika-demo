<?php
/**
 * Pita "Pratinjau": hanya tampil bila opsi `autentik_pratinjau` terisi (situs demo Playground).
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function autentik_pita_pratinjau() {
	$t = (string) get_option( 'autentik_pratinjau', '' );
	if ( '' === $t ) {
		return;
	}
	echo '<div class="pita-pratinjau" role="note"><b>Pratinjau</b> ' . esc_html( $t ) . '</div>';
}
add_action( 'wp_body_open', 'autentik_pita_pratinjau', 1 );

function autentik_pita_pratinjau_admin() {
	$t = (string) get_option( 'autentik_pratinjau', '' );
	if ( '' !== $t ) {
		echo '<div class="notice notice-info"><p><strong>Situs pratinjau.</strong> Perubahan di sini tidak tersimpan setelah tab browser ditutup. Silakan mencoba menulis artikel, mengubah data tim, dan melihat Pesan Masuk.</p></div>';
	}
}
add_action( 'admin_notices', 'autentik_pita_pratinjau_admin' );
