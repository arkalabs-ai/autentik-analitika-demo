<?php
/**
 * Pengaturan kantor di Tampilan › Sesuaikan (Customizer).
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Nilai bawaan — semuanya bisa diubah klien lewat Customizer.
 */
function autentik_defaults() {
	return array(
		'firm'          => 'Law Firm Autentik Analitika',
		'tagline'       => 'Kantor hukum bisnis dan pertanahan di Medan',
		'phone'         => '0817 2321 111',
		'wa'            => '08172321111',
		'email'         => 'autentikanalitika@gmail.com',
		'street'        => 'Jalan Iskandar Muda No. 10 D–E, Kelurahan Darat',
		'district'      => 'Kecamatan Medan Baru',
		'city'          => 'Kota Medan',
		'region'        => 'Sumatera Utara',
		'postal'        => '',
		'hours'         => 'Senin–Jumat, 09.00–17.00 WIB',
		'hours_rule'    => '1-5|09:00-17:00',
		'maps'          => 'https://www.google.com/maps/search/?api=1&query=Jalan+Iskandar+Muda+No+10+Medan+Baru',
		'lat'           => '',
		'lng'           => '',
		'facebook'      => '',
		'tiktok'        => 'https://www.tiktok.com/@lawfirmautentik',
		'instagram'     => '',
		'linkedin'      => '',
		'sk'            => 'AHU-0000951-AH.01.18 Tahun 2025',
		'npwp'          => '1000.0000.0292.3713',
		'nib'           => '0708250007355',
		'founded'       => '2025',
		'hero_eyebrow'  => 'Kantor Hukum · Medan, Sumatera Utara',
		'hero_title'    => 'Pendampingan hukum bisnis dan *pertanahan* di Medan',
		'hero_text'     => 'Kami mendampingi pelaku usaha, perusahaan, dan keluarga di Sumatera Utara dalam urusan kontrak, perizinan berusaha, serta jual beli dan pendaftaran hak atas tanah. Lingkup pekerjaan dan biaya jasa hukum kami sampaikan secara tertulis sebelum pekerjaan dimulai.',
		'hero_person'   => '',
		'hero_bg'       => '',
		'about_text'    => 'Law Firm Autentik Analitika berkantor di Medan Baru sejak 2025 dan terdaftar di Kementerian Hukum RI. Kami menangani urusan hukum perusahaan dan perorangan, terutama kontrak, perizinan usaha, dan pertanahan. Ketiga bidang ini sering saling berkaitan. Karena itu, kami menelaah setiap persoalan secara menyeluruh dan menyampaikan hasil telaah kepada Anda secara terus terang.',
		'lead_email'    => '',
		// Kutipan diatribusikan ke pendiri: perlu persetujuan tertulis Ketlyn sebelum tayang (qa/23 E8).
		'quote_text'    => 'Pemeriksaan sebelum transaksi jauh lebih ringan biayanya dibandingkan berperkara setelah timbul sengketa.',
		// Default 0: klien hanya tampil bila centang "izin tertulis" (qa/24 P0-4). Nilai 1 hanya untuk pratinjau.
		'preview_klien' => 0,
		'scam_notice'   => 1,
		'memberships'   => '',
	);
}

/**
 * Ambil satu pengaturan.
 */
function autentik_opt( $key ) {
	$d = autentik_defaults();
	return get_theme_mod( 'aa_' . $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

/**
 * Alamat lengkap satu baris.
 */
function autentik_address() {
	return implode( ', ', array_filter( array( autentik_opt( 'street' ), autentik_opt( 'district' ), autentik_opt( 'city' ), autentik_opt( 'region' ), autentik_opt( 'postal' ) ) ) );
}

function autentik_customize( $wp ) {
	$sections = array(
		'aa_kontak' => array(
			'title'  => 'Autentik: Kontak & Lokasi',
			'fields' => array(
				'phone'      => array( 'Nomor telepon (yang ditampilkan)', 'text' ),
				'wa'         => array( 'Nomor WhatsApp (contoh: 0817xxxx)', 'text' ),
				'email'      => array( 'Email kantor', 'email' ),
				'lead_email' => array( 'Email penerima formulir (bila kosong, dikirim ke email admin)', 'email' ),
				'street'     => array( 'Jalan dan kelurahan', 'text' ),
				'district'   => array( 'Kecamatan', 'text' ),
				'city'       => array( 'Kota', 'text' ),
				'region'     => array( 'Provinsi', 'text' ),
				'postal'     => array( 'Kode pos', 'text' ),
				'hours'      => array( 'Jam kerja (yang ditampilkan)', 'text' ),
				'hours_rule' => array( 'Aturan jam kerja untuk penanda "Sedang buka" (format: 1-5|09:00-17:00; 1 = Senin)', 'text' ),
				'maps'       => array( 'Tautan Google Maps kantor', 'url' ),
				'lat'        => array( 'Garis lintang/latitude (dari Google Maps, untuk SEO lokal)', 'text' ),
				'lng'        => array( 'Garis bujur/longitude (dari Google Maps, untuk SEO lokal)', 'text' ),
			),
		),
		'aa_sosial' => array(
			'title'  => 'Autentik: Media Sosial',
			'fields' => array(
				'facebook'  => array( 'Tautan Facebook', 'url' ),
				'tiktok'    => array( 'Tautan TikTok', 'url' ),
				'instagram' => array( 'Tautan Instagram', 'url' ),
				'linkedin'  => array( 'Tautan LinkedIn', 'url' ),
			),
		),
		'aa_legal'  => array(
			'title'  => 'Autentik: Legalitas',
			'fields' => array(
				'firm'    => array( 'Nama resmi firma', 'text' ),
				'tagline' => array( 'Keterangan singkat (tagline)', 'text' ),
				'sk'      => array( 'Nomor pendaftaran Kementerian Hukum', 'text' ),
				'npwp'    => array( 'NPWP', 'text' ),
				'nib'     => array( 'NIB', 'text' ),
				'founded' => array( 'Tahun berdiri', 'text' ),
			),
		),
		'aa_beranda' => array(
			'title'  => 'Autentik: Beranda',
			'fields' => array(
				'hero_title'    => array( 'Judul utama (kata yang diapit *tanda bintang* tampil berwarna emas)', 'textarea' ),
				'hero_text'     => array( 'Paragraf di bawah judul', 'textarea' ),
				'hero_person'   => array( 'Foto pimpinan di bagian pembuka beranda (PNG/JPG potret berlatar gelap)', 'image' ),
				'hero_bg'       => array( 'Gambar latar bagian pembuka beranda', 'image' ),
				'about_text'    => array( 'Teks "Tentang Kami" di beranda', 'textarea' ),
				'quote_text'    => array( 'Kutipan prinsip kerja (dicantumkan atas nama pimpinan firma)', 'textarea' ),
				'scam_notice'   => array( 'Tampilkan peringatan "Waspada penipuan yang mengatasnamakan kami" (bilah atas dan halaman Kontak)', 'checkbox' ),
				'memberships'   => array( 'Keanggotaan organisasi profesi (satu per baris; bila kosong, tidak ditampilkan)', 'textarea' ),
				'preview_klien' => array( 'Pratinjau: tampilkan klien yang belum memberikan izin tertulis (JANGAN diaktifkan pada situs yang sudah tayang)', 'checkbox' ),
			),
		),
	);

	$d = autentik_defaults();
	$i = 30;
	foreach ( $sections as $sid => $sec ) {
		$wp->add_section( $sid, array( 'title' => $sec['title'], 'priority' => $i++ ) );
		foreach ( $sec['fields'] as $key => $f ) {
			$san = 'sanitize_text_field';
			if ( 'url' === $f[1] || 'image' === $f[1] ) {
				$san = 'esc_url_raw';
			} elseif ( 'email' === $f[1] ) {
				$san = 'sanitize_email';
			} elseif ( 'textarea' === $f[1] ) {
				$san = 'sanitize_textarea_field';
			} elseif ( 'checkbox' === $f[1] ) {
				$san = 'absint';
			}
			$wp->add_setting( 'aa_' . $key, array( 'default' => $d[ $key ], 'sanitize_callback' => $san ) );
			if ( 'image' === $f[1] ) {
				$wp->add_control( new WP_Customize_Image_Control( $wp, 'aa_' . $key, array( 'label' => $f[0], 'section' => $sid ) ) );
			} else {
				$wp->add_control( 'aa_' . $key, array( 'label' => $f[0], 'section' => $sid, 'type' => $f[1] ) );
			}
		}
	}
}
add_action( 'customize_register', 'autentik_customize' );
