<?php
/**
 * Pengaturan kantor di Tampilan › Sesuaikan (Customizer).
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Nilai bawaan — semuanya bisa diubah klien lewat Customizer.
 */
function autentik_defaults() {
	return array(
		'firm'          => 'Law Firm Autentik Analitika',
		'tagline'       => 'Kantor hukum bisnis dan pertanahan di Medan',
		'phone'         => '0817 2321 111',
		'wa'            => '08172321111',
		'email'         => 'autentikanalitika@gmail.com',
		'street'        => 'Jalan Iskandar Muda No. 10 D–E, Kelurahan Darat',
		'district'      => 'Kecamatan Medan Baru',
		'city'          => 'Kota Medan',
		'region'        => 'Sumatera Utara',
		'postal'        => '',
		'hours'         => 'Senin–Jumat, 09.00–17.00 WIB',
		'hours_rule'    => '1-5|09:00-17:00',
		'maps'          => 'https://www.google.com/maps/search/?api=1&query=Jalan+Iskandar+Muda+No+10+Medan+Baru',
		'lat'           => '',
		'lng'           => '',
		'facebook'      => '',
		'tiktok'        => 'https://www.tiktok.com/@lawfirmautentik',
		'instagram'     => '',
		'linkedin'      => '',
		'sk'            => 'AHU-0000951-AH.01.18 Tahun 2025',
		'npwp'          => '1000.0000.0292.3713',
		'nib'           => '0708250007355',
		'founded'       => '2025',
		'hero_title'    => 'Hukum bisnis, perizinan, dan *pertanahan* di Medan',
		'hero_text'     => 'Kami menangani urusan kontrak, izin usaha, dan tanah bagi pelaku usaha dan keluarga di Medan. Lingkup kerja dan biaya jasa kita sepakati sebelum pekerjaan dimulai.',
		'hero_person'   => '',
		'hero_bg'       => '',
		'about_text'    => 'Law Firm Autentik Analitika berkantor di Jalan Iskandar Muda, Medan Baru, sejak 2025 dan terdaftar di Kementerian Hukum RI. Sehari-hari kami menangani kontrak, izin usaha, dan tanah. Dalam praktik, ketiganya jarang berdiri sendiri: izin usaha bisa tertahan karena anggaran dasar, dan sengketa tanah sering berawal dari perjanjian yang lemah. Karena itu setiap persoalan kami periksa utuh, lalu hasilnya kami sampaikan apa adanya, termasuk bila kabarnya kurang menyenangkan.',
		'lead_email'    => '',
		// Kutipan diatribusikan ke pendiri: perlu persetujuan tertulis Ketlyn sebelum tayang (qa/23 E8).
		'quote_text'    => 'Memeriksa sebelum membayar jauh lebih murah daripada berperkara sesudahnya.',
		// Default 0: klien hanya tampil bila centang "izin tertulis" (qa/24 P0-4). Nilai 1 hanya untuk pratinjau.
		'preview_klien' => 0,
		'scam_notice'   => 1,
		'memberships'   => '',
		'patokan'       => '',
		// Empat fakta di bawah pembuka beranda: "Judul | keterangan" per baris; {layanan} = jumlah layanan terbit (46g T2).
		'fakta'         => "1 hari kerja | Paling lambat pesan Anda kami balas\nBiaya disepakati di awal | Lingkup, waktu, dan biaya jelas sebelum pekerjaan dimulai\n{layanan} bidang layanan | Hukum bisnis, perizinan berusaha, badan usaha, dan pertanahan\nKantor di Medan Baru | Silakan datang untuk konsultasi tatap muka",
		'footer_text'   => 'Kantor hukum di Medan Baru untuk urusan kontrak dan sengketa bisnis, izin usaha, badan usaha, dan pertanahan, bagi perusahaan maupun perorangan.',
		// Foto latar (46g T3): kosong = foto bawaan tema per halaman.
		'cta_bg'        => '',
		'way_bg'        => '',
	);
}

/**
 * Ambil satu pengaturan.
 */
function autentik_opt( $key ) {
	$d = autentik_defaults();
	return get_theme_mod( 'aa_' . $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

/**
 * Alamat lengkap satu baris.
 */
function autentik_address() {
	return implode( ', ', array_filter( array( autentik_opt( 'street' ), autentik_opt( 'district' ), autentik_opt( 'city' ), autentik_opt( 'region' ), autentik_opt( 'postal' ) ) ) );
}

function autentik_customize( $wp ) {
	$sections = array(
		'aa_kontak' => array(
			'title'  => 'Autentik: Kontak & Lokasi',
			'fields' => array(
				'phone'      => array( 'Nomor telepon (yang ditampilkan)', 'text' ),
				'wa'         => array( 'Nomor WhatsApp (contoh: 0817xxxx)', 'text' ),
				'email'      => array( 'Email kantor', 'email' ),
				'lead_email' => array( 'Email penerima formulir (bila kosong, dikirim ke email admin)', 'email' ),
				'street'     => array( 'Jalan dan kelurahan', 'text' ),
				'district'   => array( 'Kecamatan', 'text' ),
				'city'       => array( 'Kota', 'text' ),
				'region'     => array( 'Provinsi', 'text' ),
				'postal'     => array( 'Kode pos', 'text' ),
				'hours'      => array( 'Jam kerja (yang ditampilkan)', 'text' ),
				'hours_rule' => array( 'Aturan jam kerja untuk penanda "Sedang buka" (format: 1-5|09:00-17:00; 1 = Senin)', 'text' ),
				'maps'       => array( 'Tautan Google Maps kantor', 'url' ),
				'patokan'    => array( 'Patokan menuju kantor (tampil di halaman Kontak; mis. bangunan terdekat, lantai, parkir). Kosongkan bila belum ada', 'textarea' ),
				'lat'        => array( 'Garis lintang/latitude (dari Google Maps, untuk SEO lokal)', 'text' ),
				'lng'        => array( 'Garis bujur/longitude (dari Google Maps, untuk SEO lokal)', 'text' ),
			),
		),
		'aa_sosial' => array(
			'title'  => 'Autentik: Media Sosial',
			'fields' => array(
				'facebook'  => array( 'Tautan Facebook', 'url' ),
				'tiktok'    => array( 'Tautan TikTok', 'url' ),
				'instagram' => array( 'Tautan Instagram', 'url' ),
				'linkedin'  => array( 'Tautan LinkedIn', 'url' ),
			),
		),
		'aa_legal'  => array(
			'title'  => 'Autentik: Legalitas',
			'fields' => array(
				'firm'    => array( 'Nama resmi firma', 'text' ),
				'tagline' => array( 'Keterangan singkat (tagline)', 'text' ),
				'sk'      => array( 'Nomor pendaftaran Kementerian Hukum', 'text' ),
				'npwp'    => array( 'NPWP', 'text' ),
				'nib'     => array( 'NIB', 'text' ),
				'founded' => array( 'Tahun berdiri', 'text' ),
			),
		),
		'aa_beranda' => array(
			'title'  => 'Autentik: Beranda',
			'fields' => array(
				'hero_title'    => array( 'Judul utama (kata yang diapit *tanda bintang* tampil berwarna emas)', 'textarea' ),
				'hero_text'     => array( 'Paragraf di bawah judul', 'textarea' ),
				'hero_person'   => array( 'Foto pimpinan di bagian pembuka beranda (PNG/JPG potret berlatar gelap)', 'image' ),
				'hero_bg'       => array( 'Gambar latar bagian pembuka beranda', 'image' ),
				'fakta'         => array( 'Empat fakta di bawah bagian pembuka (satu per baris, format: Judul | keterangan; {layanan} diganti jumlah layanan)', 'textarea' ),
				'about_text'    => array( 'Teks "Tentang Kami" di beranda', 'textarea' ),
				'quote_text'    => array( 'Kutipan prinsip kerja (dicantumkan atas nama pimpinan firma)', 'textarea' ),
				'scam_notice'   => array( 'Tampilkan peringatan "Waspada penipuan yang mengatasnamakan kami" (bilah atas dan halaman Kontak)', 'checkbox' ),
				'memberships'   => array( 'Keanggotaan organisasi profesi (satu per baris; bila kosong, tidak ditampilkan)', 'textarea' ),
				'preview_klien' => array( 'Pratinjau: tampilkan klien yang belum memberikan izin tertulis (JANGAN diaktifkan pada situs yang sudah tayang)', 'checkbox' ),
			),
		),
		'aa_foto'   => array(
			'title'  => 'Autentik: Foto Latar & Footer',
			'fields' => array(
				'cta_bg'      => array( 'Foto latar ajakan konsultasi di akhir halaman (bila kosong, foto bawaan berbeda per halaman)', 'image' ),
				'way_bg'      => array( 'Foto latar bagian "Dari konsultasi sampai pelaksanaan" di beranda', 'image' ),
				'footer_text' => array( 'Deskripsi singkat firma di footer', 'textarea' ),
			),
		),
	);

	$d = autentik_defaults();
	// Validasi dengan pesan merah di Customizer (46g T7): format salah tidak lagi tersimpan diam-diam.
	$cek = array(
		'wa'         => array( '/^\+?[\d\s-]{9,18}$/', 'Nomor WhatsApp harus 9–15 digit, contoh 08172321111.' ),
		'hours_rule' => array( '/^[1-7]-[1-7]\|\d{2}:\d{2}-\d{2}:\d{2}$/', 'Format aturan jam: 1-5|09:00-17:00 (1 = Senin, 7 = Minggu).' ),
		'lat'        => array( '/^-?([0-8]?\d(\.\d+)?|90(\.0+)?)$/', 'Latitude berupa angka desimal, contoh 3.5868.' ),
		'lng'        => array( '/^-?(1[0-7]\d(\.\d+)?|\d{1,2}(\.\d+)?|180(\.0+)?)$/', 'Longitude berupa angka desimal, contoh 98.6560.' ),
	);
	$i = 30;
	foreach ( $sections as $sid => $sec ) {
		$wp->add_section( $sid, array( 'title' => $sec['title'], 'priority' => $i++ ) );
		foreach ( $sec['fields'] as $key => $f ) {
			$san = 'sanitize_text_field';
			if ( 'url' === $f[1] || 'image' === $f[1] ) {
				$san = 'esc_url_raw';
			} elseif ( 'email' === $f[1] ) {
				$san = 'sanitize_email';
			} elseif ( 'textarea' === $f[1] ) {
				$san = 'sanitize_textarea_field';
			} elseif ( 'checkbox' === $f[1] ) {
				$san = 'absint';
			}
			// Penerima lead & pratinjau klien: hanya Administrator (Staf Kantor tetap bisa mengubah kolom lain di bagian ini).
			$cap = in_array( $key, array( 'lead_email', 'preview_klien' ), true ) ? 'manage_options' : 'edit_theme_options';
			$args = array( 'default' => $d[ $key ], 'sanitize_callback' => $san, 'capability' => $cap );
			if ( isset( $cek[ $key ] ) ) {
				$pola = $cek[ $key ];
				$args['validate_callback'] = function ( $v, $nilai ) use ( $pola ) {
					if ( '' !== trim( (string) $nilai ) && ! preg_match( $pola[0], trim( (string) $nilai ) ) ) {
						$v->add( 'format', $pola[1] );
					}
					return $v;
				};
			}
			$wp->add_setting( 'aa_' . $key, $args );
			if ( 'image' === $f[1] ) {
				$wp->add_control( new WP_Customize_Image_Control( $wp, 'aa_' . $key, array( 'label' => $f[0], 'section' => $sid, 'capability' => $cap ) ) );
			} else {
				$wp->add_control( 'aa_' . $key, array( 'label' => $f[0], 'section' => $sid, 'type' => $f[1], 'capability' => $cap ) );
			}
		}
	}
}
add_action( 'customize_register', 'autentik_customize' );
