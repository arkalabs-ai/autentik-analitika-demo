<?php
/**
 * SEO & GEO: schema JSON-LD, llms.txt, robots.txt, meta cadangan.
 * Meta title/description & sitemap ditangani Rank Math bila aktif.
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function autentik_has_seo_plugin() {
	return defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' ) || defined( 'AIOSEO_VERSION' );
}

/**
 * Entitas firma (dipakai berulang, @id stabil agar AI & Google mengenali satu entitas).
 */
// Slogan situs (Pengaturan › Umum) yang masih bawaan Inggris ikut diganti di RSS/judul bawaan.
add_filter( 'option_blogdescription', function ( $v ) {
	return 'Legal Precision · Trusted Counsel' === trim( (string) $v ) ? autentik_slogan() : $v;
} );

function autentik_org_id() {
	return home_url( '/#firma' );
}

/**
 * Tagline berbahasa Indonesia untuk schema/meta. Nilai bawaan lama berbahasa Inggris
 * ("Legal Precision · Trusted Counsel") diganti frasa netral tanpa superlatif.
 */
function autentik_slogan() {
	$t = trim( (string) autentik_opt( 'tagline' ) );
	return ( '' === $t || 'Legal Precision · Trusted Counsel' === $t ) ? 'Kantor hukum di Medan Baru' : $t;
}

/**
 * Nomor tampilan ("0817 2321 111") → format internasional untuk schema ("+62-817-2321-111").
 */
function autentik_tel_intl( $display ) {
	$parts = array_values( array_filter( preg_split( '/[^\d+]+/', trim( (string) $display ) ), 'strlen' ) );
	if ( ! $parts ) {
		return '';
	}
	if ( 0 === strpos( $parts[0], '+62' ) ) {
		$parts[0] = substr( $parts[0], 3 );
	} elseif ( 0 === strpos( $parts[0], '0' ) ) {
		$parts[0] = substr( $parts[0], 1 );
	} elseif ( 0 === strpos( $parts[0], '62' ) && count( $parts ) > 1 ) {
		$parts[0] = substr( $parts[0], 2 );
	}
	$parts = array_values( array_filter( $parts, 'strlen' ) );
	return $parts ? '+62-' . implode( '-', $parts ) : '';
}

/**
 * Potong teks dengan rapi: utamakan akhir kalimat, lalu batas kata + "…". Hasil ≤ $max karakter.
 */
function autentik_clip( $text, $max ) {
	$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' ) ) ) );
	if ( mb_strlen( $text ) <= $max ) {
		return $text;
	}
	if ( preg_match( '/^(.*[.!?])\s/su', mb_substr( $text, 0, $max + 1 ), $m ) && mb_strlen( $m[1] ) >= $max * 0.6 ) {
		return $m[1];
	}
	$cut = mb_substr( $text, 0, $max - 1 );
	if ( preg_match( '/^(.*)\s/su', $cut, $m ) && mb_strlen( $m[1] ) > $max * 0.6 ) {
		$cut = $m[1];
	}
	return rtrim( $cut, " ,;:–—-·|(" ) . '…';
}

/**
 * Jabatan yang aman ditampilkan: label "Advokat" hanya untuk anggota berstatus advokat (qa/34 Tahap 0.5).
 */
function autentik_tim_role( $id ) {
	$role = trim( (string) autentik_field( 'jabatan', $id ) );
	$adv  = function_exists( 'autentik_is_advokat' ) ? autentik_is_advokat( $id ) : null;
	if ( $role && false === $adv && false !== stripos( $role, 'advokat' ) ) {
		$role = '';
	}
	return $role;
}

/**
 * Deskripsi otomatis profil tim: "Nama, gelar — jabatan di Autentik Analitika, Medan." (+ bio bila ada).
 */
function autentik_tim_desc( $id ) {
	$name  = autentik_plain_title( $id );
	$gelar = trim( (string) autentik_field( 'gelar', $id ) );
	$who   = $gelar ? $name . ', ' . $gelar : $name;
	if ( 'notaris_mitra' === (string) autentik_field( 'status_profesi', $id ) ) {
		$d = $who . ' — mitra kerja Law Firm Autentik Analitika, Medan.';
	} else {
		$role = autentik_tim_role( $id );
		if ( ! $role ) {
			$role = ( function_exists( 'autentik_is_advokat' ) && autentik_is_advokat( $id ) ) ? 'Advokat' : 'Anggota tim hukum';
		}
		$d = $who . ' — ' . $role . ' pada Law Firm Autentik Analitika, Medan.';
	}
	$bio = trim( wp_strip_all_tags( (string) autentik_field( 'bio', $id ) ) );
	return $bio ? $d . ' ' . $bio : $d;
}

function autentik_org_schema( $full = true ) {
	$org = array(
		'@type' => array( 'LegalService', 'LocalBusiness' ),
		'@id'   => autentik_org_id(),
		'name'  => autentik_opt( 'firm' ),
		'url'   => home_url( '/' ),
	);
	if ( ! $full ) {
		return $org;
	}
	$logo = get_theme_mod( 'custom_logo' ) ? wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' ) : autentik_img( 'logo.png' );
	$org += array(
		'alternateName' => 'Autentik Analitika',
		'slogan'        => autentik_slogan(),
		'description'   => autentik_opt( 'about_text' ),
		'logo'          => $logo,
		'image'         => $logo,
		'telephone'     => autentik_tel_intl( autentik_opt( 'phone' ) ),
		'email'         => autentik_opt( 'email' ),
		'foundingDate'  => autentik_opt( 'founded' ),
		'priceRange'    => '$$',
		'address'       => array_filter(
			array(
				'@type'           => 'PostalAddress',
				'streetAddress'   => autentik_opt( 'street' ),
				'addressLocality' => trim( str_replace( 'Kota', '', autentik_opt( 'city' ) ) ),
				'addressRegion'   => autentik_opt( 'region' ),
				'postalCode'      => autentik_opt( 'postal' ),
				'addressCountry'  => 'ID',
			)
		),
		'areaServed'    => array(
			array( '@type' => 'City', 'name' => 'Medan' ),
			array( '@type' => 'State', 'name' => 'Sumatera Utara' ),
			array( '@type' => 'Country', 'name' => 'Indonesia' ),
		),
		'hasMap'        => autentik_opt( 'maps' ),
		'identifier'    => array(
			array( '@type' => 'PropertyValue', 'name' => 'Nomor Pendaftaran Kementerian Hukum RI', 'value' => autentik_opt( 'sk' ) ),
			array( '@type' => 'PropertyValue', 'name' => 'NIB', 'value' => autentik_opt( 'nib' ) ),
		),
	);
	// Kode pos & koordinat hanya dari data kantor (Customizer); tidak pernah dikarang. Kosong = tidak dicetak.
	if ( autentik_opt( 'lat' ) && autentik_opt( 'lng' ) ) {
		$org['geo'] = array( '@type' => 'GeoCoordinates', 'latitude' => autentik_opt( 'lat' ), 'longitude' => autentik_opt( 'lng' ) );
	}
	$rule = explode( '|', (string) autentik_opt( 'hours_rule' ) );
	if ( 2 === count( $rule ) && preg_match( '/^(\d)-(\d)$/', $rule[0], $d ) && preg_match( '/^(\d\d:\d\d)-(\d\d:\d\d)$/', $rule[1], $t ) ) {
		$names = array( 1 => 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' );
		$org['openingHoursSpecification'] = array(
			'@type'     => 'OpeningHoursSpecification',
			'dayOfWeek' => array_values( array_intersect_key( $names, array_flip( range( (int) $d[1], (int) $d[2] ) ) ) ),
			'opens'     => $t[1],
			'closes'    => $t[2],
		);
	}
	$same = array_values( array_filter( array( autentik_opt( 'facebook' ), autentik_opt( 'tiktok' ), autentik_opt( 'instagram' ), autentik_opt( 'linkedin' ) ) ) );
	if ( $same ) {
		$org['sameAs'] = $same;
	}
	$offers = array();
	foreach ( autentik_layanan() as $p ) {
		$offers[] = array( '@type' => 'Offer', 'itemOffered' => array( '@type' => 'Service', 'name' => autentik_plain_title( $p ), 'url' => get_permalink( $p ) ) );
	}
	if ( $offers ) {
		$org['hasOfferCatalog'] = array( '@type' => 'OfferCatalog', 'name' => 'Layanan Hukum', 'itemListElement' => $offers );
	}
	return $org;
}

/**
 * Cetak semua schema di footer (setelah template mengisi breadcrumb & FAQ).
 */
/**
 * Penulis artikel untuk schema: anggota tim (bila diisi) atau tim firma.
 */
function autentik_article_author() {
	list( $by, $rev ) = autentik_post_people( get_the_ID() );
	if ( $by ) {
		return array( '@type' => 'Person', 'name' => autentik_plain_title( $by ), 'url' => get_permalink( $by ) );
	}
	return array( '@type' => 'Organization', 'name' => autentik_opt( 'firm' ), 'url' => home_url( '/' ) );
}

function autentik_schema() {
	$graph = array();

	if ( is_front_page() || is_page( 'kontak' ) || is_page( 'tentang-kami' ) ) {
		$graph[] = autentik_org_schema();
	}

	if ( is_singular( 'layanan' ) ) {
		$id      = get_the_ID();
		$items   = array();
		foreach ( autentik_rows( 'lingkup', array( 'teks', 'teks_en' ), $id ) as $r ) {
			$items[] = array( '@type' => 'Offer', 'itemOffered' => array( '@type' => 'Service', 'name' => $r['teks'] ) );
		}
		$graph[] = array(
			'@type'           => 'Service',
			'@id'             => get_permalink() . '#layanan',
			'name'            => autentik_plain_title(),
			'serviceType'     => autentik_plain_title(),
			'description'     => wp_strip_all_tags( (string) autentik_field( 'jawaban_singkat', $id ) ),
			'url'             => get_permalink(),
			'provider'        => autentik_org_schema( false ),
			'areaServed'      => array( array( '@type' => 'City', 'name' => 'Medan' ), array( '@type' => 'State', 'name' => 'Sumatera Utara' ) ),
			'hasOfferCatalog' => array( '@type' => 'OfferCatalog', 'name' => autentik_plain_title(), 'itemListElement' => $items ),
		);
	}

	if ( is_page( 'tim' ) ) {
		$people = array();
		$tim    = function_exists( 'autentik_tim_publik' ) ? autentik_tim_publik() : get_posts( array( 'post_type' => 'tim', 'numberposts' => 30, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
		foreach ( $tim as $i => $p ) {
			$person = array_filter(
				array(
					'@type'           => 'Person',
					'@id'             => get_permalink( $p ) . '#orang',
					'name'            => autentik_plain_title( $p ),
					'url'             => get_permalink( $p ),
					'honorificSuffix' => (string) autentik_field( 'gelar', $p->ID ),
					'jobTitle'        => autentik_tim_role( $p->ID ),
					'knowsAbout'      => (string) autentik_field( 'keahlian', $p->ID ),
					'worksFor'        => autentik_org_schema( false ),
				)
			);
			$people[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'item' => $person );
		}
		if ( $people ) {
			$graph[] = array( '@type' => 'ItemList', 'name' => 'Tim Hukum ' . autentik_opt( 'firm' ), 'numberOfItems' => count( $people ), 'itemListElement' => $people );
		}
	}

	if ( is_singular( 'tim' ) ) {
		$id     = get_queried_object_id();
		$person = array(
			'@type'       => 'Person',
			'@id'         => get_permalink( $id ) . '#orang',
			'name'        => autentik_plain_title( $id ),
			'url'         => get_permalink( $id ),
			'description' => autentik_tim_desc( $id ),
		);
		// Notaris mitra tidak dinyatakan sebagai anggota firma (qa/34 Tahap 0.5).
		if ( 'notaris_mitra' !== (string) autentik_field( 'status_profesi', $id ) ) {
			$person['worksFor'] = autentik_org_schema( false );
		}
		foreach ( array( 'honorificSuffix' => 'gelar', 'email' => 'email' ) as $k => $f ) {
			if ( autentik_field( $f, $id ) ) {
				$person[ $k ] = wp_strip_all_tags( (string) autentik_field( $f, $id ) );
			}
		}
		if ( autentik_tim_role( $id ) ) {
			$person['jobTitle'] = autentik_tim_role( $id );
		}
		$know = array_map( 'autentik_plain_title', autentik_layanan_for_tim( $id ) );
		if ( $know ) {
			$person['knowsAbout'] = $know;
		}
		$alumni = autentik_lines( autentik_field( 'pendidikan', $id ) );
		if ( $alumni ) {
			$person['alumniOf'] = array_map( function ( $l ) { return array( '@type' => 'EducationalOrganization', 'name' => $l ); }, $alumni );
		}
		if ( autentik_field( 'bahasa', $id ) ) {
			$person['knowsLanguage'] = array_map( 'trim', explode( ',', (string) autentik_field( 'bahasa', $id ) ) );
		}
		if ( has_post_thumbnail( $id ) ) {
			$person['image'] = get_the_post_thumbnail_url( $id, 'autentik-portrait' );
		}
		$graph[] = $person;
	}

	if ( is_singular( 'post' ) && ! autentik_has_seo_plugin() ) {
		$graph[] = array(
			'@type'            => 'Article',
			'headline'         => autentik_plain_title(),
			'description'      => get_the_excerpt(),
			'datePublished'    => get_the_date( 'c' ),
			'dateModified'     => get_the_modified_date( 'c' ),
			'author'           => autentik_article_author(),
			'publisher'        => autentik_org_schema( false ),
			'mainEntityOfPage' => get_permalink(),
			'image'            => autentik_post_img( get_post(), 'autentik-wide' ), // sama dengan gambar yang tampil di artikel
			'inLanguage'       => 'id-ID',
		);
	}

	if ( ! empty( $GLOBALS['autentik_faq'] ) ) {
		$qa = array();
		foreach ( $GLOBALS['autentik_faq'] as $q ) {
			$tanya = isset( $q['tanya'] ) ? $q['tanya'] : $q[0];
			$jawab = isset( $q['jawab'] ) ? $q['jawab'] : $q[1];
			$qa[]  = array( '@type' => 'Question', 'name' => $tanya, 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $jawab ) );
		}
		$graph[] = array( '@type' => 'FAQPage', 'mainEntity' => $qa );
	}

	if ( ! empty( $GLOBALS['autentik_crumbs'] ) ) {
		$list = array( array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Beranda', 'item' => home_url( '/' ) ) );
		$pos  = 2;
		foreach ( $GLOBALS['autentik_crumbs'] as $c ) {
			$el = array( '@type' => 'ListItem', 'position' => $pos++, 'name' => $c[0] );
			$el['item'] = ! empty( $c[1] ) ? $c[1] : ( is_singular() ? get_permalink() : '' );
			if ( '' === $el['item'] ) {
				unset( $el['item'] );
			}
			$list[] = $el;
		}
		$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => $list );
	}

	if ( $graph ) {
		echo "\n<script type=\"application/ld+json\">" . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) . "</script>\n"; // phpcs:ignore
	}
}
add_action( 'wp_footer', 'autentik_schema', 5 );

/**
 * Meta cadangan bila belum ada plugin SEO.
 */
function autentik_rm_meta( $id, $key ) {
	$v = $id ? (string) get_post_meta( $id, $key, true ) : '';
	return ( '' !== $v && false === strpos( $v, '%' ) ) ? $v : ''; // abaikan variabel Rank Math (%title% dsb.)
}

/**
 * Deskripsi halaman (belum dipotong): meta Rank Math → ringkasan/konten → cadangan per jenis halaman.
 */
function autentik_meta_desc() {
	$desc = '';
	if ( is_singular() ) {
		$id   = get_queried_object_id();
		$desc = autentik_rm_meta( $id, 'rank_math_description' );
		if ( ! $desc && is_singular( 'tim' ) ) {
			$desc = autentik_tim_desc( $id );
		}
		if ( ! $desc ) {
			$desc = has_excerpt( $id ) ? get_the_excerpt( $id ) : wp_trim_words( wp_strip_all_tags( strip_shortcodes( (string) get_post_field( 'post_content', $id ) ) ), 28, '…' );
		}
	} elseif ( is_home() ) {
		$pid  = (int) get_option( 'page_for_posts' );
		$desc = autentik_rm_meta( $pid, 'rank_math_description' );
		if ( ! $desc && $pid && has_excerpt( $pid ) ) {
			$desc = get_the_excerpt( $pid );
		}
		if ( ! $desc ) {
			$desc = 'Artikel dan panduan hukum dari Law Firm Autentik Analitika, Medan, mengenai kontrak, perizinan berusaha, pertanahan, dan badan usaha.';
		}
	} elseif ( is_category() || is_tag() ) {
		$desc = wp_strip_all_tags( (string) term_description() );
		if ( ! $desc ) {
			$desc = 'Artikel ' . single_term_title( '', false ) . ' dari tim hukum Law Firm Autentik Analitika, Medan, yang menjelaskan dasar hukum dan langkah yang dapat Anda tempuh.';
		}
	}
	if ( ! $desc && is_front_page() ) {
		$desc = autentik_opt( 'hero_text' );
	}
	return trim( wp_strip_all_tags( html_entity_decode( (string) $desc, ENT_QUOTES, 'UTF-8' ) ) );
}

/**
 * URL kanonik halaman ini (singular, beranda, daftar artikel, kategori/tag; termasuk /page/N/).
 */
function autentik_canonical_url() {
	if ( is_front_page() ) {
		return home_url( '/' );
	}
	if ( is_singular() ) {
		return (string) wp_get_canonical_url( get_queried_object_id() );
	}
	$base = '';
	if ( is_home() ) {
		$pid  = (int) get_option( 'page_for_posts' );
		$base = $pid ? get_permalink( $pid ) : home_url( '/' );
	} elseif ( is_category() || is_tag() ) {
		$l    = get_term_link( get_queried_object() );
		$base = is_wp_error( $l ) ? '' : $l;
	}
	$paged = max( 1, (int) get_query_var( 'paged' ) );
	if ( $base && $paged > 1 ) {
		$base = get_option( 'permalink_structure' ) ? user_trailingslashit( trailingslashit( $base ) . 'page/' . $paged, 'paged' ) : add_query_arg( 'paged', $paged, $base );
	}
	return (string) $base;
}

/**
 * Gambar lampiran yang layak untuk kartu share besar: JPEG/PNG, minimal 1200×630.
 *
 * @return array|null [url, w, h, mime]
 */
function autentik_og_attachment( $att ) {
	$att  = (int) $att;
	$mime = $att ? (string) get_post_mime_type( $att ) : '';
	if ( ! in_array( $mime, array( 'image/jpeg', 'image/png' ), true ) ) {
		return null;
	}
	foreach ( array( 'autentik-wide', 'full' ) as $size ) {
		$src = wp_get_attachment_image_src( $att, $size );
		if ( $src && $src[1] >= 1200 && $src[2] >= 630 && $src[1] >= $src[2] ) {
			return array( $src[0], (int) $src[1], (int) $src[2], $mime );
		}
	}
	return null;
}

/**
 * Gambar merek per halaman di assets/img/og/ (disalin dari _brand/og/, 1200×630 JPEG).
 */
function autentik_og_file( $slug ) {
	$rel = 'og/og-' . $slug . '.jpg';
	return ( $slug && file_exists( AUTENTIK_DIR . '/assets/img/' . $rel ) ) ? $rel : '';
}

/**
 * Pilih gambar share: gambar Facebook Rank Math (bila tersimpan) → gambar merek per halaman/bidang →
 * gambar unggulan artikel 1200×630 → og.jpg.
 *
 * @return array [url, w, h, mime]
 */
function autentik_og_image() {
	$id = is_singular() ? get_queried_object_id() : 0;
	if ( $id ) {
		$rm = autentik_og_attachment( get_post_meta( $id, 'rank_math_facebook_image_id', true ) );
		if ( $rm ) {
			return $rm;
		}
	}
	$slug = '';
	$lay  = autentik_cat_to_layanan();
	if ( is_front_page() ) {
		$slug = 'beranda';
	} elseif ( is_page_template( 'page-templates/landing.php' ) ) {
		$slug = 'konsultasi';
	} elseif ( is_home() || is_page( 'artikel' ) ) {
		$slug = 'publikasi';
	} elseif ( is_page() ) {
		$slug = get_post_field( 'post_name', $id );
	} elseif ( is_singular( 'layanan' ) ) {
		$slug = get_post_field( 'post_name', $id );
	} elseif ( is_singular( 'tim' ) ) {
		$own = has_post_thumbnail( $id ) ? autentik_og_attachment( get_post_thumbnail_id( $id ) ) : null; // potret lanskap ≥1200×630 saja
		if ( $own ) {
			return $own;
		}
		$slug = 'tim';
	} elseif ( is_singular( 'post' ) ) {
		$own = has_post_thumbnail( $id ) ? autentik_og_attachment( get_post_thumbnail_id( $id ) ) : null;
		if ( $own ) {
			return $own;
		}
		$cat  = get_the_category( $id );
		$slug = ( $cat && isset( $lay[ $cat[0]->slug ] ) ) ? $lay[ $cat[0]->slug ] : 'publikasi';
	} elseif ( is_category() ) {
		$term = get_queried_object();
		$slug = ( $term && isset( $lay[ $term->slug ] ) ) ? $lay[ $term->slug ] : 'publikasi';
	}
	$rel = autentik_og_file( $slug );
	if ( ! $rel ) {
		$rel = 'og.jpg';
	}
	$ver = @filemtime( AUTENTIK_DIR . '/assets/img/' . $rel ); // phpcs:ignore -- cache WA/FB menempel pada URL gambar
	return array( autentik_img( $rel ) . ( $ver ? '?v=' . $ver : '' ), 1200, 630, 'image/jpeg' );
}

/**
 * Meta cadangan bila belum ada plugin SEO: description, canonical arsip, Open Graph lengkap, Twitter.
 * Bila Rank Math/Yoast/AIOSEO aktif, fungsi ini hanya mencetak theme-color (plugin yang mengurus sisanya).
 */
function autentik_meta_fallback() {
	// Warna bilah alamat mengikuti header: putih di situs, navy gelap di landing /konsultasi/.
	echo '<meta name="theme-color" content="' . ( is_page_template( 'page-templates/landing.php' ) ? '#061C3B' : '#FFFFFF' ) . '">' . "\n";
	if ( autentik_has_seo_plugin() ) {
		return;
	}
	$e    = function ( $prop, $val, $attr = 'property' ) {
		if ( '' !== (string) $val ) {
			echo '<meta ' . $attr . '="' . esc_attr( $prop ) . '" content="' . esc_attr( $val ) . '">' . "\n"; // phpcs:ignore
		}
	};
	$desc = autentik_meta_desc();
	$url  = autentik_canonical_url();
	if ( $desc && ! is_404() && ! is_search() ) {
		$e( 'description', autentik_clip( $desc, 160 ), 'name' );
	}
	// WordPress hanya mencetak canonical untuk singular; tambahkan untuk daftar artikel & kategori/tag.
	if ( $url && ( ( is_home() && ! is_front_page() ) || is_category() || is_tag() ) ) {
		echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
	}

	$title = html_entity_decode( wp_get_document_title(), ENT_QUOTES, 'UTF-8' );
	$type  = 'website';
	if ( is_singular( 'post' ) ) {
		$type = 'article';
	} elseif ( is_singular( 'tim' ) ) {
		$type = 'profile';
	}
	$img = autentik_og_image();

	$e( 'og:site_name', autentik_opt( 'firm' ) );
	$e( 'og:locale', 'id_ID' );
	$e( 'og:type', $type );
	$e( 'og:title', $title );
	$e( 'og:description', $desc ? autentik_clip( $desc, 90 ) : '' ); // WA/FB hanya menampilkan ±90 karakter
	$e( 'og:url', $url );
	$e( 'og:image', $img[0] );
	$e( 'og:image:type', $img[3] );
	$e( 'og:image:width', $img[1] );
	$e( 'og:image:height', $img[2] );
	$e( 'og:image:alt', $title );

	if ( 'article' === $type ) {
		$id = get_queried_object_id();
		$e( 'article:published_time', get_the_date( 'c', $id ) );
		$e( 'article:modified_time', get_the_modified_date( 'c', $id ) );
		list( $by ) = autentik_post_people( $id );
		$e( 'article:author', $by ? autentik_plain_title( $by ) : autentik_opt( 'firm' ) );
		$cat = get_the_category( $id );
		if ( $cat ) {
			$e( 'article:section', $cat[0]->name );
		}
	}
	$e( 'twitter:card', 'summary_large_image', 'name' );
}
add_action( 'wp_head', 'autentik_meta_fallback', 2 );

/**
 * Pakai judul SEO dari Rank Math (tersimpan di impor) walau Rank Math belum aktif.
 * Akhiran nama firma diseragamkan: "| Autentik" → "| Autentik Analitika" (qa/32 P2-3).
 */
function autentik_title_fallback( $title ) {
	if ( autentik_has_seo_plugin() ) {
		return $title;
	}
	$id = 0;
	if ( is_singular() ) {
		$id = get_queried_object_id();
	} elseif ( is_home() && ! is_front_page() && ! is_paged() ) {
		$id = (int) get_option( 'page_for_posts' );
	}
	$t = autentik_rm_meta( $id, 'rank_math_title' );
	if ( ! $t ) {
		return $title;
	}
	return preg_replace( '/\s*[|–—-]\s*Autentik\s*$/u', ' | Autentik Analitika', $t );
}
add_filter( 'pre_get_document_title', 'autentik_title_fallback' );

/**
 * GEO: /llms.txt — ringkasan mesin-terbaca untuk ChatGPT, Gemini, Perplexity, Claude.
 */
function autentik_llms_rewrite() {
	add_rewrite_rule( '^llms\.txt$', 'index.php?autentik_llms=1', 'top' );
}
add_action( 'init', 'autentik_llms_rewrite' );
add_filter( 'query_vars', function ( $v ) { $v[] = 'autentik_llms'; return $v; } );
add_action( 'after_switch_theme', function () { autentik_llms_rewrite(); flush_rewrite_rules(); } );

function autentik_llms_render() {
	if ( ! get_query_var( 'autentik_llms' ) ) {
		return;
	}
	header( 'Content-Type: text/plain; charset=utf-8' );
	$l   = array();
	$l[] = '# ' . autentik_opt( 'firm' );
	$l[] = '';
	$l[] = '> ' . autentik_opt( 'about_text' );
	$l[] = '';
	$l[] = '- Alamat: ' . autentik_address();
	$l[] = '- Telepon/WhatsApp: ' . autentik_opt( 'phone' ) . ' (' . autentik_tel_intl( autentik_opt( 'phone' ) ) . ')';
	$l[] = '- Email: ' . autentik_opt( 'email' );
	$l[] = '- Jam kerja: ' . autentik_opt( 'hours' );
	$l[] = '- Legalitas: terdaftar di Kementerian Hukum RI dengan Nomor ' . autentik_opt( 'sk' ) . '; NIB ' . autentik_opt( 'nib' );
	$l[] = '- Wilayah layanan: Medan, Sumatera Utara, dan seluruh Indonesia';
	$l[] = '';
	$l[] = '## Layanan';
	foreach ( autentik_layanan() as $p ) {
		$l[] = '- [' . autentik_plain_title( $p ) . '](' . get_permalink( $p ) . '): ' . wp_strip_all_tags( (string) autentik_field( 'jawaban_singkat', $p->ID ) );
	}
	$l[] = '';
	$tim = function_exists( 'autentik_tim_publik' ) ? autentik_tim_publik() : get_posts( array( 'post_type' => 'tim', 'numberposts' => 30, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $tim ) {
		$l[] = '## Tim hukum';
		foreach ( $tim as $p ) {
			$gelar = trim( (string) autentik_field( 'gelar', $p->ID ) );
			$role  = autentik_tim_role( $p->ID );
			$l[]   = '- [' . autentik_plain_title( $p ) . ( $gelar ? ', ' . $gelar : '' ) . '](' . get_permalink( $p ) . ')' . ( $role ? ': ' . $role : '' );
		}
		$l[] = '';
	}
	$l[] = '## Halaman utama';
	foreach ( array( 'tentang-kami', 'tim', 'klien', 'kontak', 'kebijakan-privasi' ) as $slug ) {
		$pg = get_page_by_path( $slug );
		if ( $pg ) {
			$l[] = '- [' . autentik_plain_title( $pg ) . '](' . get_permalink( $pg ) . ')';
		}
	}
	$posts = get_posts( array( 'numberposts' => 30 ) );
	if ( $posts ) {
		$l[] = '';
		$l[] = '## Artikel';
		foreach ( $posts as $p ) {
			$l[] = '- [' . autentik_plain_title( $p ) . '](' . get_permalink( $p ) . '): ' . wp_strip_all_tags( get_the_excerpt( $p ) );
		}
	}
	echo implode( "\n", $l ) . "\n"; // phpcs:ignore
	exit;
}
add_action( 'template_redirect', 'autentik_llms_render', 1 );

/**
 * GEO: robots.txt mengizinkan crawler AI & menunjuk sitemap.
 */
function autentik_robots( $out, $public ) {
	if ( ! $public ) {
		return $out;
	}
	$out .= "\n# Crawler AI diizinkan (GEO)\n";
	foreach ( array( 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-SearchBot', 'PerplexityBot', 'Google-Extended', 'Applebot-Extended', 'Bingbot' ) as $bot ) {
		$out .= "User-agent: {$bot}\n";
	}
	// Satu grup: bot di atas tetap tidak masuk wp-admin.
	$out .= "Disallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\nAllow: /\n";
	// Baris "Sitemap:" sudah ditambahkan WordPress / Rank Math — jangan digandakan.
	return $out;
}
add_filter( 'robots_txt', 'autentik_robots', 20, 2 );

/**
 * Landing page iklan (/konsultasi/) dan hasil pencarian: noindex,follow; keluarkan dari sitemap.
 * Sitemap pengguna ditutup agar username login tidak terbuka.
 */
function autentik_noindex_landing( $robots ) {
	// Arsip tanggal (/2026/) dan kategori bawaan "Uncategorized" = konten tipis/duplikat daftar artikel (qa/31 P2-9).
	if ( is_page_template( 'page-templates/landing.php' ) || is_search() || is_date() || is_category( 'uncategorized' ) ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'autentik_noindex_landing' );

/**
 * vCard (/tim/nama/?vcard=1) tidak diindeks (qa/31 P2-10). Dijalankan sebelum autentik_vcard() (prioritas 10).
 */
add_action( 'template_redirect', function () {
	if ( isset( $_GET['vcard'] ) && is_singular( 'tim' ) && ! headers_sent() ) { // phpcs:ignore WordPress.Security.NonceVerification
		header( 'X-Robots-Tag: noindex, nofollow', true );
	}
}, 5 );

add_filter( 'wp_sitemaps_add_provider', function ( $provider, $name ) {
	return 'users' === $name ? false : $provider;
}, 10, 2 );

add_filter( 'wp_sitemaps_posts_query_args', function ( $args, $post_type ) {
	if ( 'page' === $post_type ) {
		$lp = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/landing.php', 'fields' => 'ids' ) );
		$args['post__not_in'] = array_merge( (array) ( $args['post__not_in'] ?? array() ), wp_list_pluck( $lp, 'ID' ) );
	}
	return $args;
}, 10, 2 );
