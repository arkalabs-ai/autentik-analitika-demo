<?php
/**
 * Fitur "firma hukum profesional": relasi advokat ↔ bidang praktik, penulis/peninjau artikel,
 * kartu kontak vCard, dan data kredensial. Semua bagian otomatis tersembunyi bila datanya kosong.
 *
 * @package Autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Daftar ID dari field relasi/post object (SCF atau meta mentah).
 *
 * @return int[]
 */
function autentik_ids( $name, $post_id ) {
	$v = function_exists( 'get_field' ) ? get_field( $name, $post_id, false ) : get_post_meta( $post_id, $name, true );
	if ( '' === $v || null === $v || false === $v ) {
		return array();
	}
	$v = is_array( $v ) ? $v : array( $v );
	return array_values( array_filter( array_map( function ( $x ) { return (int) ( is_object( $x ) ? $x->ID : $x ); }, $v ) ) );
}

/**
 * Teks multi-baris → array baris tidak kosong.
 *
 * @return string[]
 */
function autentik_lines( $text ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $text ) ) ) );
}

/**
 * Anggota tim (urut menu_order).
 *
 * @return WP_Post[]
 */
function autentik_tim_all() {
	static $tim = null;
	if ( null === $tim ) {
		$tim = get_posts( array( 'post_type' => 'tim', 'numberposts' => 60, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	}
	return $tim;
}

/**
 * Advokat yang menangani satu bidang praktik.
 *
 * @return WP_Post[]
 */
function autentik_tim_for_layanan( $layanan_id ) {
	return array_values( array_filter( autentik_tim_all(), function ( $t ) use ( $layanan_id ) {
		return in_array( (int) $layanan_id, autentik_ids( 'bidang', $t->ID ), true );
	} ) );
}

/**
 * Bidang praktik (WP_Post) milik satu anggota tim.
 *
 * @return WP_Post[]
 */
function autentik_layanan_for_tim( $tim_id ) {
	$ids = autentik_ids( 'bidang', $tim_id );
	return $ids ? array_values( array_filter( array_map( 'get_post', $ids ), function ( $p ) { return $p && 'publish' === $p->post_status; } ) ) : array();
}

/**
 * Artikel yang ditulis atau ditinjau seorang anggota tim.
 *
 * @return WP_Post[]
 */
function autentik_posts_by_tim( $tim_id, $n = 6 ) {
	return get_posts(
		array(
			'numberposts' => $n,
			'meta_query'  => array(
				'relation' => 'OR',
				array( 'key' => 'penulis_tim', 'value' => (string) $tim_id ),
				array( 'key' => 'peninjau_tim', 'value' => (string) $tim_id ),
			),
		)
	);
}

/**
 * Penulis & peninjau artikel (anggota tim) — null bila belum diisi.
 *
 * @return array{0:?WP_Post,1:?WP_Post}
 */
function autentik_post_people( $post_id ) {
	$get = function ( $key ) use ( $post_id ) {
		$ids = autentik_ids( $key, $post_id );
		$p   = $ids ? get_post( $ids[0] ) : null;
		return ( $p && 'tim' === $p->post_type && 'publish' === $p->post_status ) ? $p : null;
	};
	return array( $get( 'penulis_tim' ), $get( 'peninjau_tim' ) );
}

/**
 * Foto kecil / inisial seorang anggota tim.
 */
function autentik_avatar( $p, $size = 'thumbnail', $class = 'av' ) {
	if ( has_post_thumbnail( $p ) ) {
		return get_the_post_thumbnail( $p, $size, array( 'alt' => '', 'class' => $class, 'loading' => 'lazy' ) );
	}
	return '<span class="' . esc_attr( $class ) . ' ini" aria-hidden="true">' . esc_html( autentik_initials( get_the_title( $p ) ) ) . '</span>';
}

/**
 * Kartu kontak vCard: /tim/nama/?vcard=1
 */
function autentik_vcard() {
	if ( ! is_singular( 'tim' ) || ! isset( $_GET['vcard'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$id    = get_queried_object_id();
	$esc   = function ( $s ) { return str_replace( array( '\\', ',', ';', "\n" ), array( '\\\\', '\\,', '\\;', '\\n' ), (string) $s ); };
	$name  = autentik_plain_title( $id );
	$email = (string) autentik_field( 'email', $id );
	$lines = array(
		'BEGIN:VCARD',
		'VERSION:3.0',
		'FN:' . $esc( trim( $name . ', ' . autentik_field( 'gelar', $id ), ', ' ) ),
		'N:' . $esc( $name ) . ';;;;',
		'ORG:' . $esc( autentik_opt( 'firm' ) ),
	);
	if ( autentik_field( 'jabatan', $id ) ) {
		$lines[] = 'TITLE:' . $esc( autentik_field( 'jabatan', $id ) );
	}
	$lines[] = 'TEL;TYPE=WORK,VOICE:' . $esc( autentik_opt( 'phone' ) );
	$lines[] = 'EMAIL;TYPE=WORK:' . $esc( $email ? $email : autentik_opt( 'email' ) );
	$lines[] = 'ADR;TYPE=WORK:;;' . $esc( autentik_opt( 'street' ) ) . ';' . $esc( autentik_opt( 'city' ) ) . ';' . $esc( autentik_opt( 'region' ) ) . ';' . $esc( autentik_opt( 'postal' ) ) . ';Indonesia';
	$lines[] = 'URL:' . get_permalink( $id );
	$lines[] = 'END:VCARD';
	nocache_headers();
	header( 'Content-Type: text/vcard; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="' . sanitize_title( $name ) . '.vcf"' );
	echo implode( "\r\n", $lines ) . "\r\n"; // phpcs:ignore
	exit;
}
add_action( 'template_redirect', 'autentik_vcard' );

/**
 * Keamanan: username login tidak dibuka ke publik (endpoint users REST & arsip penulis).
 */
function autentik_hide_users_endpoint( $endpoints ) {
	if ( ! is_user_logged_in() ) {
		unset( $endpoints['/wp/v2/users'], $endpoints['/wp/v2/users/(?P<id>[\d]+)'] );
		unset( $endpoints['/wp/v2/media'], $endpoints['/wp/v2/media/(?P<id>[\d]+)'] );
	}
	return $endpoints;
}
add_filter( 'rest_endpoints', 'autentik_hide_users_endpoint' );

function autentik_no_author_archive() {
	if ( is_author() || ( isset( $_GET['author'] ) && ! is_admin() ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$blog = (int) get_option( 'page_for_posts' );
		wp_safe_redirect( $blog ? get_permalink( $blog ) : home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'autentik_no_author_archive', 1 );

/**
 * Admin: petunjuk di layar edit Bidang Praktik (isi halaman berasal dari kolom di bawah editor).
 */
function autentik_layanan_notice( $post ) {
	if ( 'layanan' !== $post->post_type ) {
		return;
	}
	echo '<div class="notice notice-info inline" style="margin:12px 0"><p><strong>Cara mengubah halaman layanan:</strong> teks di situs diambil dari kolom <em>Detail Layanan</em> di bawah editor (jawaban singkat, paragraf, lingkup pekerjaan, dokumen, perkiraan waktu, tanya jawab, dan pengalaman). Editor utama hanya dipakai bila kolom "Lingkup pekerjaan" kosong. Anggota tim yang menangani layanan ini diatur melalui menu <em>Tim Hukum</em>, pada kolom "Layanan yang ditangani".</p></div>';
}
add_action( 'edit_form_after_title', 'autentik_layanan_notice' );

/**
 * Keamanan: XML-RPC mati; nama penulis tidak dibuka lewat oEmbed.
 */
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'oembed_response_data', function ( $data ) {
	unset( $data['author_name'], $data['author_url'] );
	return $data;
} );

/**
 * UU PDP: Pesan Masuk yang lebih tua dari 12 bulan dihapus otomatis (sesuai Kebijakan Privasi).
 */
function autentik_hapus_pesan_lama() {
	$lama = get_posts( array( 'post_type' => 'pesan', 'post_status' => 'any', 'numberposts' => 200, 'fields' => 'ids', 'date_query' => array( array( 'before' => '12 months ago' ) ) ) );
	foreach ( $lama as $id ) {
		wp_delete_post( $id, true );
	}
}
add_action( 'autentik_hapus_pesan_lama', 'autentik_hapus_pesan_lama' );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'autentik_hapus_pesan_lama' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'autentik_hapus_pesan_lama' );
	}
} );

/**
 * Notaris mitra tidak ditampilkan sebagai anggota firma advokat: profilnya dialihkan ke halaman Tim.
 */
function autentik_alih_notaris_mitra() {
	if ( is_singular( 'tim' ) && 'notaris_mitra' === (string) autentik_field( 'status_profesi', get_queried_object_id() ) ) {
		wp_safe_redirect( home_url( '/tim/' ), 302 );
		exit;
	}
}
add_action( 'template_redirect', 'autentik_alih_notaris_mitra' );
