<?php
/**
 * Modul CMS Staf — dimuat oleh plugin "Autentik — Jenis Konten" (require_once). BUKAN plugin terpisah:
 * sengaja tanpa header "Plugin Name" agar tidak muncul sendiri di daftar Plugin (tombol Hapus-nya
 * akan menghapus seluruh folder jenis konten).
 *
 * Isi: templat & pola artikel, editor terbatas, kunci Terbitkan tanpa penulis/peninjau (+ penjaga server),
 * ringkasan otomatis dari "Jawaban singkat", kolom admin, Pesan Masuk, peran staf, kategori ↔ layanan,
 * gambar otomatis. Versi 0.2.0 (v21).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =====================================================================
 * 1. Templat bawaan artikel + pola "Artikel panduan hukum"
 * ===================================================================== */
function aac_templat_artikel() {
	$p = function ( $ph ) { return array( 'core/paragraph', array( 'placeholder' => $ph ) ); };
	$h = function ( $txt ) { return array( 'core/heading', array( 'level' => 2, 'content' => $txt ) ); };
	$l = function ( $ph, $ordered = false ) { return array( 'core/list', array( 'ordered' => $ordered ), array( array( 'core/list-item', array( 'placeholder' => $ph ) ) ) ); };
	return array(
		array(
			'core/paragraph',
			array(
				'placeholder' => 'JAWABAN SINGKAT: jawab pertanyaan pembaca langsung dalam 2–3 kalimat (40–60 kata). Otomatis tampil tebal dan menjadi ringkasan di kartu artikel & Google bila kotak Ringkasan dikosongkan.',
				'className'   => 'aa-jawaban',
			),
		),
		$p( 'Paragraf pembuka: situasi yang dihadapi pembaca dan mengapa topik ini penting.' ),
		$h( 'Dasar hukum' ),
		$l( 'Nama peraturan lengkap + nomor + tahun + pasal. Contoh: Pasal 37 PP No. 24 Tahun 1997 tentang Pendaftaran Tanah' ),
		$h( 'Langkah-langkah' ),
		$l( 'Langkah pertama (tekan Enter untuk langkah berikutnya)', true ),
		$h( 'Dokumen yang perlu disiapkan' ),
		$l( 'Nama dokumen (tekan Enter untuk dokumen berikutnya)' ),
		$h( 'Kesalahan yang sering terjadi' ),
		$p( 'Jelaskan 2–3 kesalahan umum dan akibatnya. Jangan menyebut nama klien atau perkara nyata.' ),
		array( 'core/quote', array(), array( $p( 'Kiat: satu kalimat ringkas yang paling berguna bagi pembaca.' ) ) ),
		$h( 'Pertanyaan yang sering diajukan' ),
		array( 'core/details', array( 'summary' => '' ), array( $p( 'Tulis jawaban di sini. Klik judul kotak di atas untuk mengetik pertanyaannya.' ) ) ),
		$p( 'Penutup: kapan pembaca sebaiknya berkonsultasi. Hindari janji hasil ("pasti menang") dan kata "terbaik".' ),
	);
}

function aac_init_editor() {
	// Templat: muncul otomatis saat klik "Tulis Artikel". Tidak dikunci; blok boleh dihapus/ditambah.
	$pt = get_post_type_object( 'post' );
	if ( $pt ) {
		$pt->template = aac_templat_artikel();
	}

	// Pola: bisa disisipkan kapan saja (tombol + › Pola › Autentik).
	register_block_pattern_category( 'autentik', array( 'label' => 'Autentik' ) );
	$ph = function ( $t ) { return '<!-- wp:paragraph {"placeholder":"' . esc_attr( $t ) . '"} --><p></p><!-- /wp:paragraph -->'; };
	$h2 = function ( $t ) { return '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html( $t ) . '</h2><!-- /wp:heading -->'; };
	register_block_pattern(
		'autentik/artikel-panduan-hukum',
		array(
			'title'       => 'Artikel panduan hukum',
			'description' => 'Kerangka lengkap: jawaban singkat, dasar hukum, langkah, dokumen, kesalahan umum, kiat, tanya jawab.',
			'categories'  => array( 'autentik' ),
			'postTypes'   => array( 'post' ),
			'content'     => implode(
				"\n",
				array(
					'<!-- wp:paragraph {"placeholder":"Jawaban singkat 40–60 kata yang langsung menjawab pertanyaan pembaca.","className":"aa-jawaban"} --><p class="aa-jawaban"></p><!-- /wp:paragraph -->',
					$ph( 'Paragraf pembuka.' ),
					$h2( 'Dasar hukum' ),
					'<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>Pasal … Undang-Undang No. … Tahun … tentang …</li><!-- /wp:list-item --></ul><!-- /wp:list -->',
					$h2( 'Langkah-langkah' ),
					'<!-- wp:list {"ordered":true} --><ol class="wp-block-list"><!-- wp:list-item --><li>Langkah pertama</li><!-- /wp:list-item --><!-- wp:list-item --><li>Langkah kedua</li><!-- /wp:list-item --></ol><!-- /wp:list -->',
					$h2( 'Dokumen yang perlu disiapkan' ),
					'<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>KTP pemohon</li><!-- /wp:list-item --></ul><!-- /wp:list -->',
					$h2( 'Kesalahan yang sering terjadi' ),
					$ph( 'Dua–tiga kesalahan umum dan akibatnya.' ),
					'<!-- wp:quote --><blockquote class="wp-block-quote"><!-- wp:paragraph --><p><strong>Kiat:</strong> …</p><!-- /wp:paragraph --></blockquote><!-- /wp:quote -->',
					$h2( 'Pertanyaan yang sering diajukan' ),
					'<!-- wp:details --><details class="wp-block-details"><summary>Pertanyaan?</summary><!-- wp:paragraph --><p>Jawaban.</p><!-- /wp:paragraph --></details><!-- /wp:details -->',
					$ph( 'Penutup: kapan sebaiknya berkonsultasi.' ),
				)
			),
		)
	);
}
add_action( 'init', 'aac_init_editor', 20 );

/**
 * Teks "Jawaban singkat" dari isi artikel: paragraf ber-kelas aa-jawaban, atau paragraf pertama yang berisi.
 */
function aac_jawaban_singkat( $content ) {
	$pertama = '';
	$cari    = function ( $blocks ) use ( &$cari, &$pertama ) {
		foreach ( $blocks as $b ) {
			if ( 'core/paragraph' === $b['blockName'] ) {
				$t = trim( wp_strip_all_tags( $b['innerHTML'] ) );
				if ( '' !== $t && false !== strpos( (string) ( $b['attrs']['className'] ?? '' ), 'aa-jawaban' ) ) {
					return $t;
				}
				if ( '' !== $t && '' === $pertama ) {
					$pertama = $t;
				}
			}
			if ( ! empty( $b['innerBlocks'] ) ) {
				$x = $cari( $b['innerBlocks'] );
				if ( $x ) {
					return $x;
				}
			}
		}
		return '';
	};
	$t = $cari( parse_blocks( (string) $content ) );
	return html_entity_decode( $t ? $t : $pertama, ENT_QUOTES, 'UTF-8' );
}

/**
 * Ringkasan (excerpt) otomatis dari "Jawaban singkat" bila kosong. Ringkasan yang dulu dibuat otomatis
 * ikut diperbarui saat Jawaban singkat diubah (ditandai hash di meta _aac_ringkasan_auto); ringkasan
 * yang diketik staf tidak pernah ditimpa.
 */
function aac_ringkasan_otomatis( $data, $postarr ) {
	if ( 'post' !== $data['post_type'] ) {
		return $data;
	}
	$id    = (int) ( $postarr['ID'] ?? 0 );
	$ex    = trim( wp_unslash( (string) $data['post_excerpt'] ) );
	$tanda = $id ? get_post_meta( $id, '_aac_ringkasan_auto', true ) : '';
	$norm  = function ( $t ) { return md5( trim( html_entity_decode( wp_strip_all_tags( $t ), ENT_QUOTES, 'UTF-8' ) ) ); }; // kses bisa mengubah & → &amp;
	if ( '' !== $ex && ( ! $tanda || $norm( $ex ) !== $tanda ) ) {
		return $data; // diisi manual
	}
	$t = aac_jawaban_singkat( wp_unslash( $data['post_content'] ) );
	if ( '' === $t ) {
		return $data;
	}
	$ex                   = wp_trim_words( $t, 60, '…' );
	$data['post_excerpt'] = wp_slash( $ex );
	$GLOBALS['aac_ringkasan_hash'] = $norm( $ex );
	return $data;
}
add_filter( 'wp_insert_post_data', 'aac_ringkasan_otomatis', 20, 2 );
add_action(
	'save_post_post',
	function ( $id ) {
		if ( ! empty( $GLOBALS['aac_ringkasan_hash'] ) && ! wp_is_post_revision( $id ) ) {
			update_post_meta( $id, '_aac_ringkasan_auto', $GLOBALS['aac_ringkasan_hash'] );
			unset( $GLOBALS['aac_ringkasan_hash'] );
		}
	}
);

/* =====================================================================
 * 2. Editor sederhana: blok terbatas, tanpa warna/ukuran bebas, tanpa pola bawaan WP
 * ===================================================================== */
add_action(
	'after_setup_theme',
	function () {
		remove_theme_support( 'core-block-patterns' );
		remove_theme_support( 'align-wide' ); // kolom artikel di situs 720 px: "Lebar" tidak berpengaruh, jangan ditawarkan
		add_theme_support( 'disable-custom-colors' );
		add_theme_support( 'disable-custom-font-sizes' );
		add_theme_support( 'disable-custom-gradients' );
		add_theme_support( 'editor-gradient-presets', array() );
		add_theme_support( 'editor-font-sizes', array() );
		add_theme_support(
			'editor-color-palette',
			array(
				array( 'name' => 'Navy', 'slug' => 'navy', 'color' => '#0A3266' ),
				array( 'name' => 'Emas', 'slug' => 'emas', 'color' => '#C8913C' ),
				array( 'name' => 'Teks', 'slug' => 'teks', 'color' => '#0B1F3F' ),
			)
		);
	},
	20
);
add_filter( 'should_load_remote_block_patterns', '__return_false' );
add_filter(
	'block_editor_settings_all',
	function ( $s ) {
		$s['enableOpenverseMediaCategory'] = false; // tidak ada foto stok pihak ketiga
		$s['fontLibraryEnabled']           = false;
		return $s;
	}
);

function aac_allowed_blocks( $allowed, $ctx ) {
	if ( current_user_can( 'manage_options' ) || empty( $ctx->post ) ) {
		return $allowed; // pengembang/Administrator tetap bebas
	}
	$dasar = array( 'core/paragraph', 'core/heading', 'core/list', 'core/list-item', 'core/quote', 'core/image', 'core/table', 'core/details', 'core/separator', 'core/file', 'core/embed' );
	if ( 'page' === $ctx->post->post_type ) {
		return array_merge( $dasar, array( 'core/buttons', 'core/button', 'core/group', 'core/columns', 'core/column' ) );
	}
	return $dasar;
}
add_filter( 'allowed_block_types_all', 'aac_allowed_blocks', 10, 2 );

// Modal "Selamat datang di editor" tidak pernah muncul: preferensi welcomeGuide = false sejak dibaca dari server.
add_filter(
	'get_user_metadata',
	function ( $v, $uid, $key, $single ) {
		static $dalam = false;
		global $wpdb;
		if ( $dalam || $key !== $wpdb->get_blog_prefix() . 'persisted_preferences' ) {
			return $v;
		}
		$dalam = true;
		$p     = get_user_meta( $uid, $key, true );
		$dalam = false;
		$p     = is_array( $p ) ? $p : array();
		foreach ( array( 'core', 'core/edit-post' ) as $s ) {
			if ( ! isset( $p[ $s ] ) || ! is_array( $p[ $s ] ) ) {
				$p[ $s ] = array();
			}
			if ( ! isset( $p[ $s ]['welcomeGuide'] ) ) {
				$p[ $s ]['welcomeGuide'] = false;
			}
		}
		return array( $p );
	},
	10,
	4
);

/* =====================================================================
 * 3. Penulis & peninjau wajib sebelum terbit
 *    - Editor blok: tombol Terbitkan di panel "Cek sebelum terbit" terkunci (lockPostSaving) selama kosong.
 *    - Server: artikel yang baru diterbitkan/dijadwalkan tanpa keduanya dikembalikan ke DRAF (non-Administrator).
 * ===================================================================== */
function aac_scf_artikel_aktif() {
	static $ada = null;
	if ( null === $ada ) {
		$ada = function_exists( 'acf_get_field_group' ) && (bool) acf_get_field_group( 'group_autentik_artikel' );
	}
	return $ada;
}

/** @return string[] kolom wajib yang masih kosong. Nilai dari formulir SCF ($_POST['acf']) diutamakan. */
function aac_kurang_peninjau( $post_id ) {
	$acf = isset( $_POST['acf'] ) && is_array( $_POST['acf'] ) ? wp_unslash( $_POST['acf'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput
	$get = function ( $name, $key ) use ( $acf, $post_id ) {
		if ( is_array( $acf ) && array_key_exists( $key, $acf ) ) {
			return (int) ( is_array( $acf[ $key ] ) ? reset( $acf[ $key ] ) : $acf[ $key ] );
		}
		return $post_id ? (int) get_post_meta( $post_id, $name, true ) : 0;
	};
	$kurang = array();
	if ( ! $get( 'penulis_tim', 'field_ap_penulis' ) ) {
		$kurang[] = 'Ditulis oleh';
	}
	if ( ! $get( 'peninjau_tim', 'field_ap_peninjau' ) ) {
		$kurang[] = 'Ditinjau oleh';
	}
	return $kurang;
}

function aac_jaga_terbit( $data, $postarr ) {
	if ( 'post' !== $data['post_type'] || ! in_array( $data['post_status'], array( 'publish', 'future' ), true ) || current_user_can( 'manage_options' ) ) {
		return $data;
	}
	$id          = (int) ( $postarr['ID'] ?? 0 );
	$lama        = $id ? get_post_status( $id ) : 'baru';
	$baru_terbit = ! in_array( $lama, array( 'publish', 'future' ), true );
	// Editor blok: kolom SCF disimpan SESUDAH permintaan REST (lewat permintaan meta box). Tandai, lalu cek di sana.
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST && aac_scf_artikel_aktif() ) {
		if ( $baru_terbit && $id ) {
			update_post_meta( $id, '_aac_cek_terbit', 1 );
		}
		return $data;
	}
	$ditandai = $id && get_post_meta( $id, '_aac_cek_terbit', true );
	if ( ! $baru_terbit && ! $ditandai ) {
		return $data; // artikel yang sudah tayang sebelumnya tidak diturunkan diam-diam
	}
	if ( $ditandai ) {
		delete_post_meta( $id, '_aac_cek_terbit' );
	}
	$kurang = aac_kurang_peninjau( $id );
	if ( $kurang ) {
		$data['post_status'] = 'draft';
		update_user_meta( get_current_user_id(), 'aac_ditahan', array( 'id' => $id, 'kurang' => $kurang ) );
	}
	return $data;
}
add_filter( 'wp_insert_post_data', 'aac_jaga_terbit', 99, 2 );

function aac_teks_ditahan( $d ) {
	$judul = ! empty( $d['id'] ) ? get_the_title( (int) $d['id'] ) : '';
	return 'Artikel' . ( $judul ? ' "' . $judul . '"' : '' ) . ' dikembalikan ke DRAF karena kolom ' . implode( ' dan ', (array) $d['kurang'] ) . ' masih kosong. Isi di kotak "Penulis dan Peninjau" (panel kanan editor), lalu terbitkan lagi.';
}
// Pemberitahuan di layar klasik/daftar (mis. setelah Sunting Cepat).
add_action(
	'admin_notices',
	function () {
		$d = get_user_meta( get_current_user_id(), 'aac_ditahan', true );
		$s = get_current_screen();
		if ( ! $d || ( $s && $s->is_block_editor ) ) {
			return;
		}
		delete_user_meta( get_current_user_id(), 'aac_ditahan' );
		echo '<div class="notice notice-error"><p><strong>' . esc_html( aac_teks_ditahan( $d ) ) . '</strong></p></div>';
	}
);

/* =====================================================================
 * 4. Skrip editor: istilah, H1 dilarang di isi artikel, peringatan judul/slug, panel "Cek sebelum terbit"
 * ===================================================================== */
function aac_kategori_terhubung() {
	$map = function_exists( 'autentik_cat_to_layanan' ) ? autentik_cat_to_layanan() : array();
	$ok  = array();
	foreach ( get_categories( array( 'hide_empty' => false ) ) as $t ) {
		if ( isset( $map[ $t->slug ] ) || (int) get_term_meta( $t->term_id, 'layanan_terkait', true ) ) {
			$ok[] = (int) $t->term_id;
		}
	}
	return $ok;
}

function aac_editor_js() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	$type   = $screen ? $screen->post_type : '';
	$ditahan = '';
	$d       = get_user_meta( get_current_user_id(), 'aac_ditahan', true );
	if ( $d && 'post' === $type ) {
		$ditahan = aac_teks_ditahan( $d );
		delete_user_meta( get_current_user_id(), 'aac_ditahan' );
	}
	wp_register_script( 'aac-editor', false, array( 'wp-plugins', 'wp-editor', 'wp-edit-post', 'wp-element', 'wp-data', 'wp-dom-ready', 'wp-hooks', 'wp-api-fetch', 'wp-notices' ), '0.2', true );
	wp_enqueue_script( 'aac-editor' );
	wp_add_inline_script(
		'aac-editor',
		'window.AAC=' . wp_json_encode(
			array(
				'type'       => $type,
				'defCat'     => (int) get_option( 'default_category' ),
				'catOk'      => 'post' === $type ? aac_kategori_terhubung() : array(),
				'bisaTerbit' => current_user_can( 'publish_posts' ),
				'ditahan'    => $ditahan,
				'istilah'    => array(
					'Excerpt'                     => 'Ringkasan (kartu & Google)',
					'Add an excerpt…'             => 'Tulis ringkasan… (kosong = otomatis dari Jawaban singkat)',
					'Write an excerpt (optional)' => 'Kosongkan agar diambil otomatis dari Jawaban singkat',
				),
			)
		) . ';' . <<<'JS'
( function ( wp ) {
	var el = wp.element.createElement, data = wp.data;
	// Modal "Selamat datang": WP 6.x = core/edit-post, WP 7.x = core. Dijalankan sebelum editor dirender.
	try { [ 'core', 'core/edit-post' ].forEach( function ( s ) { data.dispatch( 'core/preferences' ).set( s, 'welcomeGuide', false ); } ); } catch ( e ) {}
	wp.hooks.addFilter( 'i18n.gettext', 'aac/istilah', function ( tr, text ) { return ( AAC.istilah && AAC.istilah[ text ] ) || tr; } );
	// Judul artikel sudah H1: di isi artikel hanya boleh H2–H4 (WP 6.7+).
	wp.hooks.addFilter( 'blocks.registerBlockType', 'aac/heading', function ( s, n ) {
		if ( 'core/heading' === n && 'post' === AAC.type && s.attributes && s.attributes.levelOptions ) {
			s.attributes = Object.assign( {}, s.attributes, { levelOptions: Object.assign( {}, s.attributes.levelOptions, { default: [ 2, 3, 4 ] } ) } );
		}
		return s;
	} );
	if ( 'post' !== AAC.type ) { return; }
	var ed = function () { return data.select( 'core/editor' ); };
	var slugOf = function ( e ) { return String( ( e.getEditedPostSlug ? e.getEditedPostSlug() : e.getEditedPostAttribute( 'slug' ) ) || '' ); };
	var notices = function () { return data.dispatch( 'core/notices' ); };
	wp.domReady( function () {
		// Panel "Cek sebelum terbit" selalu tampil (kotak "Selalu tampilkan…" disembunyikan lewat CSS).
		[ 'core/editor', 'core/edit-post' ].some( function ( s ) { try { data.dispatch( s ).enablePublishSidebar(); return true; } catch ( e ) { return false; } } );
		try { if ( ! ed().isEditorPanelOpened( 'taxonomy-panel-category' ) ) { data.dispatch( 'core/editor' ).toggleEditorPanelOpened( 'taxonomy-panel-category' ); } } catch ( e ) {}
		if ( AAC.ditahan ) { notices().createErrorNotice( AAC.ditahan, { id: 'aac-ditahan' } ); }
	} );
	// Peringatan langsung: judul > 70 karakter, slug > 7 kata / 60 karakter.
	var lastKey = '', wasSaving = false;
	data.subscribe( function () {
		var e = ed(); if ( ! e || ! e.getCurrentPostId ) { return; }
		var t = String( e.getEditedPostAttribute( 'title' ) || '' ), sl = slugOf( e );
		var pj = t.length > 70, sp = sl.length > 60 || sl.split( '-' ).length > 7;
		var key = pj + '|' + sp;
		if ( key !== lastKey ) {
			lastKey = key;
			if ( pj ) { notices().createWarningNotice( 'Judul lebih dari 70 karakter: Google memotongnya. Ringkas menjadi 30–65 karakter.', { id: 'aac-judul', isDismissible: false } ); } else { notices().removeNotice( 'aac-judul' ); }
			if ( sp ) { notices().createWarningNotice( 'Alamat (slug) terlalu panjang. Pendekkan menjadi maks. 7 kata di panel kanan › Tautan/URL, mis. cek-sertifikat-tanah-sebelum-membeli.', { id: 'aac-slug', isDismissible: false } ); } else { notices().removeNotice( 'aac-slug' ); }
		}
		// Setelah kolom SCF tersimpan: bila server mengembalikan artikel ke draf, beri tahu.
		var ep = data.select( 'core/edit-post' ), now = !! ( ep && ep.isSavingMetaBoxes && ep.isSavingMetaBoxes() );
		if ( wasSaving && ! now && [ 'publish', 'future' ].indexOf( e.getCurrentPostAttribute( 'status' ) ) > -1 ) {
			wp.apiFetch( { path: '/wp/v2/posts/' + e.getCurrentPostId() + '?context=edit&_fields=status' } ).then( function ( p ) {
				if ( p && 'draft' === p.status ) {
					notices().createErrorNotice( 'Artikel dikembalikan ke DRAF: "Ditulis oleh" dan "Ditinjau oleh" wajib diisi sebelum terbit. Muat ulang halaman, lengkapi, lalu terbitkan lagi.', { id: 'aac-ditahan', actions: [ { label: 'Muat ulang', url: window.location.href } ] } );
				}
			} ).catch( function () {} );
		}
		wasSaving = now;
	} );

	var Panel = ( wp.editor && wp.editor.PluginPrePublishPanel ) || ( wp.editPost && wp.editPost.PluginPrePublishPanel );
	if ( ! Panel ) { return; }
	function nilai( n ) { var x = document.querySelector( '.acf-field[data-name="' + n + '"] select' ); return x ? x.value : null; }
	function teks( h ) { return String( h || '' ).replace( /<[^>]*>/g, '' ).trim(); }
	function Cek() {
		// SCF memakai <select> biasa (select2): pantau nilainya berkala.
		var tick = wp.element.useState( 0 );
		wp.element.useEffect( function () { var t = setInterval( function () { tick[1]( function ( x ) { return x + 1; } ); }, 800 ); return function () { clearInterval( t ); }; }, [] );
		var d = data.useSelect( function ( s ) {
			var e = s( 'core/editor' );
			return { img: e.getEditedPostAttribute( 'featured_media' ), cats: e.getEditedPostAttribute( 'categories' ) || [], ex: String( e.getEditedPostAttribute( 'excerpt' ) || '' ), title: String( e.getEditedPostAttribute( 'title' ) || '' ), slug: slugOf( e ) };
		}, [] );
		var b = data.useSelect( function ( s ) {
			var r = { kosong: 0, faq: 0, sub: 0, jawab: false };
			var top = s( 'core/block-editor' ).getBlocks();
			( function walk( bs ) { bs.forEach( function ( x ) {
				if ( ( 'core/paragraph' === x.name || 'core/list-item' === x.name ) && ! teks( x.attributes.content ) ) { r.kosong++; }
				if ( 'core/paragraph' === x.name && /aa-jawaban/.test( x.attributes.className || '' ) && teks( x.attributes.content ) ) { r.jawab = true; }
				if ( 'core/details' === x.name && ! teks( x.attributes.summary ) ) { r.faq++; }
				walk( x.innerBlocks );
			} ); } )( top );
			top.forEach( function ( x, i ) { if ( 'core/heading' === x.name && ( ! top[ i + 1 ] || 'core/heading' === top[ i + 1 ].name ) ) { r.sub++; } } );
			return r;
		}, [] );
		var penulis = nilai( 'penulis_tim' ), peninjau = nilai( 'peninjau_tim' );
		var adaKolom = null !== penulis && null !== peninjau;
		var kunci = adaKolom && ( ! penulis || ( AAC.bisaTerbit && ! peninjau ) );
		wp.element.useEffect( function () {
			var x = data.dispatch( 'core/editor' );
			if ( kunci ) { x.lockPostSaving( 'aac-peninjau' ); } else { x.unlockPostSaving( 'aac-peninjau' ); }
			return function () { x.unlockPostSaving( 'aac-peninjau' ); }; // panel ditutup → Simpan draf tetap bisa
		}, [ kunci ] );
		var tl = d.title.length;
		var rows = [
			[ !! penulis, '"Ditulis oleh" diisi (wajib)' ],
			[ !! peninjau, '"Ditinjau oleh" advokat diisi' + ( AAC.bisaTerbit ? ' (wajib)' : ' (boleh diisi staf saat meninjau)' ) ],
			[ d.img > 0, 'Gambar sampul dipasang (mendatar, min. 1600×800 px, isi teks alternatif)' ],
			[ d.cats.filter( function ( c ) { return c !== AAC.defCat; } ).length > 0, 'Kategori layanan dipilih' ],
			[ d.cats.some( function ( c ) { return AAC.catOk.indexOf( c ) > -1; } ), 'Kategori terhubung ke halaman Layanan' ],
			[ tl >= 30 && tl <= 70, 'Judul 30–70 karakter (sekarang ' + tl + ')' ],
			[ d.slug.length <= 60 && d.slug.split( '-' ).length <= 7, 'Alamat (slug) ringkas, maks. 7 kata' ],
			[ b.jawab || d.ex.trim().length >= 60, 'Ringkasan kartu & Google (otomatis dari Jawaban singkat bila dikosongkan)' ],
			[ b.kosong === 0, b.kosong ? b.kosong + ' blok petunjuk masih kosong (isi atau hapus)' : 'Tidak ada blok petunjuk yang tertinggal' ],
			[ b.faq === 0, b.faq ? b.faq + ' kotak tanya jawab belum diberi pertanyaan' : 'Semua kotak tanya jawab berisi pertanyaan' ],
			[ b.sub === 0, b.sub ? b.sub + ' subjudul tanpa isi di bawahnya' : 'Setiap subjudul berisi' ]
		];
		if ( ! adaKolom ) { rows.splice( 0, 2 ); }
		var kurang = rows.filter( function ( r ) { return ! r[0]; } ).length;
		var judul = kunci
			? 'Tombol Terbitkan aktif setelah "Ditulis oleh"' + ( AAC.bisaTerbit ? ' dan "Ditinjau oleh"' : '' ) + ' diisi. Klik Batal, isi kotak "Penulis dan Peninjau" di panel kanan, lalu klik Terbitkan lagi.'
			: ( kurang ? kurang + ' hal belum lengkap. Sebaiknya dilengkapi sebelum terbit.' : 'Semua lengkap. Siap terbit.' );
		return el( 'div', null,
			el( 'p', { style: { fontWeight: 600, color: kunci || kurang ? '#b32d2e' : '#14783E' } }, judul ),
			el( 'ul', { style: { margin: 0 } }, rows.map( function ( r, i ) {
				return el( 'li', { key: i, style: { color: r[0] ? '#14783E' : '#b32d2e' } }, ( r[0] ? '✓ ' : '✗ ' ) + r[1] );
			} ) )
		);
	}
	wp.plugins.registerPlugin( 'aac-cek-terbit', { render: function () { return el( Panel, { title: 'Cek sebelum terbit', initialOpen: true }, el( Cek ) ); } } );
} )( window.wp );
JS
	);
	wp_register_style( 'aac-editor', false, array(), '0.2' );
	wp_enqueue_style( 'aac-editor' );
	wp_add_inline_style( 'aac-editor', '.editor-post-publish-panel__footer{display:none}' );
}
add_action( 'enqueue_block_editor_assets', 'aac_editor_js' );

/* =====================================================================
 * 5. Label & layar yang lebih jelas
 * ===================================================================== */
// Layanan & Tim diisi lewat kolom, bukan blok: pakai layar klasik (petunjuk tema & kolom langsung terlihat).
add_filter( 'use_block_editor_for_post_type', function ( $use, $type ) { return in_array( $type, array( 'layanan', 'tim' ), true ) ? false : $use; }, 10, 2 );

add_filter(
	'enter_title_here',
	function ( $t, $post ) {
		$map = array(
			'post'    => 'Judul artikel (30–65 karakter, memuat kata yang dicari orang)',
			'tim'     => 'Nama lengkap TANPA gelar (gelar diisi di kolom "Gelar")',
			'klien'   => 'Nama resmi perusahaan, mis. PT Contoh Jaya',
			'layanan' => 'Nama layanan',
		);
		return $map[ $post->post_type ] ?? $t;
	},
	10,
	2
);

foreach ( array( 'post' => 'Gambar sampul', 'tim' => 'Foto potret (4:5)', 'klien' => 'Logo klien', 'layanan' => 'Foto layanan' ) as $aac_type => $aac_lbl ) {
	add_filter(
		"post_type_labels_{$aac_type}",
		function ( $l ) use ( $aac_lbl ) {
			$l->featured_image        = $aac_lbl;
			$l->set_featured_image    = 'Pasang ' . strtolower( $aac_lbl );
			$l->remove_featured_image = 'Hapus ' . strtolower( $aac_lbl );
			$l->use_featured_image    = 'Pakai sebagai ' . strtolower( $aac_lbl );
			$l->search_items          = 'Cari';
			return $l;
		}
	);
}

// Petunjuk ukuran di kotak gambar (layar klasik: Tim, Klien, Layanan).
add_filter(
	'admin_post_thumbnail_html',
	function ( $html, $post_id ) {
		$tips = array(
			'tim'     => 'Potret tegak 4:5, minimal 800×1000 px, latar polos, wajah di sepertiga atas. Hanya foto asli orangnya, dengan persetujuannya.',
			'klien'   => 'PNG latar transparan, lebar minimal 400 px. Tampil di situs hanya bila "Ada izin tertulis" = Ya (dan mode pratinjau klien mati).',
			'layanan' => 'Foto mendatar minimal 1600×900 px. Kosongkan untuk memakai foto bawaan tema.',
		);
		$t = $tips[ get_post_type( $post_id ) ] ?? '';
		return $t ? $html . '<p class="description">' . esc_html( $t ) . '</p>' : $html;
	},
	10,
	2
);

// Peringatan di layar Tim & Klien.
add_action(
	'admin_notices',
	function () {
		$s = get_current_screen();
		if ( ! $s || ! in_array( $s->post_type, array( 'tim', 'klien' ), true ) ) {
			return;
		}
		// Klien: mode pratinjau aktif = semua nama tampil walau belum ada izin (daftar & layar ubah).
		if ( 'klien' === $s->post_type && function_exists( 'autentik_opt' ) && autentik_opt( 'preview_klien' ) ) {
			echo '<div class="notice notice-error"><p><strong>Mode pratinjau klien AKTIF:</strong> semua nama &amp; logo klien tampil di situs, termasuk yang BELUM memberi izin tertulis. Matikan di <em>Tampilan › Sesuaikan › Autentik: Beranda</em> sebelum situs tayang.</p></div>';
		}
		if ( 'post' !== $s->base || empty( $_GET['post'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$id = (int) $_GET['post']; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! has_post_thumbnail( $id ) ) {
			$apa = 'tim' === $s->post_type ? 'Foto potret belum dipasang: profil tampil dengan inisial nama.' : 'Logo belum dipasang: klien tampil sebagai tulisan nama perusahaan.';
			echo '<div class="notice notice-warning"><p><strong>' . esc_html( $apa ) . '</strong> Pasang di kotak kanan bawah.</p></div>';
		}
		if ( 'tim' === $s->post_type ) {
			$st = (string) get_post_meta( $id, 'status_profesi', true );
			if ( '' === $st ) {
				echo '<div class="notice notice-warning"><p><strong>Status profesi belum dikonfirmasi.</strong> Label "Advokat" dan tombol "Konsultasi dengan…" hanya tampil untuk status <em>Advokat</em>. Isi setelah ada salinan Berita Acara Sumpah/KTA.</p></div>';
			} elseif ( 'notaris_mitra' === $st ) {
				echo '<div class="notice notice-info"><p><strong>Notaris mitra</strong> tidak ditampilkan sebagai anggota firma (UUJN &amp; Kode Etik INI).</p></div>';
			}
		}
	}
);

// Tag & komentar tidak dipakai situs: sembunyikan agar staf tidak bingung. Kolom "Penulis" WP hanya untuk Administrator.
add_action(
	'init',
	function () {
		unregister_taxonomy_for_object_type( 'post_tag', 'post' );
		remove_post_type_support( 'post', 'comments' );
		remove_post_type_support( 'post', 'trackbacks' );
		remove_post_type_support( 'page', 'comments' );
		if ( ! current_user_can( 'manage_options' ) ) {
			remove_post_type_support( 'post', 'author' ); // juga menyembunyikan penulis akun di REST publik; cukup "Ditulis oleh" (anggota tim); akun WP tetap tercatat otomatis
		}
	},
	30
);
add_filter( 'comments_open', '__return_false' );
add_filter( 'pings_open', '__return_false' );

// Kotak "Penulis dan Peninjau" pindah ke panel kanan (tidak tersembunyi di laci "Meta Boxes" bawah).
add_filter(
	'acf/load_field_group',
	function ( $g ) {
		if ( isset( $g['key'] ) && 'group_autentik_artikel' === $g['key'] ) {
			$g['position'] = 'side';
		}
		return $g;
	}
);
add_filter(
	'acf/load_field',
	function ( $f ) {
		if ( in_array( $f['key'] ?? '', array( 'field_ap_penulis', 'field_ap_peninjau' ), true ) ) {
			$f['wrapper']['width'] = ''; // lebar penuh di panel kanan
			// Impor SCF tanpa hak unfiltered_html bisa merusak definisi field (kses mengubah "&" → "&amp;") dan
			// membuatnya jatuh ke "text". Pulihkan agar tetap berupa pilihan anggota Tim.
			if ( 'post_object' !== ( $f['type'] ?? '' ) ) {
				$f = array_merge( $f, array( 'type' => 'post_object', 'post_type' => array( 'tim' ), 'taxonomy' => '', 'allow_null' => 1, 'multiple' => 0, 'return_format' => 'id', 'ui' => 1 ) );
			}
		}
		return $f;
	}
);
// Pilihan "Ditinjau oleh" hanya anggota berstatus Advokat; "Ditulis oleh" tanpa notaris mitra.
add_filter(
	'acf/fields/post_object/query/name=peninjau_tim',
	function ( $args ) {
		$args['meta_query'] = array( array( 'key' => 'status_profesi', 'value' => 'advokat' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return $args;
	}
);
add_filter(
	'acf/fields/post_object/query/name=penulis_tim',
	function ( $args ) {
		$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
			'relation' => 'OR',
			array( 'key' => 'status_profesi', 'compare' => 'NOT EXISTS' ),
			array( 'key' => 'status_profesi', 'value' => 'notaris_mitra', 'compare' => '!=' ),
		);
		return $args;
	}
);

// Menu SCF hanya untuk Administrator.
add_filter( 'acf/settings/show_admin', function () { return current_user_can( 'manage_options' ); } );

/* =====================================================================
 * 6. Kategori artikel ↔ Layanan lewat kolom (term meta "layanan_terkait"), bukan slug
 * ===================================================================== */
// Pemetaan tema (slug kategori → slug layanan) ditambah dari kolom; kolom mengalahkan tebakan slug.
add_filter(
	'autentik_cat_to_layanan',
	function ( $map ) {
		static $tambah = null;
		if ( null === $tambah ) {
			$tambah = array();
			$terms  = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false, 'meta_key' => 'layanan_terkait' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			foreach ( is_array( $terms ) ? $terms : array() as $t ) {
				$lid = (int) get_term_meta( $t->term_id, 'layanan_terkait', true );
				if ( $lid && 'layanan' === get_post_type( $lid ) ) {
					$tambah[ $t->slug ] = get_post_field( 'post_name', $lid );
				}
			}
		}
		return array_merge( (array) $map, $tambah );
	}
);
add_filter(
	'manage_edit-category_columns',
	function ( $c ) {
		unset( $c['description'] );
		$c['aac_lay'] = 'Layanan terkait';
		return $c;
	}
);
add_filter(
	'manage_category_custom_column',
	function ( $out, $col, $term_id ) {
		if ( 'aac_lay' !== $col ) {
			return $out;
		}
		if ( (int) get_option( 'default_category' ) === (int) $term_id ) {
			return '— (kategori umum)';
		}
		$lid = (int) get_term_meta( $term_id, 'layanan_terkait', true );
		if ( $lid ) {
			return esc_html( get_the_title( $lid ) );
		}
		$t   = get_term( $term_id, 'category' );
		$map = function_exists( 'autentik_cat_to_layanan' ) ? autentik_cat_to_layanan() : array();
		if ( $t && ! is_wp_error( $t ) && isset( $map[ $t->slug ] ) ) {
			return esc_html( $map[ $t->slug ] ) . ' <small>(dari slug; sebaiknya pilih di kolom)</small>';
		}
		return aac_ok( false, '', 'Belum terhubung' );
	},
	10,
	3
);
// "Uncategorized" → "Umum" (sekali).
add_action(
	'admin_init',
	function () {
		if ( get_option( 'aac_umum_v' ) ) {
			return;
		}
		$id = (int) get_option( 'default_category' );
		$t  = $id ? get_term( $id, 'category' ) : null;
		if ( $t && ! is_wp_error( $t ) && in_array( $t->slug, array( 'uncategorized', 'tak-berkategori', 'tidak-berkategori' ), true ) && ! get_term_by( 'slug', 'umum', 'category' ) ) {
			wp_update_term( $id, 'category', array( 'name' => 'Umum', 'slug' => 'umum' ) );
		}
		update_option( 'aac_umum_v', 1 );
	}
);

/* =====================================================================
 * 7. Kolom admin
 * ===================================================================== */
function aac_ok( $ok, $ya = 'Ya', $tidak = 'Belum' ) {
	return $ok ? '<span style="color:#14783E">✓ ' . esc_html( $ya ) . '</span>' : '<span style="color:#b32d2e">✗ ' . esc_html( $tidak ) . '</span>';
}
function aac_thumb( $id, $w = 44, $h = 55 ) {
	return has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array( $w, $h ), array( 'style' => "width:{$w}px;height:{$h}px;object-fit:cover;border-radius:3px" ) ) : aac_ok( false, '', 'Belum ada' );
}
function aac_status_profesi() {
	return array(
		''              => 'Belum dikonfirmasi',
		'advokat'       => 'Advokat',
		'calon_advokat' => 'Calon advokat/magang',
		'paralegal'     => 'Paralegal',
		'staf'          => 'Staf',
		'notaris_mitra' => 'Notaris mitra',
	);
}

// Artikel
add_filter(
	'manage_post_posts_columns',
	function ( $c ) {
		unset( $c['author'], $c['tags'], $c['comments'] );
		return array_slice( $c, 0, 1 ) + array( 'aac_img' => 'Gambar' ) + array_slice( $c, 1, 1 ) + array( 'aac_by' => 'Ditulis oleh', 'aac_rev' => 'Ditinjau oleh' ) + array_slice( $c, 2 );
	}
);
add_action(
	'manage_post_posts_custom_column',
	function ( $col, $id ) {
		if ( 'aac_img' === $col ) {
			echo aac_thumb( $id, 64, 40 ); // phpcs:ignore
		} elseif ( in_array( $col, array( 'aac_by', 'aac_rev' ), true ) ) {
			$pid = (int) get_post_meta( $id, 'aac_by' === $col ? 'penulis_tim' : 'peninjau_tim', true );
			echo $pid ? esc_html( get_the_title( $pid ) ) : aac_ok( false, '', 'Kosong' ); // phpcs:ignore
		}
	},
	10,
	2
);

// Tim
add_filter(
	'manage_tim_posts_columns',
	function ( $c ) {
		return array( 'cb' => $c['cb'], 'aac_img' => 'Foto', 'title' => 'Nama', 'aac_st' => 'Status profesi', 'aac_jab' => 'Jabatan', 'aac_bid' => 'Layanan', 'aac_pim' => 'Pendiri/pimpinan', 'aac_urut' => 'Urutan', 'date' => $c['date'] );
	}
);
add_action(
	'manage_tim_posts_custom_column',
	function ( $col, $id ) {
		switch ( $col ) {
			case 'aac_img':
				echo aac_thumb( $id ); // phpcs:ignore
				break;
			case 'aac_st':
				$st  = (string) get_post_meta( $id, 'status_profesi', true );
				$lbl = aac_status_profesi()[ $st ] ?? $st;
				if ( 'advokat' === $st ) {
					echo aac_ok( true, $lbl . ( get_post_meta( $id, 'no_bas', true ) ? '' : ' (No. BAS kosong)' ) ); // phpcs:ignore
				} elseif ( '' === $st ) {
					echo aac_ok( false, '', $lbl ); // phpcs:ignore
				} else {
					echo esc_html( $lbl );
				}
				break;
			case 'aac_jab':
				echo esc_html( trim( get_post_meta( $id, 'jabatan', true ) . ' · ' . get_post_meta( $id, 'gelar', true ), ' ·' ) );
				break;
			case 'aac_bid':
				$ids = array_filter( array_map( 'intval', (array) get_post_meta( $id, 'bidang', true ) ) );
				echo $ids ? esc_html( implode( ', ', array_map( 'get_the_title', $ids ) ) ) : aac_ok( false, '', 'Belum dipilih' ); // phpcs:ignore
				break;
			case 'aac_pim':
				echo get_post_meta( $id, 'pimpinan', true ) ? '★' : '';
				break;
			case 'aac_urut':
				echo (int) get_post_field( 'menu_order', $id );
				break;
		}
	},
	10,
	2
);

// Klien
add_filter(
	'manage_klien_posts_columns',
	function ( $c ) {
		return array( 'cb' => $c['cb'], 'aac_img' => 'Logo', 'title' => 'Perusahaan', 'aac_izin' => 'Izin tertulis', 'aac_urut' => 'Urutan', 'date' => $c['date'] );
	}
);
add_action(
	'manage_klien_posts_custom_column',
	function ( $col, $id ) {
		if ( 'aac_img' === $col ) {
			echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array( 90, 45 ), array( 'style' => 'max-width:90px;max-height:45px;width:auto;height:auto' ) ) : aac_ok( false, '', 'Belum ada' ); // phpcs:ignore
		} elseif ( 'aac_izin' === $col ) {
			echo aac_ok( (bool) get_post_meta( $id, 'izin_tayang', true ), 'Ada', 'Belum — tidak tampil' ); // phpcs:ignore
		} elseif ( 'aac_urut' === $col ) {
			echo (int) get_post_field( 'menu_order', $id );
		}
	},
	10,
	2
);

// Tim & Klien: urutan di admin = urutan di situs.
add_action(
	'pre_get_posts',
	function ( $q ) {
		if ( ! is_admin() || ! $q->is_main_query() ) {
			return;
		}
		if ( in_array( $q->get( 'post_type' ), array( 'tim', 'klien' ), true ) && ! $q->get( 'orderby' ) ) {
			$q->set( 'orderby', array( 'menu_order' => 'ASC', 'title' => 'ASC' ) );
		}
		// Pesan Masuk › "Belum ditangani"
		if ( 'pesan' === $q->get( 'post_type' ) && isset( $_GET['aac_st'] ) && 'baru' === $_GET['aac_st'] ) { // phpcs:ignore WordPress.Security.NonceVerification
			$q->set( 'meta_query', array( array( 'key' => 'ditangani', 'compare' => 'NOT EXISTS' ) ) );
		}
	}
);

/* =====================================================================
 * 8. Pesan Masuk: kolom kontak, tombol balas WA, status "sudah ditangani", isi hanya-baca
 * ===================================================================== */
function aac_wa_link( $wa, $nama ) {
	$n = preg_replace( '/\D+/', '', (string) $wa );
	$n = preg_replace( '/^0/', '62', $n );
	$firma = function_exists( 'autentik_opt' ) ? autentik_opt( 'firm' ) : get_bloginfo( 'name' );
	return $n ? 'https://wa.me/' . $n . '?text=' . rawurlencode( "Halo Bapak/Ibu {$nama}, kami dari {$firma} menindaklanjuti permintaan konsultasi yang Anda kirim melalui website." ) : '';
}
add_filter(
	'manage_pesan_posts_columns',
	function ( $c ) {
		return array( 'cb' => $c['cb'], 'title' => 'Pengirim — layanan', 'aac_wa' => 'WhatsApp', 'aac_mail' => 'Email', 'aac_adv' => 'Advokat diminta', 'aac_st' => 'Status', 'date' => 'Masuk' );
	}
);
add_action(
	'manage_pesan_posts_custom_column',
	function ( $col, $id ) {
		$nama = trim( explode( '—', get_the_title( $id ) )[0] );
		if ( 'aac_wa' === $col ) {
			$wa = get_post_meta( $id, 'wa', true );
			$u  = aac_wa_link( $wa, $nama );
			echo $u ? '<a class="button button-small" target="_blank" rel="noopener" href="' . esc_url( $u ) . '">Balas lewat WA</a> <small>' . esc_html( $wa ) . '</small>' : '';
		} elseif ( 'aac_mail' === $col ) {
			$e = get_post_meta( $id, 'email', true );
			echo $e ? '<a href="mailto:' . esc_attr( $e ) . '">' . esc_html( $e ) . '</a>' : '—';
		} elseif ( 'aac_adv' === $col ) {
			echo esc_html( get_post_meta( $id, 'advokat', true ) ?: '—' );
		} elseif ( 'aac_st' === $col ) {
			$t = get_post_meta( $id, 'ditangani', true );
			if ( $t ) {
				echo aac_ok( true, 'Ditangani ' . wp_date( 'j M', (int) $t ) ); // phpcs:ignore
			} else {
				$u = wp_nonce_url( admin_url( 'admin-post.php?action=aac_ditangani&id=' . $id ), 'aac_ditangani_' . $id );
				echo '<strong style="color:#b32d2e">Belum ditangani</strong> · <a href="' . esc_url( $u ) . '">Tandai sudah ditangani</a>';
			}
		}
	},
	10,
	2
);
add_filter(
	'views_edit-pesan',
	function ( $v ) {
		$n   = count( get_posts( array( 'post_type' => 'pesan', 'post_status' => 'private', 'numberposts' => 500, 'fields' => 'ids', 'meta_query' => array( array( 'key' => 'ditangani', 'compare' => 'NOT EXISTS' ) ) ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$now = isset( $_GET['aac_st'] ) && 'baru' === $_GET['aac_st']; // phpcs:ignore WordPress.Security.NonceVerification
		$v['aac_baru'] = '<a href="' . esc_url( admin_url( 'edit.php?post_type=pesan&aac_st=baru' ) ) . '"' . ( $now ? ' class="current" aria-current="page"' : '' ) . '>Belum ditangani <span class="count">(' . (int) $n . ')</span></a>';
		return $v;
	}
);
add_action(
	'admin_post_aac_ditangani',
	function () {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'aac_ditangani_' . $id );
		if ( ! $id || 'pesan' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
			wp_die( 'Tidak diizinkan.' );
		}
		update_post_meta( $id, 'ditangani', time() );
		update_post_meta( $id, 'ditangani_oleh', get_current_user_id() );
		delete_transient( 'autentik_pesan_baru' ); // lencana menu ikut berkurang
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'edit.php?post_type=pesan' ) );
		exit;
	}
);
// Hilangkan akhiran " — Private" di daftar pesan.
add_filter( 'display_post_states', function ( $s, $p ) { return 'pesan' === $p->post_type ? array() : $s; }, 10, 2 );
// Isi pesan hanya-baca (tidak bisa terhapus/teredit tak sengaja).
add_action(
	'init',
	function () {
		remove_post_type_support( 'pesan', 'editor' );
	},
	30
);
add_action(
	'add_meta_boxes_pesan',
	function ( $p ) {
		add_meta_box(
			'aac_isi',
			'Isi pesan',
			function ( $p ) {
				$u = aac_wa_link( get_post_meta( $p->ID, 'wa', true ), trim( explode( '—', $p->post_title )[0] ) );
				echo '<div style="white-space:pre-wrap;font-size:14px;line-height:1.7">' . esc_html( $p->post_content ) . '</div>';
				if ( $u ) {
					echo '<p><a class="button button-primary" target="_blank" rel="noopener" href="' . esc_url( $u ) . '">Balas lewat WhatsApp</a></p>';
				}
			},
			'pesan',
			'normal',
			'high'
		);
	}
);

/* =====================================================================
 * 9. Gambar: perkecil otomatis, WebP, tanpa ukuran yang tidak dipakai
 * ===================================================================== */
add_filter( 'big_image_size_threshold', function () { return 2000; } ); // foto HP 4000 px → 2000 px
add_filter( 'wp_editor_set_quality', function () { return 82; } );
add_filter(
	'image_editor_output_format',
	function ( $f ) {
		$f['image/jpeg'] = 'image/webp'; // PNG (logo transparan) dibiarkan PNG
		return $f;
	}
);
add_filter(
	'intermediate_image_sizes_advanced',
	function ( $s ) {
		unset( $s['1536x1536'], $s['2048x2048'] );
		return $s;
	}
);
add_filter(
	'wp_handle_upload_prefilter',
	function ( $f ) {
		if ( ! empty( $f['size'] ) && $f['size'] > 15 * MB_IN_BYTES ) {
			$f['error'] = 'Berkas terlalu besar (maks. 15 MB). Kirim foto lewat WhatsApp ke diri sendiri lalu unggah hasilnya, atau kecilkan dulu.';
		}
		return $f;
	}
);

/* =====================================================================
 * 10. Peran
 *    - Administrator     : pengelola teknis + 1 partner (semua akses)
 *    - Staf Kantor       : artikel, halaman, Layanan/Tim/Klien, Pesan Masuk, Customizer kontak & beranda.
 *                          Tanpa plugin/tema/pengaturan, tanpa Legalitas & Analitik (dikunci di tema), tanpa
 *                          membuat kategori baru, tanpa unfiltered_html.
 *    - Advokat (Penulis) : menulis artikel & unggah gambar; TIDAK bisa menerbitkan ("Kirim untuk Ditinjau").
 *                          Tidak bisa menyentuh Layanan/Tim/Klien (jenis konten memakai kapabilitas aa_profil).
 * ===================================================================== */
function aac_cap_profil() {
	$c = array();
	foreach ( array( 'edit_%s', 'edit_others_%s', 'edit_published_%s', 'edit_private_%s', 'publish_%s', 'read_private_%s', 'delete_%s', 'delete_others_%s', 'delete_published_%s', 'delete_private_%s' ) as $f ) {
		$c[ sprintf( $f, 'aa_profils' ) ] = true;
	}
	return $c;
}
add_action(
	'init',
	function () {
		if ( '3' === get_option( 'aac_roles_v' ) ) {
			return;
		}
		remove_role( 'staf_kantor' );
		remove_role( 'advokat_penulis' );
		$editor = get_role( 'editor' );
		$caps   = $editor ? $editor->capabilities : array( 'read' => true );
		unset( $caps['unfiltered_html'], $caps['manage_categories'], $caps['moderate_comments'], $caps['manage_links'] );
		add_role( 'staf_kantor', 'Staf Kantor', array_merge( $caps, aac_cap_profil(), array( 'autentik_pesan' => true, 'edit_theme_options' => true ) ) );
		add_role( 'advokat_penulis', 'Advokat (Penulis)', array( 'read' => true, 'edit_posts' => true, 'delete_posts' => true, 'upload_files' => true ) );
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( array_keys( aac_cap_profil() + array( 'autentik_pesan' => true ) ) as $c ) {
				$admin->add_cap( $c );
			}
		}
		update_option( 'aac_roles_v', '3' );
	},
	1
);

// Tambah Pengguna: hanya tiga peran yang dipakai (Editor punya unfiltered_html, Author bisa langsung terbit).
add_filter(
	'editable_roles',
	function ( $r ) {
		unset( $r['editor'], $r['author'], $r['contributor'], $r['subscriber'] );
		return $r;
	}
);

// Pesan Masuk: dibuka oleh pemilik kapabilitas "autentik_pesan" (Administrator + Staf Kantor).
add_filter(
	'register_post_type_args',
	function ( $args, $type ) {
		if ( 'pesan' === $type && ! empty( $args['capabilities'] ) ) {
			foreach ( $args['capabilities'] as $k => $v ) {
				if ( 'manage_options' === $v ) {
					$args['capabilities'][ $k ] = 'autentik_pesan';
				}
			}
		}
		return $args;
	},
	20,
	2
);

// Artikel advokat masuk antrean tinjauan → kabari staf lewat email.
add_action(
	'transition_post_status',
	function ( $new, $old, $post ) {
		if ( 'pending' === $new && 'pending' !== $old && 'post' === $post->post_type ) {
			$to = function_exists( 'autentik_opt' ) && autentik_opt( 'lead_email' ) ? autentik_opt( 'lead_email' ) : get_option( 'admin_email' );
			wp_mail( $to, '[Website] Artikel menunggu tinjauan: ' . $post->post_title, "Buka untuk meninjau, mengisi \"Ditinjau oleh\", lalu menerbitkan:\n" . admin_url( 'post.php?post=' . $post->ID . '&action=edit' ) );
		}
	},
	10,
	3
);
