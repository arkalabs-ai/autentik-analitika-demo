<?php
/**
 * Plugin Name: Autentik — Jenis Konten
 * Description: Mendaftarkan jenis konten Layanan, Tim, Klien, dan Pesan Masuk (dari formulir) serta CMS staf (templat artikel, peran, kunci terbit) untuk situs Law Firm Autentik Analitika. Aktifkan SEBELUM mengimpor autentik-konten.xml. WAJIB AKTIF — jangan dihapus.
 * Version: 1.1.0
 * Author: ARKA LABS
 * Text Domain: autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function autentik_register_post_types() {
	$types = array(
		'layanan' => array(
			'jamak'    => 'Layanan',
			'tunggal'  => 'Layanan',
			'ikon'     => 'dashicons-portfolio',
			'publik'   => true,
			'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
		),
		'tim'     => array(
			'jamak'    => 'Tim Hukum',
			'tunggal'  => 'Anggota Tim',
			'ikon'     => 'dashicons-groups',
			'publik'   => true,
			'supports' => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		),
		'pesan'   => array(
			'jamak'    => 'Pesan Masuk',
			'tunggal'  => 'Pesan',
			'ikon'     => 'dashicons-email-alt',
			'publik'   => false,
			'privat'   => true,
			'supports' => array( 'title', 'editor' ),
		),
		'klien'   => array(
			'jamak'    => 'Klien',
			'tunggal'  => 'Klien',
			'ikon'     => 'dashicons-building',
			'publik'   => false,
			'supports' => array( 'title', 'thumbnail', 'page-attributes' ),
		),
	);

	foreach ( $types as $slug => $t ) {
		register_post_type(
			$slug,
			array(
				'labels'              => array(
					'name'          => $t['jamak'],
					'singular_name' => $t['tunggal'],
					'add_new_item'  => 'Tambah ' . $t['tunggal'],
					'edit_item'     => 'Ubah ' . $t['tunggal'],
					'all_items'     => 'Semua ' . $t['jamak'],
					'add_new'       => 'Tambah ' . $t['tunggal'],
					'view_item'     => 'Lihat ' . $t['tunggal'],
					'search_items'  => 'Cari',
					'not_found'     => 'Belum ada data',
					'not_found_in_trash' => 'Tempat sampah kosong',
				),
				'public'              => $t['publik'],
				'show_ui'             => true,
				'publicly_queryable'  => $t['publik'],
				'exclude_from_search' => ! $t['publik'],
				'show_in_rest'        => $t['publik'],
				'show_in_nav_menus'   => $t['publik'],
				'menu_icon'           => $t['ikon'],
				'has_archive'         => false,
				'hierarchical'        => false,
				'rewrite'             => $t['publik'] ? array( 'slug' => $slug, 'with_front' => false ) : false,
				'supports'            => $t['supports'],
				'map_meta_cap'        => true,
				// Layanan/Tim/Klien: kapabilitas sendiri (Administrator + Staf Kantor), agar Advokat (Penulis) tidak bisa mengubahnya.
				'capability_type'     => empty( $t['privat'] ) ? array( 'aa_profil', 'aa_profils' ) : 'post',
				// Pesan Masuk berisi data pribadi calon klien: hanya Administrator (bukan Editor).
				'capabilities'        => empty( $t['privat'] ) ? array() : array(
					'create_posts'           => 'do_not_allow',
					'edit_posts'             => 'manage_options',
					'edit_others_posts'      => 'manage_options',
					'edit_private_posts'     => 'manage_options',
					'edit_published_posts'   => 'manage_options',
					'read_private_posts'     => 'manage_options',
					'delete_posts'           => 'manage_options',
					'delete_others_posts'    => 'manage_options',
					'delete_private_posts'   => 'manage_options',
					'delete_published_posts' => 'manage_options',
					'publish_posts'          => 'manage_options',
				),
			)
		);
	}
}
add_action( 'init', 'autentik_register_post_types' );

require_once __DIR__ . '/autentik-cms.php';

/**
 * UU PDP: Pesan Masuk ikut diproses di Alat › Ekspor/Hapus Data Pribadi (dicari lewat email).
 */
function autentik_pesan_by_email( $email ) {
	return get_posts( array( 'post_type' => 'pesan', 'post_status' => 'any', 'numberposts' => 100, 'meta_key' => 'email', 'meta_value' => $email ) );
}
add_filter(
	'wp_privacy_personal_data_exporters',
	function ( $ex ) {
		$ex['autentik-pesan'] = array(
			'exporter_friendly_name' => 'Pesan Masuk (formulir konsultasi)',
			'callback'               => function ( $email ) {
				$data = array();
				foreach ( autentik_pesan_by_email( $email ) as $p ) {
					$data[] = array(
						'group_id'    => 'autentik-pesan',
						'group_label' => 'Pesan Masuk',
						'item_id'     => 'pesan-' . $p->ID,
						'data'        => array(
							array( 'name' => 'Tanggal', 'value' => $p->post_date ),
							array( 'name' => 'Isi', 'value' => $p->post_content ),
						),
					);
				}
				return array( 'data' => $data, 'done' => true );
			},
		);
		return $ex;
	}
);
add_filter(
	'wp_privacy_personal_data_erasers',
	function ( $er ) {
		$er['autentik-pesan'] = array(
			'eraser_friendly_name' => 'Pesan Masuk (formulir konsultasi)',
			'callback'             => function ( $email ) {
				$n = 0;
				foreach ( autentik_pesan_by_email( $email ) as $p ) {
					if ( wp_delete_post( $p->ID, true ) ) {
						$n++;
					}
				}
				return array( 'items_removed' => $n > 0, 'items_retained' => false, 'messages' => array(), 'done' => true );
			},
		);
		return $er;
	}
);

function autentik_activate() {
	autentik_register_post_types();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'autentik_activate' );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
