<?php
/**
 * Plugin Name: Autentik — Jenis Konten
 * Description: Mendaftarkan jenis konten Layanan, Tim, Klien, dan Pesan Masuk (dari formulir) serta CMS staf (templat artikel, peran, kunci terbit) untuk situs Law Firm Autentik Analitika. Aktifkan SEBELUM mengimpor autentik-konten.xml. WAJIB AKTIF — jangan dihapus.
 * Version: 1.2.1
 * Requires at least: 6.5
 * Requires Plugins: secure-custom-fields
 * Author: ARKA LABS
 * Text Domain: autentik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function autentik_register_post_types() {
	$types = array(
		'layanan' => array(
			'jamak'    => 'Layanan',
			'tunggal'  => 'Layanan',
			'ikon'     => 'dashicons-portfolio',
			'publik'   => true,
			'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
		),
		'tim'     => array(
			'jamak'    => 'Tim Hukum',
			'tunggal'  => 'Anggota Tim',
			'ikon'     => 'dashicons-groups',
			'publik'   => true,
			'supports' => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		),
		'pesan'   => array(
			'jamak'    => 'Pesan Masuk',
			'tunggal'  => 'Pesan',
			'ikon'     => 'dashicons-email-alt',
			'publik'   => false,
			'privat'   => true,
			'supports' => array( 'title', 'editor' ),
		),
		'klien'   => array(
			'jamak'    => 'Klien',
			'tunggal'  => 'Klien',
			'ikon'     => 'dashicons-building',
			'publik'   => false,
			'supports' => array( 'title', 'thumbnail', 'page-attributes' ),
		),
	);

	foreach ( $types as $slug => $t ) {
		register_post_type(
			$slug,
			array(
				'labels'              => array(
					'name'          => $t['jamak'],
					'singular_name' => $t['tunggal'],
					'add_new_item'  => 'Tambah ' . $t['tunggal'],
					'edit_item'     => 'Ubah ' . $t['tunggal'],
					'all_items'     => 'Semua ' . $t['jamak'],
					'add_new'       => 'Tambah ' . $t['tunggal'],
					'view_item'     => 'Lihat ' . $t['tunggal'],
					'search_items'  => 'Cari',
					'not_found'     => 'Belum ada data',
					'not_found_in_trash' => 'Tempat sampah kosong',
				),
				'public'              => $t['publik'],
				'show_ui'             => true,
				'publicly_queryable'  => $t['publik'],
				'exclude_from_search' => ! $t['publik'],
				'show_in_rest'        => $t['publik'],
				'show_in_nav_menus'   => $t['publik'],
				'menu_icon'           => $t['ikon'],
				'has_archive'         => false,
				'hierarchical'        => false,
				'rewrite'             => $t['publik'] ? array( 'slug' => $slug, 'with_front' => false ) : false,
				'supports'            => $t['supports'],
				'map_meta_cap'        => true,
				// Layanan/Tim/Klien: kapabilitas sendiri (Administrator + Staf Kantor), agar Advokat (Penulis) tidak bisa mengubahnya.
				'capability_type'     => empty( $t['privat'] ) ? array( 'aa_profil', 'aa_profils' ) : 'post',
				// Pesan Masuk berisi data pribadi calon klien: hanya Administrator (bukan Editor).
				'capabilities'        => empty( $t['privat'] ) ? array() : array(
					'create_posts'           => 'do_not_allow',
					'edit_posts'             => 'manage_options',
					'edit_others_posts'      => 'manage_options',
					'edit_private_posts'     => 'manage_options',
					'edit_published_posts'   => 'manage_options',
					'read_private_posts'     => 'manage_options',
					'delete_posts'           => 'manage_options',
					'delete_others_posts'    => 'manage_options',
					'delete_private_posts'   => 'manage_options',
					'delete_published_posts' => 'manage_options',
					'publish_posts'          => 'manage_options',
				),
			)
		);
	}
}
add_action( 'init', 'autentik_register_post_types' );

require_once __DIR__ . '/autentik-cms.php';

/**
 * UU PDP: Pesan Masuk ikut diproses di Alat › Ekspor/Hapus Data Pribadi.
 * Dicari lewat email, dan juga lewat nomor WhatsApp (email di formulir tidak wajib). Karena formulir
 * permintaan WordPress hanya menerima alamat email, nomor WA ditulis sebagai email semu
 * "<nomor>@wa.invalid" (mis. 081234567890@wa.invalid) dengan centang "Kirim email konfirmasi" dikosongkan.
 * Nomor dicocokkan dalam bentuk angka saja (08… maupun 628…). Nilai non-email (dari kode) juga diperlakukan sebagai nomor.
 */
function autentik_pesan_by_email( $kunci ) {
	$kunci = trim( (string) $kunci );
	$q     = array( 'post_type' => 'pesan', 'post_status' => 'any', 'numberposts' => 100 );
	$or    = array( 'relation' => 'OR' );
	$nomor = $kunci;
	if ( is_email( $kunci ) ) {
		list( $lokal, $domain ) = explode( '@', $kunci, 2 );
		if ( 'wa.invalid' === strtolower( $domain ) ) {
			$nomor = $lokal;
		} else {
			$or[]  = array( 'key' => 'email', 'value' => $kunci );
			$nomor = '';
		}
	}
	$digit = preg_replace( '/\D+/', '', $nomor );
	if ( strlen( $digit ) >= 9 && strlen( $digit ) <= 15 ) {
		$varian = array( $digit, preg_replace( '/^0/', '62', $digit ), preg_replace( '/^62/', '0', $digit ) );
		$or[]   = array( 'key' => 'wa_digit', 'value' => array_values( array_unique( $varian ) ), 'compare' => 'IN' );
	}
	if ( count( $or ) < 2 ) {
		return array();
	}
	$q['meta_query'] = $or; // phpcs:ignore WordPress.DB.SlowDBQuery
	return get_posts( $q );
}
// Sekali jalan: Pesan lama (sebelum meta wa_digit/nama) dilengkapi agar ikut terjangkau pencarian UU PDP & sapaan WA.
add_action(
	'admin_init',
	function () {
		if ( '1' === get_option( 'aac_pesan_meta_v' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$ids = get_posts( array( 'post_type' => 'pesan', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ) );
		foreach ( $ids as $id ) {
			if ( '' === (string) get_post_meta( $id, 'wa_digit', true ) ) {
				update_post_meta( $id, 'wa_digit', preg_replace( '/\D+/', '', (string) get_post_meta( $id, 'wa', true ) ) );
			}
			if ( '' === (string) get_post_meta( $id, 'nama', true ) ) {
				update_post_meta( $id, 'nama', trim( (string) preg_split( '/\s*[:—]\s*/u', (string) get_post_field( 'post_title', $id ) )[0] ) );
			}
		}
		update_option( 'aac_pesan_meta_v', '1', false );
	}
);
add_filter(
	'wp_privacy_personal_data_exporters',
	function ( $ex ) {
		$ex['autentik-pesan'] = array(
			'exporter_friendly_name' => 'Pesan Masuk (formulir konsultasi)',
			'callback'               => function ( $email ) {
				$data = array();
				foreach ( autentik_pesan_by_email( $email ) as $p ) {
					$data[] = array(
						'group_id'    => 'autentik-pesan',
						'group_label' => 'Pesan Masuk',
						'item_id'     => 'pesan-' . $p->ID,
						'data'        => array(
							array( 'name' => 'Tanggal', 'value' => $p->post_date ),
							array( 'name' => 'Isi', 'value' => $p->post_content ),
						),
					);
				}
				return array( 'data' => $data, 'done' => true );
			},
		);
		return $ex;
	}
);
add_filter(
	'wp_privacy_personal_data_erasers',
	function ( $er ) {
		$er['autentik-pesan'] = array(
			'eraser_friendly_name' => 'Pesan Masuk (formulir konsultasi)',
			'callback'             => function ( $email ) {
				$n = 0;
				foreach ( autentik_pesan_by_email( $email ) as $p ) {
					if ( wp_delete_post( $p->ID, true ) ) {
						$n++;
					}
				}
				return array( 'items_removed' => $n > 0, 'items_retained' => false, 'messages' => array(), 'done' => true );
			},
		);
		return $er;
	}
);

/**
 * UU PDP: Pesan Masuk yang lebih tua dari 12 bulan dihapus otomatis (sesuai Kebijakan Privasi).
 * Dikelola plugin pemilik data Pesan; dijadwalkan saat aktivasi, dilepas saat nonaktif.
 * Memakai event yang sama dengan versi lama di tema ('autentik_hapus_pesan_lama') agar tidak terjadwal dobel.
 */
function aac_hapus_pesan_lama() {
	$lama = get_posts( array( 'post_type' => 'pesan', 'post_status' => 'any', 'numberposts' => 200, 'fields' => 'ids', 'date_query' => array( array( 'before' => '12 months ago' ) ) ) );
	foreach ( $lama as $id ) {
		wp_delete_post( $id, true );
	}
}
add_action( 'autentik_hapus_pesan_lama', 'aac_hapus_pesan_lama', 5 );
function aac_jadwal_hapus_pesan() {
	if ( ! wp_next_scheduled( 'autentik_hapus_pesan_lama' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'autentik_hapus_pesan_lama' );
	}
}
add_action( 'init', 'aac_jadwal_hapus_pesan' ); // juga memulihkan jadwal bila hilang

function autentik_activate() {
	autentik_register_post_types();
	flush_rewrite_rules();
	aac_jadwal_hapus_pesan();
}
register_activation_hook( __FILE__, 'autentik_activate' );
function autentik_deactivate() {
	wp_clear_scheduled_hook( 'autentik_hapus_pesan_lama' );
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'autentik_deactivate' );
